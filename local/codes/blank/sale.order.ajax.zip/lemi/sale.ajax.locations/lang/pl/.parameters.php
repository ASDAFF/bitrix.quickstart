<?
$MESS["CP_BSSI_NAME"] = "Lokalizacja nazwa pola wejściowego";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "Miatso jest opcjonalne";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Pole formularza nazwa miasta (lokalizacja)";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "ID lokalizacji zwrotnej (lub miasto w przeciwnym wypadku)";
$MESS["SALE_SAL_PARAM_COUNTRY"] = "Kraj początkowy";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Pole formularza nazwa kraju";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "Miatso (lokalizacja) zmiana obsługi";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Region nazwa pola formularza";
?>