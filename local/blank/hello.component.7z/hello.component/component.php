<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

$arResult = array();

if(empty($arParams['USER_NAME'])) {
	$arParams['USER_NAME'] = 'Незнакомец';
}

// Старт кеша 
// если кеша нет, то выполняет код, заключенный в фигурные скобки,
// в противном случае вместо этой части компонента подгружается кеш.
if ($this->StartResultCache(false, false)) {
    CModule::IncludeModule('iblock');
	
    // Кешируемый код компонента
	
	$arResult['HELLO_TEXT'] = 'Привет, ' . $arParams['USER_NAME'] . '!';
	
	// Подключение шаблона
    $this->IncludeComponentTemplate(); 
}

// Код, выполняющийся вне зависимости от кеша

?>
