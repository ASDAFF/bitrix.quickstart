<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arTemplateParameters = array(
	"INCLUDE_JQUERY"  =>  array(
		"NAME" => GetMessage("WEBDEBUG_REVIEWS_INCLUDE_JQUERY"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "N", 
	),
);

?>