<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vdgb.tszhvote/include.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vdgb.tszhvote/prolog.php");

IncludeModuleLangFile(__FILE__);

$modulePermissions = $APPLICATION->GetGroupRight("vdgb.tszhvote");
if ($modulePermissions<="R")
	$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));

$strRedirect = BX_ROOT."/admin/vdgb_tszhvoting_edit.php?lang=".LANG;
$strRedirectList = BX_ROOT."/admin/vdgb_tszhvoting.php?lang=".LANG;
$UF_ENTITY = "CITRUS_POLL";

$ID = IntVal($ID);


$aTabs = array(
	array (
		"DIV" => "edit1",
		"TAB" => GetMessage("voting_tab_edit1"),
		"ICON"=>"main_user_edit",
		"TITLE"=>GetMessage("voting_tab_edit1_title")
	),
	array(
		"DIV" => "edit2",
		"TAB" => GetMessage("voting_tab_edit2"),
		"ICON"=>"main_user_edit",
		"TITLE"=>GetMessage("voting_tab_edit2_title")
	),
);

$tabControl = new CAdminForm("citrusPollEdit", $aTabs);


//������ ������� �������� �������
$arClasses = CCitrusPollMethodBase::GetList();
$arMethodSelect = array();
foreach ($arClasses as $methodCode => $arMethod)
	$arMethodSelect[$methodCode] = $arMethod['NAME'];

//������ ���������� (������������, ������� ����� � �.�.)
$arEntityList = CCitrusPollEntityBase::GetList();
$arEntitySelect = array();
foreach ($arEntityList as $code => $arEntity)
	$arEntitySelect[$code] = $arEntity['NAME'];

$errorMessage = '';
$bVarsFromForm = false;
$ID = isset($_REQUEST["ID"]) && IntVal($_REQUEST["ID"]) > 0 ? IntVal($_REQUEST['ID']) : 0;
$COPY_ID = isset($_REQUEST["COPY"]) && IntVal($_REQUEST["COPY"]) > 0 ? IntVal($_REQUEST['COPY']) : 0;

if ($REQUEST_METHOD=="POST" && strlen($Update)>0 && $modulePermissions>="W" && check_bitrix_sessid())
{
	if ($modulePermissions < "W")
		$errorMessage .= GetMessage("ACCESS_DENIED") . "<br>";

    $arFields = array(
		"GROUP_ID" => IntVal($_POST["GROUP_ID"]),
		"DATE_BEGIN" => trim($_POST["DATE_BEGIN"]),
		"DATE_END" => trim($_POST["DATE_END"]),
    	"TITLE_TEXT" => trim(htmlspecialcharsbx($_POST["TITLE_TEXT"])),
    	"DETAIL_TEXT" => trim(htmlspecialcharsbx($_POST["DETAIL_TEXT"])),
    	"NAME" => trim(htmlspecialcharsbx($_POST["NAME"])),
    	"ACTIVE" => $_POST["ACTIVE"] == "Y" ? "Y" : "N",
		"ACCESS" => trim(IntVal($_POST["ACCESS"])),
		"ACCESS_EDIT" => trim(IntVal($_POST["ACCESS_EDIT"])),
		"ACCESS_SHOW" => trim(IntVal($_POST["ACCESS_SHOW"])),
		"ACCESS_SHOW" => trim(IntVal($_POST["ACCESS_SHOW"])),
		"PERCENT_NEEDED" => trim(IntVal($_POST["PERCENT_NEEDED"])),
		"VOTING_COMPLETED" => $_POST["VOTING_COMPLETED"] == "Y" ? "Y" : "N",
		"VOTING_METHOD" => trim(htmlspecialcharsbx($_POST["VOTING_METHOD"])),
		"ENTITY_TYPE" => trim($_POST["ENTITY_TYPE"]),
    );
	$USER_FIELD_MANAGER->EditFormAddFields($UF_ENTITY, $arFields);

    $ID = isset($_REQUEST["ID"]) && IntVal($_REQUEST["ID"]) > 0 ? IntVal($_REQUEST['ID']) : 0;
	if ($ID > 0) {
		$bResult = CCitrusPoll::Update($ID, $arFields);
	} else {
		$ID = CCitrusPoll::Add($arFields);
		$bResult = $ID > 0;
	}
	if (!$bResult)
	{
		if ($ex = $APPLICATION->GetException())
			$errorMessage .= $ex->GetString().".<br />";
		else
			$errorMessage .= GetMessage("voting_edit_err") . "<br />";
	}

	if (strlen($errorMessage) <= 0)
	{
		if (strlen($apply) <= 0)
			LocalRedirect($strRedirectList . GetFilterParams("filter_", false));
		else
		{
			LocalRedirect($strRedirect."&ID=".$ID."&".$tabControl->ActiveTabParam());
		}
	}
	else
	{
		$bVarsFromForm = true;
	}
}

if ($ID > 0)
{
    $APPLICATION->SetTitle(GetMessage("VOTING_EDIT_TITLE").$_GET["ID"]);
}
else
{
    $APPLICATION->SetTitle(GetMessage("VOTING_ADD_TITLE"));
}

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");


if ($bVarsFromForm)
{
	$DB->InitTableVarsForEdit("b_citrus_voting", "", "str_");
}
elseif ($ID > 0 || $COPY_ID > 0)
{
	$db = CCitrusPoll::GetList(
		Array(),
		Array("ID" => $ID > 0 ? $ID : $COPY_ID),
		false,
		Array("nTopCount" => 1),
		Array("*")
	);
	
	if (!$arFields = $db->ExtractFields("str_"))
		$ID = 0;

}
else
{
	$str_ACTIVE = "Y";
	$str_GROUP_ID = isset($_GET['id_group']) && IntVal($_GET['id_group']) > 0 ? IntVal($_GET['id_group']) : 0;
	$str_DATE_BEGIN = ConvertTimeStamp(); 
	$str_DATE_END = ConvertTimeStamp(strtotime('+1 month'));
}

if(strlen($errorMessage)>0)
	echo CAdminMessage::ShowMessage(Array("DETAILS"=>$errorMessage, "TYPE"=>"ERROR", "MESSAGE"=> GetMessage("TE_ERROR_HAPPENED"), "HTML"=>true));


//���������� �������� � ������ ������
$question_count = CCitrusPollQuestion::GetList(array(),array("VOTING_ID"=>$ID),array());



$aTabs = array(
	array (
            "DIV" => "edit1",
            "TAB" => GetMessage("voting_tab_edit1"),
            "ICON"=>"main_user_edit",
            "TITLE"=>GetMessage("voting_tab_edit1_title")
        ),
	array(
            "DIV" => "edit2",
            "TAB" => GetMessage("voting_tab_edit2"),
            "ICON"=>"main_user_edit",
            "TITLE"=>GetMessage("voting_tab_edit2_title")
        ),
);
$aMenu = array(
    array(
        "TEXT"	=> GetMessage("voting_list"),
        "TITLE"	=> GetMessage("voting_list_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting.php?lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_list"

    ),
);

if(isset($_GET["ID"]) && IntVal($_GET["ID"]) > 0) {

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_new"),
        "TITLE"	=> GetMessage("voting_new_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting_edit.php?lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_new"
    );

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_copy"),
        "TITLE"	=> GetMessage("voting_copy_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting_edit.php?COPY=" . IntVal($_GET["ID"]) ."&lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_copy"
    );

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_del"),
        "TITLE"	=> GetMessage("voting_del_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting.php?del_element=". IntVal($_GET["ID"]) ."&lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_delete"
    );

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_reset"),
        "TITLE"	=> GetMessage("voting_reset_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting.php?RESET=". IntVal($_GET["ID"]) ."lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_reset"
    );

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_question")." [". $question_count ."]",
        "TITLE"	=> GetMessage("voting_question_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting_question.php?VOTING_ID=". IntVal($_GET["ID"]) ."lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_list"
    );

    $aMenu[] = array(
        "TEXT"	=> GetMessage("voting_question_new"),
        "TITLE"	=> GetMessage("voting_question_new_title"),
        "LINK"	=> "/bitrix/admin/vdgb_tszhvoting_question_edit.php?VOTING_ID=". IntVal($_GET["ID"]) ."lang=".LANGUAGE_ID."&set_default=Y",
        "ICON"	=> "btn_new"
    );
}

$context = new CAdminContextMenu($aMenu);
$context->Show();


if(method_exists($USER_FIELD_MANAGER, 'showscript')) {
	$tabControl->BeginPrologContent();
	echo $USER_FIELD_MANAGER->ShowScript();
	$tabControl->EndPrologContent();
}

$tabControl->BeginEpilogContent();
echo GetFilterHiddens("filter_");
?>
<input type="hidden" name="ID" value="<?=$ID;?>"/>
<input type="hidden" name="Update" value="Y"/>
 <?
echo bitrix_sessid_post();
$tabControl->EndEpilogContent();


$tabControl->Begin(array(
	"FORM_ACTION" => $APPLICATION->GetCurPage(),
	"FORM_ATTRIBUTES" => "method=\"POST\" enctype=\"multipart/form-data\"",
));


$arPollGroups = Array();
$rsGroup = CCitrusPollGroup::GetList(array("SORT"), array("ACTIVE" => "Y"), false, false, array("ID","NAME"));
while($arGroupList = $rsGroup->GetNext(false))
{
	$arPollGroups[$arGroupList["ID"]] = "[".$arGroupList["ID"]."]".$arGroupList["NAME"];
}


$tabControl->BeginNextFormTab();

	if ($str_ID > 0) {
		$tabControl->AddViewField("ID", "ID", $str_ID);
		$tabControl->AddViewField("TIMESTAMP_X", GetMessage("TIMESTAMP_X"), $str_TIMESTAMP_X);
	}
	
	$tabControl->AddCheckBoxField("ACTIVE", GetMessage("voting_act"), false, "Y", ($str_ACTIVE=="Y"));
	$tabControl->AddDropDownField("GROUP_ID", GetMessage("voting_group_id"), true, $arPollGroups, $str_GROUP_ID);
	$tabControl->AddEditField("NAME", GetMessage("voting_name"), true, array("size"=>30, "maxlength"=>255), $str_NAME);
	$tabControl->AddCalendarField("DATE_BEGIN", GetMessage("voting_date_begin"), $str_DATE_BEGIN, true);
	$tabControl->AddCalendarField("DATE_END", GetMessage("voting_date_end"), $str_DATE_END, true);
	$tabControl->AddEditField("PERCENT_NEEDED", GetMessage("voting_count_of_comp"), false, array("size"=>5, "maxlength"=>3), $str_PERCENT_NEEDED);
	$tabControl->AddCheckBoxField("VOTING_COMPLETED", GetMessage("voting_completed"), false, "Y", ($str_VOTING_COMPLETED=="Y"));
	$tabControl->AddDropDownField("VOTING_METHOD", GetMessage("voting_method"), true, $arMethodSelect, $str_VOTING_METHOD);
	$tabControl->AddDropDownField("ENTITY_TYPE", GetMessage("CV_ENTITY_TYPE"), true, $arEntitySelect, $str_ENTITY_TYPE);
	
	if(
		(count($USER_FIELD_MANAGER->GetUserFields($UF_ENTITY)) > 0) ||
		($USER_FIELD_MANAGER->GetRights($UF_ENTITY) >= "W")
	)
	{
		$tabControl->AddSection('USER_FIELDS', GetMessage("USER_FIELDS"));
		$tabControl->ShowUserFields($UF_ENTITY, $str_ID, $bVarsFromForm);
	}
	

$tabControl->BeginNextFormTab();

	$tabControl->AddEditField("TITLE_TEXT", GetMessage("TITLE_TEXT"), false, array("size"=>80, "maxlength"=>255), $str_TITLE_TEXT);
	$tabControl->BeginCustomField("DETAIL_TEXT", GetMessage("DETAIL_TEXT"), false);
	?>
	<tr>
		<td width="20%" valign="top"><?= GetMessage("DETAIL_TEXT");?>:</td>
		<td width="80%" valign="top">
			<?
			if (CModule::IncludeModule("fileman")):
				$LHE = new CLightHTMLEditor;
				$LHE->Show(array(
					'id' => 'DETAIL_TEXT',
					'width' => '100%',
					'height' => '200px',
					'inputName' => "DETAIL_TEXT",
					'content' => $str_DETAIL_TEXT,
					'bUseFileDialogs' => false,
					'bFloatingToolbar' => true,
					'bArisingToolbar' => true,
					'toolbarConfig' => array(
						'Bold', 'Italic', 'Underline', 'RemoveFormat',
						'CreateLink', 'DeleteLink', 'Image', 'Video',
		//				'BackColor', 'ForeColor',
						'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyFull',
						'InsertOrderedList', 'InsertUnorderedList', 'Outdent', 'Indent',
						'StyleList', 'HeaderList',
		//				'FontList', 'FontSizeList',
					),
				));
			else:
				?>
				<textarea rows="5" cols="40" name="DESCRIPTION"><?=$str_DETAIL_TEXT?></textarea>
				<?
			endif;
			?>
		</td>
	</tr>
	<?
	$tabControl->EndCustomField("DETAIL_TEXT", '<input type="hidden" name="DETAIL_TEXT" value="'.$str_DETAIL_TEXT.'">');
	
	

$tabControl->Buttons(Array(
	"disabled" => ($modulePermissions < "W"),
	"back_url" => $strRedirectList . GetFilterParams("filter_"),
));

$tabControl->Show();
$tabControl->ShowWarnings($tabControl->GetName(), $message);

if(!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1):?>
<?echo BeginNote();?>
<span class="required">*</span> <?echo GetMessage("REQUIRED_FIELDS")?>
<?echo EndNote(); ?>
<?endif;?>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");?>