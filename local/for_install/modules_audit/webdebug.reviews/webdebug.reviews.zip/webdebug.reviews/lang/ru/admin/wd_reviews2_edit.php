<?
$MESS['WD_REVIEWS2_PAGE_TITLE_ADD'] = 'Добавление нового отзыва';
$MESS['WD_REVIEWS2_PAGE_TITLE_EDIT'] = 'Редактирование отзыва';

$MESS['WD_REVIEWS2_TAB1_NAME'] = 'Добавление отзыва';
$MESS['WD_REVIEWS2_TAB1_DESC'] = 'Форма добавления отзыва администратором сайта';

$MESS['WD_REVIEWS2_ERROR_REVIEW_NOT_FOUND'] = 'Не найден указанный отзыв';

$MESS['WD_REVIEWS2_MENU_LIST'] = 'Список отзывов';
$MESS['WD_REVIEWS2_MENU_ADD'] = 'Добавить отзыв';
$MESS['WD_REVIEWS2_MENU_DELETE'] = 'Удалить отзыв';
$MESS['WD_REVIEWS2_MENU_DELETE_CONFIRM'] = 'Вы уверены, что хотите удалить текущий отзыв?';

$MESS['WD_REVIEWS2_FIELD_TARGET_OPEN_SITE'] = 'открыть на сайте';
$MESS['WD_REVIEWS2_FIELD_TARGET_OPEN_ADMIN'] = 'открыть в админке';
$MESS['WD_REVIEWS2_FIELD_TARGET_BLANK'] = 'откроется в новом окне';

$MESS['WD_REVIEWS2_HEADER_FIELD'] = 'Поля формы';
$MESS['WD_REVIEWS2_NO_FIELDS'] = 'Поля не созданы. Перейдите на <a href="#LINK#" target="_blank">страницу редактирования интерфейса</a>, чтобы добавить новые поля для отзывов.';
$MESS['WD_REVIEWS2_HEADER_RATINGS'] = 'Рейтинги';
$MESS['WD_REVIEWS2_NO_RATINGS'] = 'Рейтинги не созданы. Перейдите на <a href="#LINK#" target="_blank">страницу редактирования интерфейса</a>, чтобы добавить новые рейтинги для отзывов.';

$MESS['WD_REVIEWS2_HEADER_RATINGS_VOTING'] = 'Мнение пользователей';
$MESS['WD_REVIEWS2_VOTES_Y'] = 'Голосов ЗА';
$MESS['WD_REVIEWS2_VOTES_N'] = 'Голосов «ПРОТИВ»';
$MESS['WD_REVIEWS2_VOTE_RESULT'] = 'Результат голосования';

$MESS['WD_REVIEWS2_HEADER_ASWER'] = 'Ответ на отзыв';
$MESS['WD_REVIEWS2_ANSWER'] = 'Ответ администратора';
$MESS['WD_REVIEWS2_DATE_ANSWER'] = 'Дата ответа';
$MESS['WD_REVIEWS2_ANSWER_USER_ID'] = 'ID aдминистратора';

?>