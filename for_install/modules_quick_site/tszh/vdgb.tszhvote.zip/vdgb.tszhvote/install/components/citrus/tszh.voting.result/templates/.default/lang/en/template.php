<?
$MESS["VOTE_GROUP_TOTAL"] = "total";
?>