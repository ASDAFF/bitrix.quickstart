<?
$MESS["CITY_INPUT_NAME_TIP"] = "El nombre de un campo del formulario para contener el nombre o la ubicación de la ciudad.";
$MESS["CITY_OUT_LOCATION_TIP"] = "Si está marcada, los servicios devolverá el ID de ubicación.";
$MESS["COUNTRY_INPUT_NAME_TIP"] = "El nombre de un campo del formulario que contiene el nombre del país.";
$MESS["COUNTRY_TIP"] = "Seleccione aquí el país que aparecerá primero en la lista.";
$MESS["ONCITYCHANGE_TIP"] = "Especifica el nombre de la<b>ciudad seleccionada</b>servicios para eventos.";
?>