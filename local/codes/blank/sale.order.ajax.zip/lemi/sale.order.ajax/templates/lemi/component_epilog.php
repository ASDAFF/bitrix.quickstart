<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Page\Asset;
$asset = Asset::getInstance();
$asset->addJs('//api-maps.yandex.ru/2.1/?apikey=c8d28484-9ad4-46e7-88b5-94311cbcb5c8&load=package.full&lang=ru-RU');
?>

