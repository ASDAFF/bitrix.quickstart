<?
    require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/classes/general/xml.php');

    require("CStartShopExchange1CResponse.php");
    require("CStartShopExchange1CCatalog.php");
    require("CStartShopExchange1CCatalogIBlock.php");
    require("CStartShopExchange1CCatalogSection.php");
    require("CStartShopExchange1CCatalogProperty.php");
    require("CStartShopExchange1CCatalogItem.php");
    require("CStartShopExchange1CCatalogOffer.php");
    require("CStartShopExchange1COrder.php");

    class CStartShopExchange1C
    {
        public static function GetSchemeVersion(&$oXml) {
            if ($oXml instanceof CDataXML)
                if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация")) {
                    $sVersion = $oNode->getAttribute("ВерсияСхемы");

                    if (!empty($sVersion))
                        return $sVersion;
                }

            return null;
        }
    }

?>