<?
$MESS ['ADG_WTITLE_NEW_SECTION'] = "Add";
$MESS ['ADG_WTITLE_EDIT_SECTION'] = "Edit";
$MESS ['ADG_ERROR_NO_SECTION'] = "Error. Can't find parent section. It's required.";
$MESS ['ADG_LBL_NAME'] = "Name";
$MESS ['ADG_LBL_SORT'] = "Sort";
$MESS ['ADG_LBL_COVER'] = "Set cover for the album";
$MESS ['ADG_LBL_SAVE'] = "Save";
$MESS ['ADG_ERROR_EMPTY_NAME'] = "Error. Name(on main language) can't be empty";
$MESS ['ADG_MSG_ENTER_NAME'] = "Enter name for the section(or album)<br><br>";
?>
