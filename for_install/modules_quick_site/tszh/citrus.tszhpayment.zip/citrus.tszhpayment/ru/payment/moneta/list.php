<?
include(GetLangFileName(dirname(__FILE__)."/", "/payment.php"));
if (!$USER->IsAuthorized())
{
	echo GetMessage("CITRUS_TSZHPAYMENT_TERMS_UNAUTH");
	return;
}

