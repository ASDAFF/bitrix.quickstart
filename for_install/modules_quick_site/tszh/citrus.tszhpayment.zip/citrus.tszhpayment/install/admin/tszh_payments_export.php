<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszhpayment/admin/tszh_payments_export.php");
?>
