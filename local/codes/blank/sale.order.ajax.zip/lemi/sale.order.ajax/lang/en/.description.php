<?
$MESS['SOF_DEFAULT_TEMPLATE_NAME'] = "Ordering Page";
$MESS['SOF_DEFAULT_TEMPLATE_DESCRIPTION'] = "Ordering procedure";
$MESS['SOF_NAME'] = "Ordering Procedure";