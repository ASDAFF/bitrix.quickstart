<?
$MESS ['SAL_CHOOSE_COUNTRY'] = '(выберите страну)';
$MESS ['SAL_CHOOSE_REGION'] = '(выберите регион)';
$MESS ['SAL_CHOOSE_CITY'] = '(выберите город)';
$MESS ['SAL_CHOOSE_CITY_OTHER'] = '(другой)';
$MESS ['LOC_DEFAULT_NAME_NULL'] = 'другой';
$MESS ['SAL_LOC_COUNTRY'] = 'Страна';
$MESS ['SAL_LOC_REGION'] = 'Регион';
$MESS ['SAL_LOC_CITY'] = 'Город';
?>