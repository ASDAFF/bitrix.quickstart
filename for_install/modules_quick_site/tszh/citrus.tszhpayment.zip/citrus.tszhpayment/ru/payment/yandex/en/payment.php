<?
global $MESS;

$MESS["SPCP_DTITLE"] = "Yandex.Money (Russian payment system)";
$MESS["SPCP_DDESCR"] = "Payment via Pay Center <a href=\"http://money.yandex.ru\" target=\"_blank\">http://money.yandex.ru</a>";


$MESS["SHOP_ID"] = "Shop ID";
$MESS["USER_ID"] = "Customer information";
$MESS["ORDER_ID"] = "Order ID";
$MESS["SHOP_KEY"] = "Shop password";
$MESS["SHOULD_PAY"] = "Order amount";
$MESS["ORDER_DATE"] = "Order date";
$MESS["IS_TEST"] = "Test mode";
$MESS["IS_TEST_DESCR"] = "If empty - shop will work in normal mode";
?>