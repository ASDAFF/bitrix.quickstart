$(function () {
    var note = $('#tszhAuthNote'),
        phone = $('#tszhAuthNote .tszh-note-phone');
    var getCurrentOrg = function() {
        var id = $('input[name=TSZH_ID]').val();
        if (!id)
            id = $('select[name=TSZH_ID]').val();
        return id;
    };
    var showHideNote = function() {
        var org = getCurrentOrg();
        if (typeof window.tszhHasAccounts[org] !== 'undefined') {
            note.show();
            phone.html(window.tszhHasAccounts[org]);
        } else {
            note.hide();
        }
    };
    $('select[name=TSZH_ID]').change(function () {
        showHideNote();
    })

    showHideNote();
});