<?
$arModuleVersion = array(
	"VERSION" => "1.4.2",
	"VERSION_DATE" => "2017-01-10 20:56:37"
);
?>