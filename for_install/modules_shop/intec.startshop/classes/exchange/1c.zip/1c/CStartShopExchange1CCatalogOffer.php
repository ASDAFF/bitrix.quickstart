<?
    class CStartShopExchange1CCatalogOffer
    {
        public $Id;
        public $Name;
        public $Characteristics;
        public $Prices;
        public $Quantity;

        public function GetCatalogItemID() {
            if ($this->IsOffer()) {
                $arIDs = explode('#', $this->Id);
                return $arIDs[0];
            } else {
                return $this->Id;
            }
        }

        public function GetCatalogItemOfferID() {
            if ($this->IsOffer()) {
                $arIDs = explode('#', $this->Id);
                return $arIDs[1];
            } else {
                return null;
            }
        }

        public function IsOffer() {
            if (count(explode('#', $this->Id)) > 1 && !empty($this->Characteristics)) {
                return true;
            } else {
                return false;
            }
        }

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeCharacteristics = $oXmlNode->elementsByName("ХарактеристикиТовара");
                $oXmlNodeCharacteristics = $oXmlNodeCharacteristics[0];
                $oXmlNodePrices = $oXmlNode->elementsByName("Цены");
                $oXmlNodePrices = $oXmlNodePrices[0];
                $oXmlNodeQuantity = $oXmlNode->elementsByName("Количество");
                $oXmlNodeQuantity = $oXmlNodeQuantity[0];


                if ($oXmlNodeId == null || $oXmlNodeName == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                if ($oXmlNodePrices != null)
                    $oInstance->Prices = CStartShopExchange1CCatalogOfferPrice::GetListByXmlNodes($oXmlNodePrices->children());

                if ($oXmlNodeCharacteristics != null)
                    $oInstance->Characteristics = CStartShopExchange1CCatalogOfferCharacteristic::GetListByXmlNodes($oXmlNodeCharacteristics->children());

                if ($oXmlNodeQuantity != null) {
                    $oInstance->Quantity = floatval(CStartShopUtil::ConvertToSiteCharset($oXmlNodeQuantity->textContent()));
                } else {

                }

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }

        public static function GetListByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/ПакетПредложений/Предложения");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetListByXmlNodes($oXmlNode->children());
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogOfferPriceType
    {
        public $Id;
        public $Name;
        public $Ratio;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeRatio = $oXmlNode->elementsByName("Коэффициент");
                $oXmlNodeRatio = $oXmlNodeRatio[0];

                if ($oXmlNodeId == null || $oXmlNodeName == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                if ($oXmlNodeRatio != null) {
                    $oInstance->Ratio = floatval(CStartShopUtil::ConvertToSiteCharset($oXmlNodeRatio->textContent()));
                } else {
                    $oInstance->Ratio = 1;
                }

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }

        public static function GetListByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/ПакетПредложений/ТипыЦен");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetListByXmlNodes($oXmlNode->children());
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogOfferPrice
    {
        public $Type;
        public $Value;
        public $Currency;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeType = $oXmlNode->elementsByName("ИдТипаЦены");
                $oXmlNodeType = $oXmlNodeType[0];
                $oXmlNodeValue = $oXmlNode->elementsByName("ЦенаЗаЕдиницу");
                $oXmlNodeValue = $oXmlNodeValue[0];
                $oXmlNodeCurrency = $oXmlNode->elementsByName("Валюта");
                $oXmlNodeCurrency = $oXmlNodeCurrency[0];

                if ($oXmlNodeType == null || $oXmlNodeValue == null)
                    return null;

                $oInstance = new static;
                $oInstance->Type = CStartShopUtil::ConvertToSiteCharset($oXmlNodeType->textContent());
                $oInstance->Value = floatval(CStartShopUtil::ConvertToSiteCharset($oXmlNodeValue->textContent()));

                if ($oXmlNodeCurrency != null)
                    $oInstance->Currency = CStartShopUtil::ConvertToSiteCharset($oXmlNodeCurrency->textContent());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Type] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogOfferCharacteristic
    {
        public $Name;
        public $Value;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeValue = $oXmlNode->elementsByName("Значение");
                $oXmlNodeValue = $oXmlNodeValue[0];

                if ($oXmlNodeName == null || $oXmlNodeValue == null)
                    return null;

                $oInstance = new static;
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());
                $oInstance->Value = CStartShopUtil::ConvertToSiteCharset($oXmlNodeValue->textContent());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }
    }
?>