<?

$MESS['WD_REVIEWS2_TAB_GENERAL_NAME'] = 'Общие настройки рейтинга';
$MESS['WD_REVIEWS2_TAB_GENERAL_DESC'] = 'Редактирование общих настроек нового рейтинга';

$MESS['WD_REVIEWS2_RATING_NAME'] = 'Название';
$MESS['WD_REVIEWS2_RATING_SORT'] = 'Сортировка';
$MESS['WD_REVIEWS2_RATING_DESCRIPTION'] = 'Описание';
$MESS['WD_REVIEWS2_RATING_PARTICIPATES'] = 'Влияет на общий рейтинг';

?>