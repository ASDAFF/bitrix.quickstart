<?
$MESS["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Formularz dynamiczego wyboru lokalizacji";
$MESS["SAL_DEFAULT_TEMPLATE_NAME"] = "Lokalizacje (AJAX)";
$MESS["SAL_NAME"] = "Procedura zamówienia";
?>