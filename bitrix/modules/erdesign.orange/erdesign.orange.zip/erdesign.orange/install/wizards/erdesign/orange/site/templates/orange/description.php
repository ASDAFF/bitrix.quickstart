<?$arTemplate = Array(
	"NAME"=>GetMessage('CSST_TEMPLATE_NAME'), 
	"DESCRIPTION"=>GetMessage('CSST_TEMPLATE_DESC')
);?>