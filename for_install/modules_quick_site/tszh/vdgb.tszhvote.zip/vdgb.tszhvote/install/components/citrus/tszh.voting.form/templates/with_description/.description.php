<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("VOTE_WITH_DESC_NAME"),
	"DESCRIPTION" => GetMessage("VOTE_WITH_DESC_DESC"),
);
?>