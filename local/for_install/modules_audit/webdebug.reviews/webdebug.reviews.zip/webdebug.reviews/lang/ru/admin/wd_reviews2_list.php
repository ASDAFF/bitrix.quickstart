<?
$MESS['WD_REVIEWS2_PAGE_TITLE'] = 'Список отзывов &ndash; #NAME#';

$MESS['WD_REVIEWS2_MENU_DELETE'] = 'Удалить отзыв';
$MESS['WD_REVIEWS2_MENU_DELETE_CONFIRM'] = 'Вы уверены, что хотите удалить выбранный отзыв?';

$MESS['WD_REVIEWS2_FILTER_DESCRIPTION'] = 'Описание';
$MESS['WD_REVIEWS2_FILTER_MODERATED'] = 'Допущено к публикации';
	$MESS['WD_REVIEWS2_FILTER_MODERATED_ANY'] = '--- не имеет значения ---';
$MESS['WD_REVIEWS2_FILTER_DATE_CREATE'] = 'Дата создания';
$MESS['WD_REVIEWS2_FILTER_DATE_MODIFIED'] = 'Дата изменения';
$MESS['WD_REVIEWS2_FILTER_USER_ID'] = 'Пользователь';
$MESS['WD_REVIEWS2_FILTER_ANSWER'] = 'Ответ администрации';
$MESS['WD_REVIEWS2_FILTER_ANSWER_USER_ID'] = 'ID администратора';
$MESS['WD_REVIEWS2_FILTER_TARGET'] = 'Объект';
	$MESS['WD_REVIEWS2_FILTER_TARGET_ANY'] = '--- не имеет значения ---';
	$MESS['WD_REVIEWS2_FILTER_TARGET_ELEMENT'] = 'элемент инфоблока';

?>