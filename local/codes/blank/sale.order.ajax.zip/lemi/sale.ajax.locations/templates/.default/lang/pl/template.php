<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "inne";
$MESS["SAL_CHOOSE_CITY"] = "(wybierz miasto)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(inny)";
$MESS["SAL_CHOOSE_COUNTRY"] = "(wybierz kraj)";
$MESS["SAL_CHOOSE_REGION"] = "(wybierz region)";
$MESS["SAL_LOC_CITY"] = "Miasto";
$MESS["SAL_LOC_COUNTRY"] = "Kraj";
$MESS["SAL_LOC_REGION"] = "Region";
?>