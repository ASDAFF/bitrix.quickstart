<?
$arModuleVersion = array(
	"VERSION" => "3.3.3",
	"VERSION_DATE" => "2017-06-29 21:17:05"
);
?>