<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (count($arResult['PAY_SYSTEMS']) <= 0) {
	ShowError(GetMessage("TSZH_PAYMENT_NO_PAY_SYSTEMS"));
	return;
}

if($arParams["DISPLAY_TOP_PAGER"]) {
	echo $arResult["NAV_STRING"];
}

foreach ($arResult['PAY_SYSTEMS'] as $key=>$arPaySystem):

	if ($_SERVER["REQUEST_METHOD"] == "POST" && IntVal($_POST["pay_system_id"]) != $arPaySystem['ID'] && $USER->IsAuthorized())
		continue;

?>
<div class="pay-system">
	<div class="pay-system-description"><?=$arPaySystem['DESCRIPTION']?></div>
<?$APPLICATION->IncludeComponent(
	"citrus:tszh.payment.do",
	".default",
	Array(
		"MINIMUM_SUMM" => $arPaySystem["ACTION_FILE"] == "/bitrix/modules/citrus.tszhpayment/ru/payment/moneta" ? CTszhPaymentGatewayMoneta::getInstance()->getMinPaymentSum() : "0",
		"PAY_SYSTEM" => $arPaySystem["ID"],
		"AMOUNT_TO_SHOW" => is_set($_GET["summ"]) && is_numeric($_GET["summ"]) ? $_GET["summ"] : '',
		"TSZH_ID" => is_set($arResult, "FILTER") && is_set($arResult["FILTER"], "TSZH_ID") ? $arResult["FILTER"]["TSZH_ID"] : false,
	),
	$component,
	Array("HIDE_ICONS" => "Y")
);?>
</div>
<hr />
<?
endforeach;


if($arParams["DISPLAY_BOTTOM_PAGER"]) {
	echo $arResult["NAV_STRING"];
}
?>