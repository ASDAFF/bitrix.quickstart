<?
$MESS["PUP_NULL"] = "Įvesti miestą";
$MESS["LOC_DEFAULT_NAME_NULL"] = "kita (rankinis įrašas)";
?>