<?
$MESS['MFT_NAME'] = "Name...";
$MESS['MFT_FNAME'] = "Last Name...";
$MESS['MFT_PHONE'] = "Phone";
$MESS['MFT_EMAIL'] = "E-mail";
$MESS['MFT_MESSAGE'] = "Message...";
$MESS ['MFT_CAPTCHA'] = "CAPTCHA";
$MESS ['MFT_CAPTCHA_CODE'] = "Type the letters you see on the picture";
$MESS['MFT_SUBMIT'] = "Send";
?>