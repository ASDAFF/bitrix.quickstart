<?
    define("STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_STRING", 0);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_NUMBER", 1);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_LIST", 2);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_DATETIME", 3);

    class CStartShopExchange1CCatalogProperty
    {
        public $Id;
        public $Name;
        public $Type;
        public $Values;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeType = $oXmlNode->elementsByName("ТипЗначений");
                $oXmlNodeType = $oXmlNodeType[0];
                $oXmlNodeValues = $oXmlNode->elementsByName("ВариантыЗначений");
                $oXmlNodeValues = $oXmlNodeValues[0];

                if ($oXmlNodeId == null || $oXmlNodeName == null || $oXmlNodeType == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                switch ($oXmlNodeType->textContent()) {
                    case "Строка": $oInstance->Type = STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_STRING; break;
                    case "Число": $oInstance->Type = STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_NUMBER; break;
                    case "Время": $oInstance->Type = STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_DATETIME; break;
                    case "Справочник": $oInstance->Type = STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_LIST; break;
                }

                if ($oInstance->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_LIST)
                    if ($oXmlNodeValues != null) {
                        $oInstance->Values = CStartShopExchange1CCatalogPropertyListValue::GetListByXmlNodes($oXmlNodeValues->children());
                    } else {
                        return null;
                    }

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }

        public static function GetListByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/Классификатор/Свойства");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetListByXmlNodes($oXmlNode->children());
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogPropertyListValue
    {
        public $Id;
        public $Value;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("ИдЗначения");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeValue = $oXmlNode->elementsByName("Значение");
                $oXmlNodeValue = $oXmlNodeValue[0];

                if ($oXmlNodeId == null || $oXmlNodeValue == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Value = CStartShopUtil::ConvertToSiteCharset($oXmlNodeValue->textContent());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }
    }
?>