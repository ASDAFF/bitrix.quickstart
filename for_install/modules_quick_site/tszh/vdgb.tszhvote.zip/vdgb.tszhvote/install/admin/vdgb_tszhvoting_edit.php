<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vdgb.tszhvote/admin/vdgb_tszhvoting_edit.php");?>
