<?
$MESS['WD_REVIEWS2_INTERFACE'] = 'Интерфейс';
$MESS['WD_REVIEWS2_TARGET_TYPE'] = 'Тип объекта';
	$MESS['WD_REVIEWS2_TARGET_TYPE_DEFAULT'] = '--- по умолчанию ---';
	$MESS['WD_REVIEWS2_TARGET_TYPE_ELEMENT'] = 'элемент инфоблока';
$MESS['WD_REVIEWS2_TARGET'] = 'Объект';
$MESS['WD_REVIEWS2_COUNT'] = 'Количество отзывов на странице';
$MESS['WD_REVIEWS2_SORT_BY_1'] = 'Поле для первой сортировки';
$MESS['WD_REVIEWS2_SORT_ORDER_1'] = 'Направление для первой сортировки';
$MESS['WD_REVIEWS2_SORT_BY_2'] = 'Поле для второй сортировки';
$MESS['WD_REVIEWS2_SORT_ORDER_2'] = 'Направление для второй сортировки';
$MESS['WD_REVIEWS2_FILTER_NAME'] = 'Дополнительный фильтр';
$MESS['WD_REVIEWS2_SHOW_AVATARS'] = 'Показывать аватарки';
$MESS['WD_REVIEWS2_SHOW_ANSWERS'] = 'Показывать ответы администрации';
$MESS['WD_REVIEWS2_SHOW_ANSWER_DATE'] = 'Показывать даты ответов';
$MESS['WD_REVIEWS2_USER_ANSWER_NAME'] = 'Шаблон имени ответившего администратора';
	$MESS['WD_REVIEWS2_USER_ANSWER_NAME_0'] = '(отображать только логин)';
	$MESS['WD_REVIEWS2_USER_ANSWER_NAME_1'] = 'Иван';
	$MESS['WD_REVIEWS2_USER_ANSWER_NAME_2'] = 'Иван Иванов';
	$MESS['WD_REVIEWS2_USER_ANSWER_NAME_3'] = 'Иванов Иван';
	$MESS['WD_REVIEWS2_USER_ANSWER_NAME_4'] = 'Иван Иванович';
$MESS['WD_REVIEWS2_SHOW_ANSWER_AVATAR'] = 'Показывать аватарки администраторов';
$MESS['WD_REVIEWS2_ALLOW_VOTE'] = 'Разрешить голосования за отзывы';
$MESS['WD_REVIEWS2_MANUAL_CSS_INCLUDE'] = 'Подключать CSS нестандартным способом';
$MESS['WD_REVIEWS2_AUTO_LOADING'] = 'Автоматически подгружать актуальный список отзывов';
$MESS['WD_REVIEWS2_SHOW_ALL_IF_ADMIN'] = 'Показывать все отзывы для администраторов';
$MESS['WD_REVIEWS2_DATE_FORMAT'] = 'Формат даты/времени';
$MESS['WD_REVIEWS2_MINIMIZE_FORM'] = 'Сворачивать форму по умолчанию';
$MESS['WD_REVIEWS2_JS'] = 'Подключать JS-скрипты';
	$MESS['WD_REVIEWS2_JS_NONE'] = '--- не подключать ---';
	$MESS['WD_REVIEWS2_JS_ALL'] = 'jQuery и плагин звездочек';
	$MESS['WD_REVIEWS2_JS_RATY'] = 'Только плагин звездочек';

$MESS['WD_REVIEWS2_PAGER_TITLE_VALUE'] = 'Отзывы';

$MESS['WD_REVIEWS2_DATE_CREATED'] = 'Дата создания';
$MESS['WD_REVIEWS2_DATE_MODIFIED'] = 'Дата изменения';
$MESS['WD_REVIEWS2_DATE_VOTING'] = 'Дата последнего голосования';
$MESS['WD_REVIEWS2_DATE_ANSWER'] = 'Дата ответа';
$MESS['WD_REVIEWS2_VOTES_Y'] = 'Кол-во голосов «ЗА»';
$MESS['WD_REVIEWS2_VOTES_N'] = 'Кол-во голосов «ПРОТИВ»';
$MESS['WD_REVIEWS2_VOTE_RESULT'] = 'Результат голосования';

$MESS['WD_REVIEWS2_SORT_ASC'] = 'По возрастанию';
$MESS['WD_REVIEWS2_SORT_DESC'] = 'По убыванию';

?>