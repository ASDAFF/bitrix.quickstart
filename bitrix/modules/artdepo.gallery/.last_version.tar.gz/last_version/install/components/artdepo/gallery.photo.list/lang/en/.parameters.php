<?
$MESS ['POP_NONE'] = "Not use (in case of other scripts)";
$MESS ['COMP_POPUP_TEMPLATE'] = "Popup photo template";

$MESS ['COMP_ARTDEPO_GALLERY_PHOTO_LIST_SECTION_ID_NAME'] = "Root section";
$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_PARENT_ID_NAME'] = "Parent album";

$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_SORT_BY1_NAME'] = "Field for sorting";
$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_SORT_ORDER1_NAME'] = "Direction for sorting";

$MESS ["T_IBLOCK_DESC_ASC"] = "Ascending";
$MESS ["T_IBLOCK_DESC_DESC"] = "Descending";
$MESS ["T_IBLOCK_DESC_FID"] = "ID";
$MESS ["T_IBLOCK_DESC_FNAME"] = "Name";
$MESS ["T_IBLOCK_DESC_FSORT"] = "Sort";
$MESS ["T_IBLOCK_DESC_FTSAMP"] = "Date of last change";
$MESS ["T_IBLOCK_DESC_FTSCREATED"] = "Creation date";

$MESS ["COMP_GPL_DESC_BACK_URL"] = "Back url";

$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_DISPLAY_NAME_NAME'] = "Display name";
$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_LANGUAGE_ID_NAME'] = "Language";
$MESS ['COMP_ARTDEPO_GALLERY_ALBUM_LIST_NEWS_COUNT_NAME'] = "Elements per page";
$MESS ["COMP_ARTDEPO_GALLERY_ALBUM_LIST_NAME_TRUNCATE_LEN_NAME"] = "Truncate name length";
$MESS ["COMP_ARTDEPO_GALLERY_ALBUM_LIST_SKIP_FIRST_NAME"] = "Skip first item";

$MESS ["CP_ADGL_SET_STATUS_404"] = "Set 404 status if no element or section was found";

$MESS ["CP_BNL_CACHE_GROUPS"] = "Respect Access Permissions";
?>
