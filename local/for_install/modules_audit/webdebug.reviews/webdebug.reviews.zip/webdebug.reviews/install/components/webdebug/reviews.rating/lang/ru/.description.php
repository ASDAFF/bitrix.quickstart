<?
$MESS['WEBDEBUG_REVIEWS_COMPONENT_NAME'] = 'Рейтинг на основе отзывов (старая версия)';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_DESC'] = 'Вывод среднего рейтинга на основе отзывов';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>