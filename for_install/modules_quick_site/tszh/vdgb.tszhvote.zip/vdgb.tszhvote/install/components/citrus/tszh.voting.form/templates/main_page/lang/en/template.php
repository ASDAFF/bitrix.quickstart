<?
$MESS ['VOTE_SUBMIT_BUTTON'] = "Vote";
$MESS["F_CAPTCHA_TITLE"] = "Spam bot protection (CAPTCHA)";
$MESS["F_CAPTCHA_PROMT"] = "CAPTCHA image characters";
?>
