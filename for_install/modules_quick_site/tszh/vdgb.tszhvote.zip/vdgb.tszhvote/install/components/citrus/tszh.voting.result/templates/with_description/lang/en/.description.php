<?
$MESS ['VOTE_WITH_DESCRIPTION_NAME'] = "Template with poll description";
$MESS ['VOTE_WITH_DESCRIPTION_DESC'] = "Default template with poll description";
?>