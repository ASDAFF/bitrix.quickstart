<?
$MESS['WEBDEBUG_REVIEWS_SOURCE'] = 'Выбор элемента инфоблока';
	$MESS['WEBDEBUG_REVIEWS_IBLOCK_TYPE'] = 'Тип инфоблока';
	$MESS['WEBDEBUG_REVIEWS_IBLOCK_ID'] = 'Инфоблок';
	$MESS['WEBDEBUG_REVIEWS_ELEMENT_ID'] = 'ID элемента';
	$MESS['WEBDEBUG_REVIEWS_ELEMENT_CODE'] = 'Код элемента';

$MESS['WEBDEBUG_REVIEWS_SUCCESS_MESSAGE'] = 'Сообщение от успешной отправке';
$MESS['WEBDEBUG_REVIEWS_SUCCESS_MESSAGE_DEFAULT'] = 'Спасибо! Ваш отзыв успешно добавлен.';
$MESS['WEBDEBUG_REVIEWS_EVENT_TEMPLATES'] = 'Отправлять сообщения по почтовым шаблонам';
$MESS['WEBDEBUG_REVIEWS_USE_CAPTCHA'] = 'Использовать CAPTCHA для неавторизованных пользователей';
$MESS['WEBDEBUG_REVIEWS_USE_MODERATE'] = 'Публиковать отзывы только после модерации';
$MESS['WEBDEBUG_REVIEWS_DELETE_PARAMETERS'] = 'Удалять GET-переменные из запроса при переадресации';

$MESS['WEBDEBUG_REVIEWS_FIELDS'] = 'Заполняемые поля';
	$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELDS'] = 'Отображаемые поля';
	$MESS['WEBDEBUG_REVIEWS_REQUIRED_FIELDS'] = 'Поля, обязательные для заполнения';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_NAME'] = 'Имя';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_EMAIL'] = 'E-mail';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_WWW'] = 'Веб-сайт';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_PLUS'] = 'Достоинства';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_MINUS'] = 'Недостатки';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_COMMENTS'] = 'Комментарии';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_EMAIL_PUBLIC'] = 'Разрешить возможность публиковать e-mail';

?>