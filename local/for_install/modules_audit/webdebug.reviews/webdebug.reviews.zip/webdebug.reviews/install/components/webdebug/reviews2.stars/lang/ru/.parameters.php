<?
$MESS['WD_REVIEWS2_VALUE'] = 'Значение (кол-во звездочек)';
$MESS['WD_REVIEWS2_INTERFACE'] = 'Интерфейс';
$MESS['WD_REVIEWS2_INPUT_NAME'] = 'Имя скрытого поля для ввода';
$MESS['WD_REVIEWS2_READ_ONLY'] = 'Запретить изменение рейтинга';
$MESS['WD_REVIEWS2_UNIQ_ID'] = 'Уникальный id рейтинга';
$MESS['WD_REVIEWS2_SCHEMA_ORG'] = 'Использовать микроразметку';
$MESS['WD_REVIEWS2_COUNT'] = 'Количество оценок (для микроразметки)';
?>