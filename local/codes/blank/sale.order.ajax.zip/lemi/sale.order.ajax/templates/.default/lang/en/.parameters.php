<?
$MESS['SOA_FEEDBACK_PHONE'] = 'Feedback phone number';
$MESS['SOA_PATH_TO_FEEDBACK_FORM'] = 'Feedback form page';