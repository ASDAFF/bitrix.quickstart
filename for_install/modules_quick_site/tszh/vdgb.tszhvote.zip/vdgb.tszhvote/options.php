<?
IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/options.php");
IncludeModuleLangFile(__FILE__);

$aTabs = array(
    array(
    "DIV" => "tabMain",
    "TAB" => GetMessage("VOTE_OPTIONS_TAB_MAIN"),
    "ICON" => "search_settings",
    "TITLE" => GetMessage("VOTE_OPTIONS_TAB_TITLE_STATISTIC"),
    "OPTIONS" => Array(

    )

    ),
);

$tabControl = new CAdminTabControl("tabControlSetings", $aTabs);

$aMenu = array(
	array(
		"TEXT"=>GetMessage("VOTE_OPTIONS_MAIN"),
		"LINK"=>"search_reindex.php?lang=".LANGUAGE_ID,
		"TITLE"=>GetMessage("VOTE_OPTIONS_MAIN_TITLE"),
	),
);
$context = new CAdminContextMenu($aMenu);

if($REQUEST_METHOD=="POST"  && check_bitrix_sessid()) {

            
}

$context->Show();

$tabControl->Begin();?>


<?$tabControl->Buttons();?>
    <form method="post" action="<?echo $APPLICATION->GetCurPage()?>?mid=<?=urlencode($mid)?>&amp;lang=<?=LANGUAGE_ID?>">
	<input type="submit" name="UpdateButton" value="<?=GetMessage("MAIN_SAVE")?>" title="<?=GetMessage("MAIN_OPT_SAVE_TITLE")?>">
	<input type="submit" name="ApplyButton" value="<?=GetMessage("MAIN_OPT_APPLY")?>" title="<?=GetMessage("MAIN_OPT_APPLY_TITLE")?>">
	<?=bitrix_sessid_post();?>
    </form>
<?$tabControl->End();?>
