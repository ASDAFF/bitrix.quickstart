<?
	if( !defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true )
		die();

	$MESS['CP_NODE_NAME']   = 'Tuning-Soft';
	$MESS['CP_FOLDER_NAME'] = 'Other';
	$MESS['CP_NAME']        = 'Element filter form';
	$MESS['CP_DESCRIPTION'] = 'Displays elements filter form';