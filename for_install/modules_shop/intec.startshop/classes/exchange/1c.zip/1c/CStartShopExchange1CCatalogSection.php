<?
    class CStartShopExchange1CCatalogSection
    {
        public $Id;
        public $Name;
        public $Groups;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeGroups = $oXmlNode->elementsByName("Группы");
                $oXmlNodeGroups = $oXmlNodeGroups[0];

                if ($oXmlNodeId == null || $oXmlNodeName == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                if (!empty($oXmlNodeGroups))
                    $oInstance->Groups = static::GetListByXmlNodes($oXmlNodeGroups->children());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }

        public static function GetListByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/Классификатор/Группы");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetListByXmlNodes($oXmlNode->children());
            }

            return null;
        }
    }
?>