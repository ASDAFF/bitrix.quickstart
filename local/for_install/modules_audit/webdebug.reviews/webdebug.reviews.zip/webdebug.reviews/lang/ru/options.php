<?
$MESS['WD_REVIEWS2_TAB_0_NAME'] = 'Общие параметры';
$MESS['WD_REVIEWS2_TAB_0_DESC'] = 'Настройка общих параметров модуля';
$MESS['WD_REVIEWS2_TAB_1_NAME'] = 'Поля для голосования (для 1й версии модуля)';
$MESS['WD_REVIEWS2_TAB_1_DESC'] = 'Названия полей для голосования';
$MESS['WD_REVIEWS2_TAB_2_NAME'] = "Доступ";
$MESS['WD_REVIEWS2_TAB_2_DESC'] = "Настройка уровней доступа к модулю";

$MESS['WD_REVIEWS2_SHOW_VERSION_1'] = 'Показывать пункт меню отзывов для 1й версии';
$MESS['WD_REVIEWS2_USE_EPILOG_FOR_SCRIPTS_INCLUDE'] = 'Подключать необходимые скрипты не в прологе, а в эпилоге';
$MESS['WD_REVIEWS2_SKIP_SESSID_CHECK'] = 'Пропускать проверку сессии (check_bitrix_sessid)';
$MESS['WD_REVIEWS2_SHOW_TARGET_LINKS'] = 'Показывать ссылки на объекты в списке отзывов';
$MESS['WD_REVIEWS2_ALLOW_UNREG_VOTING'] = 'Разрешить голосования незарегистрированным пользователям';

$MESS['WD_REVIEWS2_BUTTON_UPDATE_VALUE'] = 'Сохранить';
$MESS['WD_REVIEWS2_BUTTON_APPLY_VALUE'] = 'Применить';
$MESS['WD_REVIEWS2_BUTTON_CANCEL_VALUE'] = 'Отменить';
$MESS['WD_REVIEWS2_ERROR_MODULE_NOT_INCLUDED'] = 'Модуль <b>Простые отзывы</b> не установлен!';
$MESS['WD_REVIEWS2_VOTE_FIELD_NAME'] = 'Поле для голосования #';
?>