<?
$MESS['WEBDEBUG_REVIEWS_INCLUDE_JQUERY'] = 'Автоматически подключать jQuery';
?>