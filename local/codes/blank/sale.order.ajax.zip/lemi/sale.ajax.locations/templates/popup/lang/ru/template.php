<?
$MESS["PUP_NULL"] = "Введите город";
$MESS ['LOC_DEFAULT_NAME_NULL'] = 'другой (ввести руками)';
?>