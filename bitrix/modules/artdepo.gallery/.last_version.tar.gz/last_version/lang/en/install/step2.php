<?
$MESS ['ADG_DEMO_DIR'] = "To see demo go to:";
$MESS ['ADG_TEXT_1'] = "Module succesfully installerd. Admin section for gallery is in menu Service";
$MESS ['ADG_MODULE_NAME'] = "Gallery with multiupload";
?>
