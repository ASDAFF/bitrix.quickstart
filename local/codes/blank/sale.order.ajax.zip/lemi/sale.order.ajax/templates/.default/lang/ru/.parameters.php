<?
$MESS['SOA_FEEDBACK_PHONE'] = 'Телефон для обратной связи';
$MESS['SOA_PATH_TO_FEEDBACK_FORM'] = 'Страница формы обратной связи';
