<?
    class CStartShopExchange1CCatalogIBlock
    {
        public $Id;
        public $Name;
        public $IsOnlyChanges = false;

        public static function GetByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/Каталог");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetByXmlNode($oXmlNode);
            }

            return null;
        }

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeIsOnlyChanges = $oXmlNode->getAttribute("СодержитТолькоИзменения");
                $oXmlNodeIsOnlyChanges = $oXmlNodeIsOnlyChanges[0];

                if ($oXmlNodeId == null || $oXmlNodeName == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                if ($oXmlNodeIsOnlyChanges->textContent == "true")
                    $oInstance->IsOnlyChanges = true;

                return $oInstance;
            }

            return null;
        }
    }
?>