<?
$MESS["COUNTRY_INPUT_NAME_TIP"] = "Formos lauko, kuriame bus įrašyta šalis, pavadinimas.";
$MESS["CITY_INPUT_NAME_TIP"] = "Formos lauko, kuriame bus įrašytas miestas arba vieta, pavadinimas.";
$MESS["COUNTRY_TIP"] = "Čia pasirinkite šalį, kuri bus rodomas pirma sąraše.";
$MESS["CITY_OUT_LOCATION_TIP"] = "Pažymėjus, peržiūros programa grąžins vietos ID.";
$MESS["ONCITYCHANGE_TIP"] = "Nurodo miesto pasirinkimo įvykio tvarkymo programos pavadinimą.";
?>