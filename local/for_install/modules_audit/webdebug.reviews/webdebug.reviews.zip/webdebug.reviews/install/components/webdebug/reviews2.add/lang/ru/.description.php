<?
$MESS['WD_REVIEWS2_COMPONENT_NAME'] = 'Добавление отзыва';
$MESS['WD_REVIEWS2_COMPONENT_DESC'] = 'Форма для добавления отзыва к товарам, новостям, другим элементам инфоблока, а также к другим объектам и статическим страницам.';
$MESS['WD_REVIEWS2_COMPONENT_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WD_REVIEWS2_COMPONENT_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>