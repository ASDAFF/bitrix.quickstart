<?
$arModuleVersion = array(
	"VERSION" => "2.0.22",
	"VERSION_DATE" => "2015-06-18 10:00:00"
);
?>