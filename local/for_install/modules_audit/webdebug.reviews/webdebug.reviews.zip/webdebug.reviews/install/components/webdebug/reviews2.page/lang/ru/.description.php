<?
$MESS['WD_REVIEWS2_COMP_NAME'] = 'Страница с отзывами';
$MESS['WD_REVIEWS2_COMP_DESC'] = 'Компонент реализует совместный функционал списка отзывов и формы добавления отзыва для товаров, новостей, других элементов инфоблока, а также для других объектов и статических страниц.';
$MESS['WD_REVIEWS2_COMP_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WD_REVIEWS2_COMP_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>