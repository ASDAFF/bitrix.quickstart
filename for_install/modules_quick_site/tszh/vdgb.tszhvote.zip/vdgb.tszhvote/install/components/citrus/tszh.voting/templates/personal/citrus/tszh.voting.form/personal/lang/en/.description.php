<?
$MESS ['VOTE_DOT_DEFAULT_NAME'] = "Template for the personal area";
$MESS ['VOTE_DOT_DEFAULT_DESC'] = "Template for the personal area";
?>