<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

CPageOption::SetOptionString("main", "nav_page_in_session", "N");

if (!CModule::IncludeModule("vdgb.tszhvote"))
{
	ShowError(GetMessage("VOTE_MODULE_IS_NOT_INSTALLED"));
	return;
}

$arParams["PAGER_TITLE"] = trim($arParams["PAGER_TITLE"]);
$arParams["PAGER_SHOW_ALWAYS"] = $arParams["PAGER_SHOW_ALWAYS"]!="N";
$arParams["PAGER_TEMPLATE"] = trim($arParams["PAGER_TEMPLATE"]);
$arParams["PAGER_DESC_NUMBERING"] = $arParams["PAGER_DESC_NUMBERING"]=="Y";
$arParams["PAGER_DESC_NUMBERING_CACHE_TIME"] = intval($arParams["PAGER_DESC_NUMBERING_CACHE_TIME"]);
$arParams["PAGER_SHOW_ALL"] = $arParams["PAGER_SHOW_ALL"]!=="N";

$arParams["VOTES_COUNT"] = intval($arParams["VOTES_COUNT"]);
if($arParams["VOTES_COUNT"]<=0)
	$arParams["VOTES_COUNT"] = 10;

$arParams["GROUP_ID"] = IntVal($arParams['GROUP_ID']) > 0 ? IntVal($arParams['GROUP_ID']) : 0;
$arParams["LIMIT_FIELD_NAME"] = trim(htmlspecialcharsbx($arParams["LIMIT_FIELD_NAME"]));
if ($arParams["LIMIT_FIELD_NAME"] == '-' || strlen($arParams["LIMIT_FIELD_NAME"]) <= 0)
	 $arParams["LIMIT_FIELD_NAME"] = false;
$arParams["LIMIT_FIELD_VALUE"] = trim($arParams['LIMIT_FIELD_VALUE']);


$arResult["VOTINGS"] = Array();

$arFilter = Array(
	"GROUP_ID" => $arParams["GROUP_ID"],
	"ACTIVE" => "Y",
);
if ($arParams["LIMIT_FIELD_NAME"])
	$arFilter[$arParams["LIMIT_FIELD_NAME"]] = $arParams["LIMIT_FIELD_VALUE"];

$arNavParams = array(
	"nPageSize" => $arParams["VOTES_COUNT"],
	"bDescPageNumbering" => $arParams["PAGER_DESC_NUMBERING"],
	"bShowAll" => $arParams["PAGER_SHOW_ALL"],
);
// for cache key
//$arNavigation = CDBResult::GetNavParams($arNavParams);
$rsVotings = CCitrusPoll::GetList(Array("DATE_BEGIN" => "DESC"), $arFilter, false, $arNavParams);
while ($arVoting = $rsVotings->GetNext(false))
{
	$arResult["VOTINGS"][] = $arVoting;
}
$arResult["NAV_STRING"] = $rsVotings->GetPageNavStringEx($navComponentObject, $arParams["PAGER_TITLE"], $arParams["PAGER_TEMPLATE"], $arParams["PAGER_SHOW_ALWAYS"]);
$arResult["NAV_CACHED_DATA"] = $navComponentObject->GetTemplateCachedData();
$arResult["NAV_RESULT"] = $rsVotings;

$this->IncludeComponentTemplate();

?>