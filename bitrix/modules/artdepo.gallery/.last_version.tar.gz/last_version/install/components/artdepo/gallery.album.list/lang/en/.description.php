<?
$MESS ['T_ARTDEPO_GALLERY_ALBUM_DESC_LIST'] = "Album list";
$MESS ['T_ARTDEPO_GALLERY_ALBUM_DESC_LIST_DESC'] = "The album list in sertain section";
$MESS ['T_ARTDEPO_DESC_GALLERY'] = "Gallery";
?>
