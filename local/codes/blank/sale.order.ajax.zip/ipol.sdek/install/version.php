<?
$arModuleVersion = array(
	"VERSION" => "3.8.1",
	"VERSION_DATE" => "2019-08-22 15:56:15"
);
?>