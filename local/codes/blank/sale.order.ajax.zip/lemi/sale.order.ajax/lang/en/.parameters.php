<?
$MESS['SBB_DELIVERY_PAYSYSTEM'] = 'Sequence of ordering process';
$MESS['SBB_TITLE_PD'] = 'Delivery -> Payment';
$MESS['SBB_TITLE_DP'] = 'Payment -> Delivery';
$MESS['SOA_DELIVERY_NO_AJAX'] = 'Immediate delivery calculation';
$MESS['SOA_ALLOW_PAY_FROM_ACCOUNT'] = 'Allow Payment from Internal Account';
$MESS['SOA_ONLY_FULL_PAY_FROM_ACCOUNT'] = 'Disallow Partial Payments from Internal Accounts';
$MESS['SBB_USE_PREPAYMENT'] = 'Use PayPal Express Checkout';
$MESS['SOA_DISABLE_BASKET_REDIRECT'] = 'Don\'t redirect if the cart is empty';
$MESS['SOA_SEND_NEW_USER_NOTIFY'] = 'Notify User Of Their Registration';
$MESS['SOA_PATH_TO_BASKET'] = 'Shopping Cart Page';
$MESS['PATH_TO_CATALOG'] = 'Catalog start Page';
$MESS['SOA_PATH_TO_PAYMENT'] = 'Payment System Page';
$MESS['SOA_PATH_TO_PERSONAL'] = 'User Personal Page';
$MESS['SOA_PATH_TO_ORDERS_LIST'] = 'Users orders List Page';
$MESS['SOA_DELIVERY_GROUPS'] = 'Properties groups for delivery setup';
$MESS['SOA_PAY_SYSTEMS_ONLINE'] = 'Online payment systems';