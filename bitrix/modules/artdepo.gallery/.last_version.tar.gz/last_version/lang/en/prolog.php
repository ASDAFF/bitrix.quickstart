<?
$MESS ['ACCESS_DENIED'] = "Access denie";
?>
