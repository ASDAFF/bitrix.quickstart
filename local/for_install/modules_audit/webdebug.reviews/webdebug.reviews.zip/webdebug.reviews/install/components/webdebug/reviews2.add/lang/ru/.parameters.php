<?
$MESS['WD_REVIEWS2_INTERFACE'] = 'Интерфейс';
$MESS['WD_REVIEWS2_TARGET_TYPE'] = 'Тип объекта';
	$MESS['WD_REVIEWS2_TARGET_TYPE_DEFAULT'] = '--- по умолчанию ---';
	$MESS['WD_REVIEWS2_TARGET_TYPE_ELEMENT'] = 'элемент инфоблока';
$MESS['WD_REVIEWS2_TARGET'] = 'Объект';
$MESS['WD_REVIEWS2_MANUAL_CSS_INCLUDE'] = 'Подключать CSS нестандартным способом';
$MESS['WD_REVIEWS2_MINIMIZE_FORM'] = 'Сворачивать форму по умолчанию';

?>