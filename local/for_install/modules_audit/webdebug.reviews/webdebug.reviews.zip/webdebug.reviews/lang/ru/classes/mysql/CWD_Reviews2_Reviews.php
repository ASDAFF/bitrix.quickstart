<?
$MESS['WD_REVIEWS2_REVIEW_ERROR_NO_INTERFACE'] = 'Не указан интерфейс';
$MESS['WD_REVIEWS2_REVIEW_ERROR_NO_TARGET'] = 'Не указан объект для отзыва';
$MESS['WD_REVIEWS2_REVIEW_ERROR_NO_INTERFACE_GET'] = 'Невозможно определить интерфейс';
$MESS['WD_REVIEWS2_REVIEW_ERROR_NO_RATINGS'] = 'Заполните рейтинг.';

$MESS['WD_REVIEWS2_IBLOCK_PROP_COUNT'] = 'Количество отзывов';
$MESS['WD_REVIEWS2_IBLOCK_PROP_RATING'] = 'Средний рейтинг';
$MESS['WD_REVIEWS2_IBLOCK_PROP_LAST'] = 'Дата последнего изменения рейтинга';
?>