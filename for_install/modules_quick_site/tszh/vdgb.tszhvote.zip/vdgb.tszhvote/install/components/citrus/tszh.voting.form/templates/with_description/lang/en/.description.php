<?
$MESS ['VOTE_WITH_DESC_NAME'] = "Template with poll description";
$MESS ['VOTE_WITH_DESC_DESC'] = "Template with poll description";
?>