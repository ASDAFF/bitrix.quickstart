<?
$MESS ['ARTDEPO_GALLERY_MENU_MAIN'] = "Gallery with multiupload";
?>
