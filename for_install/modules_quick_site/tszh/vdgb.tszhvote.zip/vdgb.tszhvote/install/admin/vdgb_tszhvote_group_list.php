<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vdgb.tszhvote/admin/vdgb_tszhvote_group_list.php");?>
