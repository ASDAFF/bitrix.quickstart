<?

$MESS['WD_REVIEWS2_ERROR_NO_FIELDS'] = 'Не создано ни одного поля';
$MESS['WD_REVIEWS2_ERROR_NO_EMAIL_FIELD'] = 'Не создано ни одного поля, используемого как e-mail';
$MESS['WD_REVIEWS2_ERROR_NO_REVIEW_FIELD'] = 'Не создано ни одного поля, используемого как отзыв или комментарий';
$MESS['WD_REVIEWS2_ERROR_TOO_MAY_EMAIL_FIELDS'] = 'Создано более одного поля, используемого как e-mail';
$MESS['WD_REVIEWS2_ERROR_TOO_MAY_NAME_FIELDS'] = 'Создано более одного поля, используемого как имя пользователя';
$MESS['WD_REVIEWS2_ERROR_TOO_MAY_REVIEW_FIELDS'] = 'Создано более одного поля, используемого как отзыв или комментарий';
$MESS['WD_REVIEWS2_ERROR_SAVE'] = 'Ошибка при сохранении';

$MESS['WD_REVIEWS2_BTN_ADD'] = 'Добавить';
$MESS['WD_REVIEWS2_BTN_REFRESH'] = 'Обновить список';

$MESS['WD_REVIEWS2_FIELD_NAME'] = 'Название';
$MESS['WD_REVIEWS2_FIELD_TYPE'] = 'Тип';
$MESS['WD_REVIEWS2_FIELD_CODE'] = 'Код';
$MESS['WD_REVIEWS2_FIELD_REQUIRED'] = 'Обяз.';
$MESS['WD_REVIEWS2_FIELD_HIDDEN'] = 'Скрыто';
$MESS['WD_REVIEWS2_FIELD_SORT'] = 'Сорт.';

$MESS['WD_REVIEWS2_FIELDS_COUNT'] = 'Всего рейтингов';

$MESS['WD_REVIEWS2_FIELDS_POPUP_ADD'] = 'Создание нового поля в форме добавления отзыва';
$MESS['WD_REVIEWS2_FIELDS_POPUP_EDIT'] = 'Редактирование поля в форме добавления отзыва';
$MESS['WD_REVIEWS2_FIELDS_POPUP_SAVE'] = 'Сохранить';
$MESS['WD_REVIEWS2_FIELDS_POPUP_CANCEL'] = 'Отменить';

$MESS['WD_REVIEWS2_FIELDS_EDIT'] = 'Ред.';
$MESS['WD_REVIEWS2_FIELDS_DELETE'] = 'Уд.';
$MESS['WD_REVIEWS2_FIELDS_DELETE_CONFIRM'] = 'Удалить данное поле?';

?>