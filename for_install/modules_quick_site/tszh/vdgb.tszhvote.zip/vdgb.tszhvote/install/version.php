<?
    $arModuleVersion = array(
            "VERSION" => "1.0.3",
            "VERSION_DATE" => "2014-10-31 11:15:00"
    );
?>
