<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/artdepo.gallery/admin/artdepo_gallery_section_admin.php");
?>
