<?
$MESS['WEBDEBUG_REVIEWS_HEADER'] = 'Отзывы о ';
$MESS['WEBDEBUG_REVIEWS_NO_ITEMS'] = 'Вы можете стать первым, кто оставит отзыв о <strong>%s</strong>';
?>