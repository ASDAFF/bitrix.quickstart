<?
    class CStartShopExchange1CCatalogItem
    {
        public $Id;
        public $Name;
        public $Article;
        public $Groups;
        public $Pictures;
        public $Properties;
        public $Description;
        public $Traits;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeArticle = $oXmlNode->elementsByName("Артикул");
                $oXmlNodeArticle = $oXmlNodeArticle[0];
                $oXmlNodeGroups = $oXmlNode->elementsByName("Группы");
                $oXmlNodeGroups = $oXmlNodeGroups[0];
                $oXmlNodeProperties = $oXmlNode->elementsByName("ЗначенияСвойств");
                $oXmlNodeProperties = $oXmlNodeProperties[0];
                $oXmlNodeTraits = $oXmlNode->elementsByName("ЗначенияРеквизитов");
                $oXmlNodeTraits = $oXmlNodeTraits[0];
                $oXmlNodeDescription = $oXmlNode->elementsByName("Описание");
                $oXmlNodeDescription = $oXmlNodeDescription[0];

                $arXmlNodePictures = $oXmlNode->elementsByName("Картинка");

                if ($oXmlNodeId == null || $oXmlNodeName == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());

                if (!empty($oXmlNodeArticle))
                    $oInstance->Article = CStartShopUtil::ConvertToSiteCharset($oXmlNodeArticle->textContent());

                if (!empty($oXmlNodeDescription))
                    $oInstance->Description = CStartShopUtil::ConvertToSiteCharset($oXmlNodeDescription->textContent());

                if (!empty($oXmlNodeGroups)) {
                    $oGroups = $oXmlNodeGroups->children();

                    if (!empty($oGroups)) {
                        $oInstance->Groups = array();

                        foreach ($oGroups as $oGroup)
                            $oInstance->Groups[] = CStartShopUtil::ConvertToSiteCharset($oGroup->textContent());
                    }

                    unset($oGroup, $oGroups);
                }

                if (!empty($arXmlNodePictures)) {
                    $oInstance->Pictures = array();

                    foreach ($arXmlNodePictures as $oXmlNodePicture)
                        $oInstance->Pictures[] = CStartShopUtil::ConvertToSiteCharset($oXmlNodePicture->textContent());
                }

                if ($oXmlNodeProperties != null)
                    $oInstance->Properties = CStartShopExchange1CCatalogItemProperty::GetListByXmlNodes($oXmlNodeProperties->children());

                if ($oXmlNodeTraits != null)
                    $oInstance->Traits = CStartShopExchange1CCatalogItemTrait::GetListByXmlNodes($oXmlNodeTraits->children());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }

        public static function GetListByXml(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $oXmlNode = $oXml->SelectNodes("/КоммерческаяИнформация/Каталог/Товары");

                if ($oXmlNode instanceof CDataXMLNode)
                    return static::GetListByXmlNodes($oXmlNode->children());
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogItemProperty
    {
        public $Id;
        public $Value;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeId = $oXmlNode->elementsByName("Ид");
                $oXmlNodeId = $oXmlNodeId[0];
                $oXmlNodeValue = $oXmlNode->elementsByName("Значение");
                $oXmlNodeValue = $oXmlNodeValue[0];

                if ($oXmlNodeId == null || $oXmlNodeValue == null)
                    return null;

                $oInstance = new static;
                $oInstance->Id = CStartShopUtil::ConvertToSiteCharset($oXmlNodeId->textContent());
                $oInstance->Value = CStartShopUtil::ConvertToSiteCharset($oXmlNodeValue->textContent());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[$oInstance->Id] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }
    }

    class CStartShopExchange1CCatalogItemTrait
    {
        public $Name;
        public $Value;

        public static function GetByXmlNode(&$oXmlNode) {
            if ($oXmlNode instanceof CDataXMLNode) {
                $oXmlNodeName = $oXmlNode->elementsByName("Наименование");
                $oXmlNodeName = $oXmlNodeName[0];
                $oXmlNodeValue = $oXmlNode->elementsByName("Значение");
                $oXmlNodeValue = $oXmlNodeValue[0];

                if ($oXmlNodeName == null || $oXmlNodeValue == null)
                    return null;

                $oInstance = new static;
                $oInstance->Name = CStartShopUtil::ConvertToSiteCharset($oXmlNodeName->textContent());
                $oInstance->Value = CStartShopUtil::ConvertToSiteCharset($oXmlNodeValue->textContent());

                return $oInstance;
            }

            return null;
        }

        public static function GetListByXmlNodes(&$arXmlNodes) {
            if (is_array($arXmlNodes)) {
                $arList = array();

                foreach ($arXmlNodes as &$oXmlNode) {
                    $oInstance = static::GetByXmlNode($oXmlNode);

                    if ($oInstance != null)
                        $arList[] = $oInstance;
                }

                if (!empty($arList))
                    return $arList;
            }

            return null;
        }
    }
?>