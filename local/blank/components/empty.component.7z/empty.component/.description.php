<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	'NAME' => 'Имя',
	'DESCRIPTION' => 'Описание',
	'ICON' => '/images/icon.gif',
	'SORT' => 90,
	'CACHE_PATH' => 'Y',
	'PATH' => array(
		'ID' => 'new_path',
		'NAME' => 'Тестовый раздел'
	),
);

?>
