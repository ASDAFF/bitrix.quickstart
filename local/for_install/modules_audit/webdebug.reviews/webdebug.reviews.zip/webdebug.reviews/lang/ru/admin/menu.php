<?
$MESS['WEBDEBUG_REVIEWS_MENU_NAME'] = "Отзывы (старая версия)";
$MESS['WEBDEBUG_REVIEWS_MENU_DESC'] = "Просмотр и модерация отзывов из первой версии модуля.";

$MESS['WD_REVIEWS2_GROUP'] = 'Отзывы';
$MESS['WD_REVIEWS2_INTERFACES'] = 'Настройка';

?>