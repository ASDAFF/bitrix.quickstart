<?
$MESS["VOTE_POLL_ID"] = "Poll ID";
$MESS["VOTE_TEMPLATE_FOR_QUESTION"] = "Chart type for question \"#QUESTION#\"";
$MESS["VOTE_BY_DEFAULT"] = "<by default>";
$MESS["VOTE_ALL_RESULTS"] = "Show All Results";
?>