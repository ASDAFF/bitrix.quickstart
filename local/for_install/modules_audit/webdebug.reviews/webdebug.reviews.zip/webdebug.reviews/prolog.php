<?
define('ADMIN_MODULE_NAME', 'webdebug.reviews');
?>