<?
$MESS['WEBDEBUG_REVIEWS_COMPONENT_NAME'] = 'Список отзывов(старая версия)';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_DESC'] = 'Вывод списка отзывов к товару, новости и другим элементам инфоблока';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>