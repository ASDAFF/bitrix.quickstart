<?
$MESS["IPOLSDEK_YOURCITY"] = "Ваш город:&nbsp;";

$MESS["IPOLSDEK_COURIER"] = "Курьер:";
$MESS["IPOLSDEK_PICKUP"] = "Самовывоз:";

$MESS["IPOLSDEK_DELTERM"] = "<strong>Срок:</strong> ";
$MESS["IPOLSDEK_DAY"] = " дн.";

$MESS["IPOLSDEK_NO_DELIV"] = "Нет доставки.";

$MESS["IPOLSDEK_CITYSEARCH"] = "Поиск города";

$MESS["IPOLSDEK_TEMPL_ALL"] = "Все";
$MESS["IPOLSDEK_TEMPL_PVZ"] = "Пункты выдачи";
$MESS["IPOLSDEK_TEMPL_POSTOMAT"] = "Почтоматы";
?>