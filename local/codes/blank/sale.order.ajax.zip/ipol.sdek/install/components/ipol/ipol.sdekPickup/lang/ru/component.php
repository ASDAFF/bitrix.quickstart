<?
$MESS["IPOLSDEK_MOSCOW"] = "Москва";
$MESS["IPOLSDEK_RUSSIA"] = "Россия";
$MESS["IPOLSDEK_LABELPVZ"] = "Пункты самовывоза";
$MESS["IPOLSDEK_DELIVERY"] = "Доставка: ";

$MESS["IPOLSDEK_CMP_PRICE"] = "Стоимость";
$MESS["IPOLSDEK_CMP_TRM"] = "срок";
$MESS["IPOLSDEK_CMP_RUB"] = "руб.";
$MESS["IPOLSDEK_CMP_DAY"] = "дн.";
?>