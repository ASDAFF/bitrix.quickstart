<?
$MESS ['COUNTRY_INPUT_NAME_TIP'] = "The name of a form field to contain the country name.";
$MESS ['CITY_INPUT_NAME_TIP'] = "The name of a form field to contain the city or location name.";
$MESS ['COUNTRY_TIP'] = "Select here the country that will be displayed first in the list.";
$MESS ['CITY_OUT_LOCATION_TIP'] = "If checked, the services will return the location ID.";
$MESS ['ONCITYCHANGE_TIP'] = "Specifies the name of the <b>city selection</b> event services.";
?>