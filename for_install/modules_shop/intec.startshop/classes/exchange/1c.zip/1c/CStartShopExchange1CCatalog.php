<?
    IncludeModuleLangFile(__FILE__);

    define("STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING", 0);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DEACTIVATE", 1);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DELETE", 2);

    define("STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_PRODUCTS", 0);
    define("STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_OFFERS", 1);

    class CStartShopExchange1CCatalog
    {
        /**
         * @param CDataXML $oXml
         * @param string $sIBlockType
         * @param bool $bSynchronizeName
         * @return array
         */
        public static function ImportIBlocks(&$oXml, $sIBlockType, $bSynchronizeName = true) {
            $oXmlIBlock = CStartShopExchange1CCatalogIBlock::GetByXml($oXml);
            $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

            if ($oXmlIBlock != null && !empty($sIBlockType)) {

                $arSites = CStartShopUtil::DBResultToArray(CSite::GetList($by = "sort", $order = "asc"), "ID");

                $arIBlockFields = array(
                    "IBLOCK_TYPE_ID" => $sIBlockType,
                    "EXTERNAL_ID" => $oXmlIBlock->Id,
                    "NAME" => $oXmlIBlock->Name,
                    "SITE_ID" => array(),
                    "ACTIVE" => "Y"
                );

                $arIBlockOffersFields = array(
                    "IBLOCK_TYPE_ID" => $sIBlockType,
                    "EXTERNAL_ID" => $oXmlIBlock->Id."_offers",
                    "NAME" => $oXmlIBlock->Name." (".GetMessage("IBLOCK_OFFERS_PREFIX").")",
                    "SITE_ID" => array(),
                    "ACTIVE" => "Y"
                );

                foreach ($arSites as $arSite) {
                    $arIBlockFields["SITE_ID"][] = $arSite["ID"];
                    $arIBlockOffersFields["SITE_ID"][] = $arSite["ID"];
                }

                $arIBlock = CIBlock::GetList(array(), array("EXTERNAL_ID" => $arIBlockFields["EXTERNAL_ID"]))->Fetch();
                $arIBlockOffers = CIBlock::GetList(array(), array("EXTERNAL_ID" => $arIBlockOffersFields["EXTERNAL_ID"]))->Fetch();
                $oIBlock = new CIBlock();

                if (empty($arIBlock)) {
                    $oIBlock->Add($arIBlockFields);
                } else {
                    $arIBlockFieldsUpdate = array();

                    if ($arIBlockFields["IBLOCK_TYPE_ID"] != $arIBlock["IBLOCK_TYPE_ID"])
                        $arIBlockFieldsUpdate["IBLOCK_TYPE_ID"] = $arIBlockFields["IBLOCK_TYPE_ID"];

                    if ($bSynchronizeName && $arIBlockFields["NAME"] != $arIBlock["NAME"])
                        $arIBlockFieldsUpdate["NAME"] = $arIBlockFields["NAME"];

                    if (!empty($arIBlockFieldsUpdate))
                        $oIBlock->Update($arIBlock["ID"], $arIBlockFieldsUpdate);

                    unset($arIBlockFieldsUpdate);
                }

                if (empty($arIBlockOffers)) {
                    $oIBlock->Add($arIBlockOffersFields);
                } else {
                    $arIBlockOffersFieldsUpdate = array();

                    if ($arIBlockOffersFields["IBLOCK_TYPE_ID"] != $arIBlockOffers["IBLOCK_TYPE_ID"])
                        $arIBlockOffersFieldsUpdate["IBLOCK_TYPE_ID"] = $arIBlockOffersFields["IBLOCK_TYPE_ID"];

                    if ($bSynchronizeName && $arIBlockOffersFields["NAME"] != $arIBlockOffers["NAME"])
                        $arIBlockOffersFieldsUpdate["NAME"] = $arIBlockOffersFields["NAME"];

                    if (!empty($arIBlockOffersFieldsUpdate))
                        $oIBlock->Update($arIBlock["ID"], $arIBlockOffersFieldsUpdate);

                    unset($arIBlockOffersFieldsUpdate);
                }

                $arIBlock = CIBlock::GetList(array(), array("EXTERNAL_ID" => $arIBlockFields["EXTERNAL_ID"]))->Fetch();
                $arIBlockOffers = CIBlock::GetList(array(), array("EXTERNAL_ID" => $arIBlockOffersFields["EXTERNAL_ID"]))->Fetch();

                unset($arIBlockFields, $arIBlockOffersFields);

                if (empty($arIBlock) || empty($arIBlockOffers))
                    return null;

                if (CStartShopCatalog::GetByIBlock($arIBlock["ID"])->Fetch()) {
                    CStartShopCatalog::Update($arIBlock["ID"], array("OFFERS_IBLOCK" => $arIBlockOffers["ID"]));
                } else {
                    CStartShopCatalog::Add(array(
                        "IBLOCK" => $arIBlock["ID"],
                        "USE_QUANTITY" => 1,
                        "OFFERS_IBLOCK" => $arIBlockOffers["ID"]
                    ));
                }

                $arCatalog = CStartShopCatalog::GetByIBlock($arIBlock["ID"])->Fetch();

                if (empty($arCatalog))
                    return null;

                CStartShopToolsIBlock::CheckOffersLink($arIBlock["ID"], true);

                return array(
                    "CATALOG" => $arIBlock,
                    "CATALOG_OFFERS" => $arIBlockOffers
                );
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @param array $arIBlock
         * @param int $eSectionAction
         * @param bool $bSynchronizeName
         * @return array
         */
        public static function ImportSections(&$oXml, &$arIBlock, $eSectionAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING, $bSynchronizeName = true) {
            if ($oXml instanceof CDataXML && !empty($arIBlock)) {
                $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);
                $arXmlSections = CStartShopExchange1CCatalogSection::GetListByXml($oXml);
                $arXmlSectionsTreated = array();

                $arIBlockSections = CStartShopUtil::DBResultToArray(CIBlockSection::GetList(
                    array(),
                    array("IBLOCK_ID" => $arIBlock["ID"])
                ), 'EXTERNAL_ID');

                if ($arXmlSections != null)
                    $arXmlSectionsTreated = static::ImportXmlSections($arIBlock, $arIBlockSections, $arXmlSections, null, $bSynchronizeName);

                if ($bIsOnlyChanges)
                    $eSectionAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING;

                if ($eSectionAction != STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING) {
                    $arIBlockSections = CStartShopUtil::DBResultToArray(CIBlockSection::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"])
                    ), 'ID');

                    $oIBlockSection = new CIBlockSection();

                    foreach ($arIBlockSections as $arIBlockSection) {
                        if (!empty($arIBlockSection["EXTERNAL_ID"]))
                            if (array_key_exists($arIBlockSection["EXTERNAL_ID"], $arXmlSectionsTreated)) continue;

                        if ($eSectionAction == STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DELETE) {
                            $oIBlockSection->Delete($arIBlockSection["ID"]);
                        } else {
                            $oIBlockSection->Update($arIBlockSection["ID"], array("ACTIVE" => "N"));
                        }
                    }

                    unset($oIBlockSection);
                }

                $oIBlockSection = new CIBlockSection();
                $oIBlockSection->ReSort($arIBlock["ID"]);
                $oIBlockSection->TreeReSort($arIBlock["ID"]);

                unset($oIBlockSection);

                return CStartShopUtil::DBResultToArray(CIBlockSection::GetList(
                    array(),
                    array("IBLOCK_ID" => $arIBlock["ID"])
                ), 'ID');
            }

            return null;
        }

        /**
         * @param array $arIBlock
         * @param array $arIBlockSections
         * @param array $arXmlSections
         * @param null $oXmlSectionParent
         * @param bool $bSynchronizeName
         * @return array
         */
        public static function ImportXmlSections(&$arIBlock, &$arIBlockSections, &$arXmlSections, $oXmlSectionParent = null, $bSynchronizeName = true) {
            $arXmlSectionsTreated = array();

            if (is_array($arXmlSections))
                foreach ($arXmlSections as $oXmlSection)
                    if ($oXmlSection instanceof CStartShopExchange1CCatalogSection) {
                        $arIBlockSection = $arIBlockSections[$oXmlSection->Id];
                        $arIBlockSectionParent = array();

                        if ($oXmlSectionParent instanceof CStartShopExchange1CCatalogSection) {
                            $arIBlockSectionParent = $arIBlockSections[$oXmlSectionParent->Id];
                        }

                        $oIBlockSection = new CIBlockSection();

                        if (!empty($arIBlockSection)) {
                            $arIBlockSectionFields = array();

                            if (!empty($arIBlockSectionParent))
                                $arIBlockSectionFields["IBLOCK_SECTION_ID"] = $arIBlockSectionParent["ID"];

                            if ($oXmlSection->Name != $arIBlockSection["NAME"] && $bSynchronizeName)
                                $arIBlockSectionFields["NAME"] = $oXmlSection->Name;

                            if (!empty($arIBlockSectionFields))
                                $oIBlockSection->Update($arIBlockSection["ID"], $arIBlockSectionFields);

                            unset($arIBlockSectionFields);
                        } else {
                            $arIBlockSectionFields = array(
                                "IBLOCK_ID" => $arIBlock["ID"],
                                "EXTERNAL_ID" => $oXmlSection->Id,
                                "NAME" => $oXmlSection->Name
                            );

                            if (!empty($arIBlockSectionParent))
                                $arIBlockSectionFields["IBLOCK_SECTION_ID"] = $arIBlockSectionParent["ID"];

                            $oIBlockSection->Add($arIBlockSectionFields, false, false);

                            unset($arIBlockSectionFields);
                        }

                        $arXmlSectionsTreated[$oXmlSection->Id] = $oXmlSection;

                        unset($oIBlockSection, $arIBlockSection);

                        if ($oXmlSection->Groups != null) {
                            $arIBlockSections = CStartShopUtil::DBResultToArray(CIBlockSection::GetList(
                                array(),
                                array("IBLOCK_ID" => $arIBlock["ID"])
                            ), 'EXTERNAL_ID');

                            $arXmlSectionsTreated = array_merge(
                                $arXmlSectionsTreated,
                                static::ImportXmlSections($arIBlock, $arIBlockSections, $oXmlSection->Groups, $oXmlSection, $bSynchronizeName)
                            );
                        }
                    }

            return $arXmlSectionsTreated;
        }

        /**
         * @param CDataXML $oXml
         * @param array $arIBlock
         * @param int $ePropertyAction
         * @param bool $bSynchronizeName
         * @param array $arPropertiesExcluded
         * @param string $sPropertyPictures
         * @param string $sPropertyArticle
         * @param string $sPropertyTraits
         * @return array|null
         */
        public static function ImportProperties(&$oXml, &$arIBlock, $ePropertyAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING, $bSynchronizeName = true, $arPropertiesExcluded = array(), $sPropertyArticle = null, $sPropertyPictures = null, $sPropertyTraits = null) {
            if ($oXml instanceof CDataXML && !empty($arIBlock)) {
                $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);
                $arXmlProperties = CStartShopExchange1CCatalogProperty::GetListByXml($oXml);
                $arXmlPropertiesTreated = array();

                $arIBlockProperties = CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(
                    array(),
                    array("IBLOCK_ID" => $arIBlock["ID"])
                ), "XML_ID");

                if ($arXmlProperties != null)
                    foreach ($arXmlProperties as $oXmlProperty)
                        if ($oXmlProperty instanceof CStartShopExchange1CCatalogProperty) {
                            $oIBlockProperty = new CIBlockProperty();

                            $arIBlockProperty = $arIBlockProperties[$oXmlProperty->Id];
                            $arIBlockPropertyFields = array();

                            if ($oXmlProperty->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_STRING) {
                                $arIBlockPropertyFields = array(
                                    "PROPERTY_TYPE" => "S",
                                    "USER_TYPE" => false
                                );
                            } else if ($oXmlProperty->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_NUMBER) {
                                $arIBlockPropertyFields = array(
                                    "PROPERTY_TYPE" => "N",
                                    "USER_TYPE" => false
                                );
                            } else if ($oXmlProperty->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_DATETIME) {
                                $arIBlockPropertyFields = array(
                                    "PROPERTY_TYPE" => "S",
                                    "USER_TYPE" => "DateTime"
                                );
                            } else if ($oXmlProperty->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_LIST) {
                                $arIBlockPropertyFields = array(
                                    "PROPERTY_TYPE" => "L",
                                    "USER_TYPE" => false
                                );
                            }

                            if (!empty($arIBlockProperty)) {
                                if ($arIBlockProperty['NAME'] != $oXmlProperty->Name && $bSynchronizeName)
                                    $arIBlockPropertyFields['NAME'] = $oXmlProperty->Name;

                                $oIBlockProperty->Update($arIBlockProperty["ID"], $arIBlockPropertyFields);
                                $arIBlockProperty = CIBlockProperty::GetByID($arIBlockProperty["ID"])->Fetch();
                            } else {
                                $arIBlockPropertyFields["IBLOCK_ID"] = $arIBlock["ID"];
                                $arIBlockPropertyFields["XML_ID"] = $oXmlProperty->Id;
                                $arIBlockPropertyFields["NAME"] = $oXmlProperty->Name;
                                $iIBlockPropertyID = $oIBlockProperty->Add($arIBlockPropertyFields);
                                $arIBlockProperty = CIBlockProperty::GetByID($iIBlockPropertyID)->Fetch();
                                unset($iIBlockPropertyID);
                            }

                            if (empty($arIBlockProperty))
                                continue;

                            static::ImportPropertyValues($arIBlockProperty, $oXmlProperty, $bIsOnlyChanges);

                            $arXmlPropertiesTreated[$oXmlProperty->Id] = $oXmlProperty;
                        }

                $oIBlockProperty = new CIBlockProperty();

                if (!is_array($arPropertiesExcluded))
                    $arPropertiesExcluded = array();

                if (!empty($sPropertyPictures)) {
                    $arPropertiesExcluded[] = '^'.preg_quote($sPropertyPictures).'$';

                    $arPropertyPictures = CIBlockProperty::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"], "CODE" => $sPropertyPictures)
                    )->Fetch();

                    if (!empty($arPropertyPictures)) {
                        $oIBlockProperty->Update($arPropertyPictures["ID"], array(
                            "PROPERTY_TYPE" => "F",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "Y"
                        ));
                    } else {
                        $oIBlockProperty->Add(array(
                            "IBLOCK_ID" => $arIBlock["ID"],
                            "CODE" => $sPropertyPictures,
                            "PROPERTY_TYPE" => "F",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "Y",
                            "ACTIVE" => "Y",
                            "NAME" => GetMessage("IBLOCK_PROPERTY_PICTURES")
                        ));
                    }

                    unset($arPropertyPictures);
                }

                if (!empty($sPropertyArticle)) {
                    $arPropertiesExcluded[] = '^'.preg_quote($sPropertyArticle).'$';

                    $arPropertyArticle = CIBlockProperty::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"], "CODE" => $sPropertyArticle)
                    )->Fetch();

                    if (!empty($arPropertyArticle)) {
                        $oIBlockProperty->Update($arPropertyArticle["ID"], array(
                            "PROPERTY_TYPE" => "S",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "N"
                        ));
                    } else {
                        $oIBlockProperty->Add(array(
                            "IBLOCK_ID" => $arIBlock["ID"],
                            "CODE" => $sPropertyArticle,
                            "PROPERTY_TYPE" => "S",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "N",
                            "ACTIVE" => "Y",
                            "NAME" => GetMessage("IBLOCK_PROPERTY_ARTICLE")
                        ));
                    }

                    unset($arPropertyArticle);
                }

                if (!empty($sPropertyTraits)) {
                    $arPropertiesExcluded[] = '^'.preg_quote($sPropertyTraits).'$';

                    $arPropertyTraits = CIBlockProperty::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"], "CODE" => $sPropertyTraits)
                    )->Fetch();

                    if (!empty($arPropertyTraits)) {
                        $oIBlockProperty->Update($arPropertyTraits["ID"], array(
                            "PROPERTY_TYPE" => "S",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "Y",
                            "WITH_DESCRIPTION" => "Y"
                        ));
                    } else {
                        $oIBlockProperty->Add(array(
                            "IBLOCK_ID" => $arIBlock["ID"],
                            "CODE" => $sPropertyTraits,
                            "PROPERTY_TYPE" => "S",
                            "USER_TYPE" => false,
                            "MULTIPLE" => "Y",
                            "ACTIVE" => "Y",
                            "NAME" => GetMessage("IBLOCK_PROPERTY_TRAITS"),
                            "WITH_DESCRIPTION" => "Y"
                        ));
                    }

                    unset($arPropertyTraits);
                }

                if ($bIsOnlyChanges)
                    $ePropertyAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING;

                if ($ePropertyAction != STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING) {
                    $arIBlockProperties = CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(array(), array("IBLOCK_ID" => $arIBlock["ID"])), "ID");

                    foreach ($arIBlockProperties as $arIBlockProperty) {
                        if (!empty($arIBlockProperty["XML_ID"]))
                            if (array_key_exists($arIBlockProperty["XML_ID"], $arXmlPropertiesTreated))
                                continue;

                        if (in_array($arIBlockProperty['ID'], $arPropertiesExcluded))
                            continue;

                        if (!empty($arIBlockProperty['CODE'])) {
                            $bContinue = false;

                            foreach ($arPropertiesExcluded as $sPropertyExcluded) {
                                if (preg_match('/'.$sPropertyExcluded.'/', $arIBlockProperty['CODE'])) {
                                    $bContinue = true;
                                    break;
                                }
                            }

                            if ($bContinue)
                                continue;

                            unset($bContinue);
                        }

                        if ($ePropertyAction == STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DELETE) {
                            $oIBlockProperty->Delete($arIBlockProperty["ID"]);
                        } else {
                            $oIBlockProperty->Update($arIBlockProperty["ID"], array("ACTIVE" => "N"));
                        }
                    }
                }

                unset($oIBlockProperty);

                return CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(
                    array(),
                    array("IBLOCK_ID" => $arIBlock["ID"])
                ), "ID");
            }

            return null;
        }

        /**
         * @param array $arIBlockProperty
         * @param CStartShopExchange1CCatalogProperty $oXmlProperty
         * @param bool $bIsOnlyChanges
         */
        public static function ImportPropertyValues (&$arIBlockProperty, &$oXmlProperty, $bIsOnlyChanges = false) {
            if ($oXmlProperty->Type == STARTSHOP_EXCHANGE_1C_CATALOG_PROPERTY_TYPE_LIST) {
                $arIBlockPropertyValues = CStartShopUtil::DBResultToArray(CIBlockPropertyEnum::GetList(array(), array("PROPERTY_ID" => $arIBlockProperty["ID"])), "EXTERNAL_ID");
                $arXmlPropertyValuesTreated = array();

                $oIBlockPropertyValue = new CIBlockPropertyEnum();

                if (!empty($oXmlProperty->Values))
                    foreach ($oXmlProperty->Values as $oXmlPropertyValue) {
                        $arIBlockPropertyValue = $arIBlockPropertyValues[$oXmlPropertyValue->Id];

                        if (!empty($arIBlockPropertyValue)) {
                            $oIBlockPropertyValue->Update($arIBlockPropertyValue["ID"], array(
                                "VALUE" => $oXmlPropertyValue->Value,
                                "PROPERTY_ID" => $arIBlockProperty["ID"],
                            ));
                        } else {
                            $oIBlockPropertyValue->Add(array(
                                "EXTERNAL_ID" => $oXmlPropertyValue->Id,
                                "PROPERTY_ID" => $arIBlockProperty["ID"],
                                "VALUE" => $oXmlPropertyValue->Value
                            ));
                        }

                        $arXmlPropertyValuesTreated[$oXmlPropertyValue->Id] = $oXmlPropertyValue;

                        unset($arIBlockPropertyValue);
                    }

                unset($oIBlockPropertyEnum);

                if (!$bIsOnlyChanges) {
                    $arIBlockPropertyValues = CStartShopUtil::DBResultToArray(CIBlockPropertyEnum::GetList(
                        array(),
                        array("PROPERTY_ID" => $arIBlockProperty["ID"])
                    ), "ID");

                    foreach ($arIBlockPropertyValues as $arIBlockPropertyValue) {
                        if (!empty($arIBlockPropertyValue["EXTERNAL_ID"]))
                            if (array_key_exists($arIBlockPropertyValue["EXTERNAL_ID"], $arXmlPropertyValuesTreated))
                                continue;

                        $oIBlockPropertyValue->Delete($arIBlockPropertyValue['ID']);
                    }
                }

                unset(
                    $arXmlPropertyValuesTreated,
                    $arIBlockPropertyValues,
                    $arIBlockPropertyValue,
                    $oIBlockPropertyValue
                );
            }
        }

        /**
         * @param CDataXML $oXml
         * @param array $arIBlock
         * @param int $eItemAction
         * @param bool $bSynchronizeName
         * @param int $iOffset
         * @param int $iLength
         * @param string $sPicturesPath
         * @param null $sPropertyArticle
         * @param null $sPropertyPictures
         * @param null $sPropertyTraits
         * @return array|null
         */
        public static function ImportItems(&$oXml, &$arIBlock, $eItemAction, $bSynchronizeName, $iOffset, $iLength, $sPicturesPath, $sPropertyArticle = null, $sPropertyPictures = null, $sPropertyTraits = null) {
            $iOffset = intval($iOffset);
            $iLength = intval($iLength);

            if ($oXml instanceof CDataXML && !empty($arIBlock)) {
                $arXmlItems = null;
                $arXmlItemsAll = CStartShopExchange1CCatalogItem::GetListByXml($oXml);
                $arXmlProperties = CStartShopExchange1CCatalogProperty::GetListByXml($oXml);
                $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

                if ($arXmlItemsAll != null)
                    if ($iOffset > 0 && $iLength == 0) {
                        $arXmlItems = array_slice($arXmlItemsAll, $iOffset);
                    } else if ($iLength > 0) {
                        $arXmlItems = array_slice($arXmlItemsAll, $iOffset, $iLength);
                    }

                if (!empty($arXmlItems)) {
                    $arIBlockSections = CStartShopUtil::DBResultToArray(CIBlockSection::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"])
                    ), 'EXTERNAL_ID');

                    $arIBlockProperties = CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(
                        array(),
                        array('IBLOCK_ID' => $arIBlock['ID'])
                    ), 'XML_ID');

                    $arIBlockPropertiesEnum = CStartShopUtil::DBResultToArray(CIBlockPropertyEnum::GetList(
                        array(),
                        array('IBLOCK_ID' => $arIBlock['ID'])
                    ), 'ID');

                    $arIBlockPropertiesExternalID = array();

                    foreach ($arIBlockProperties as $sKey => $arIBlockProperty)
                        $arIBlockPropertiesExternalID[$arIBlockProperty['ID']] = $sKey;

                    foreach ($arIBlockPropertiesEnum as $iID => $arIBlockPropertyEnum) {
                        $sIBlockPropertyExternal = $arIBlockPropertiesExternalID[$arIBlockPropertyEnum['PROPERTY_ID']];

                        if (!empty($sIBlockPropertyExternal) && !empty($arIBlockPropertyEnum['EXTERNAL_ID']))
                            $arIBlockProperties[$sIBlockPropertyExternal]['VALUES'][$arIBlockPropertyEnum['EXTERNAL_ID']] = $arIBlockPropertyEnum;
                    }

                    unset(
                        $arIBlockPropertiesExternalID,
                        $arIBlockPropertiesEnum,
                        $arIBlockPropertyEnum,
                        $sKey,
                        $iID,
                        $sIBlockPropertyExternal
                    );

                    $arIBlockItems = CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"])
                    ), "EXTERNAL_ID");

                    foreach ($arXmlItems as $oXmlItem) {
                        $oIBlockItem = new CIBlockElement();
                        $arIBlockItem = $arIBlockItems[$oXmlItem->Id];

                        if (!empty($arIBlockItem)) {
                            $arIBlockItemFields = array();
                            $arIBlockItemProperties = array();

                            if ($bSynchronizeName && $arIBlockItem['NAME'] != $oXmlItem->Name)
                                $arIBlockItemFields["NAME"] = $oXmlItem->Name;

                            if (!empty($oXmlItem->Description)) {
                                $arIBlockItemFields["DETAIL_TEXT"] = $oXmlItem->Description;
                            } else {
                                $arIBlockItemFields["DETAIL_TEXT"] = "";
                            }

                            /* Groups import */
                            if (!empty($oXmlItem->Groups)) {
                                $arIBlockItemFields["IBLOCK_SECTION"] = array();

                                foreach ($oXmlItem->Groups as $sGroup)
                                    $arIBlockItemFields["IBLOCK_SECTION"][] = $arIBlockSections[$sGroup]["ID"];
                            } else {
                                $arIBlockItemFields["IBLOCK_SECTION"] = false;
                            }

                            /* Pictures import */
                            if ($oXmlItem->Pictures != null) {
                                $arPictures = $oXmlItem->Pictures;
                                $sPicture = array_shift($arPictures);

                                if (!empty($sPicture)) {
                                    $arIBlockItemFields["DETAIL_PICTURE"] = CFile::MakeFileArray($sPicturesPath."/".$sPicture);
                                } else {
                                    $arIBlockItemFields["DETAIL_PICTURE"] = array("del" => "Y");
                                }

                                unset($sPicture);

                                if (!empty($sPropertyPictures))
                                    if (!empty($arPictures)) {
                                        $arIBlockItemPropertyPictures = array();

                                        foreach ($arPictures as $sPicture)
                                            $arIBlockItemPropertyPictures[] = array("VALUE" => CFile::MakeFileArray($sPicturesPath."/".$sPicture));

                                        $arIBlockItemProperties[$sPropertyPictures] = $arIBlockItemPropertyPictures;
                                        unset($arIBlockItemPropertyPictures);
                                    } else {
                                        $arIBlockItemProperties[$sPropertyPictures] = array("VALUE" => array("del" => "Y"));
                                    }
                            } else {
                                $arIBlockItemFields["DETAIL_PICTURE"] = array("del" => "Y");

                                if (!empty($sPropertyPictures))
                                    $arIBlockItemProperties[$sPropertyPictures] = array("VALUE" => array("del" => "Y"));
                            }

                            /* Article import */
                            if (!empty($sPropertyArticle))
                                if (!empty($oXmlItem->Article)) {
                                    $arIBlockItemProperties[$sPropertyArticle] = $oXmlItem->Article;
                                } else {
                                    $arIBlockItemProperties[$sPropertyArticle] = false;
                                }

                            /* Traits import */
                            if (!empty($sPropertyTraits))
                                if (!empty($oXmlItem->Traits)) {
                                    $arIBlockItemProperties[$sPropertyTraits] = array();

                                    foreach ($oXmlItem->Traits as $oXmlItemTrait)
                                        if ($oXmlItemTrait instanceof CStartShopExchange1CCatalogItemTrait)
                                            $arIBlockItemProperties[$sPropertyTraits][] = array(
                                                "VALUE" => $oXmlItemTrait->Value,
                                                "DESCRIPTION" => $oXmlItemTrait->Name
                                            );
                                } else {
                                    $arIBlockItemProperties[$sPropertyTraits] = false;
                                }

                            /* Properties import */
                            if (!empty($arXmlProperties))
                                foreach ($arXmlProperties as $oXmlProperty) {
                                    $oXmlItemProperty = $oXmlItem->Properties[$oXmlProperty->Id];
                                    $arIBlockProperty = $arIBlockProperties[$oXmlProperty->Id];

                                    if (!empty($oXmlItemProperty) && !empty($arIBlockProperty)) {
                                        if ($arIBlockProperty['PROPERTY_TYPE'] != 'L') {
                                            $arIBlockItemProperties[$arIBlockProperty["ID"]] = $oXmlItemProperty->Value;
                                        } else {
                                            $arIBlockItemProperties[$arIBlockProperty["ID"]] = $arIBlockProperty["VALUES"][$oXmlItemProperty->Value]["ID"];
                                        }
                                    } else {
                                        $arIBlockItemProperties[$arIBlockProperty['ID']] = false;
                                    }

                                    unset($oXmlItemProperty, $arIBlockProperty);
                                }

                            /* Inserting properties */
                            if (!empty($arIBlockItemProperties))
                                CIBlockElement::SetPropertyValuesEx(
                                    $arIBlockItem['ID'],
                                    $arIBlockItem['IBLOCK_ID'],
                                    $arIBlockItemProperties
                                );

                            if (!empty($arIBlockItemFields))
                                $oIBlockItem->Update($arIBlockItem["ID"], $arIBlockItemFields);
                        } else {
                            $arIBlockItemFields = array(
                                "IBLOCK_ID" => $arIBlock["ID"],
                                "EXTERNAL_ID" => $oXmlItem->Id,
                                "NAME" => $oXmlItem->Name,
                                "PROPERTY_VALUES" => array(),
                            );

                            if (!empty($oXmlItem->Description))
                                $arIBlockItemFields["DETAIL_TEXT"] = $oXmlItem->Description;

                            /* Groups import */
                            if (!empty($oXmlItem->Groups)) {
                                $arIBlockItemFields["IBLOCK_SECTION"] = array();

                                foreach ($oXmlItem->Groups as $sGroup)
                                    $arIBlockItemFields["IBLOCK_SECTION"][] = $arIBlockSections[$sGroup]["ID"];
                            }

                            /* Article import */
                            if (!empty($oXmlItem->Article) && !empty($sPropertyArticle))
                                $arIBlockItemFields["PROPERTY_VALUES"][$sPropertyArticle] = $oXmlItem->Article;

                            /* Pictures import */
                            if ($oXmlItem->Pictures != null) {
                                $arPictures = $oXmlItem->Pictures;
                                $sPicture = array_shift($arPictures);

                                if (!empty($sPicture))
                                    $arIBlockItemFields["DETAIL_PICTURE"] = CFile::MakeFileArray($sPicturesPath."/".$sPicture);

                                unset($sPicture);

                                if (!empty($arPictures) && !empty($sPropertyPictures)) {
                                    $arIBlockItemPropertyPictures = array();

                                    foreach ($arPictures as $sPicture)
                                        $arIBlockItemPropertyPictures[] = array("VALUE" => CFile::MakeFileArray($sPicturesPath."/".$sPicture));

                                    $arIBlockItemFields["PROPERTY_VALUES"][$sPropertyPictures] = $arIBlockItemPropertyPictures;
                                    unset($arIBlockItemPropertyPictures);
                                }

                                unset($arPictures);
                            }

                            /* Traits import */
                            if (!empty($sPropertyTraits))
                                if (!empty($oXmlItem->Traits)) {
                                    $arIBlockItemProperties[$sPropertyTraits] = array();

                                    foreach ($oXmlItem->Traits as $oXmlItemTrait)
                                        if ($oXmlItemTrait instanceof CStartShopExchange1CCatalogItemTrait)
                                            $arIBlockItemProperties[$sPropertyTraits][] = array(
                                                "VALUE" => $oXmlItemTrait->Value,
                                                "DESCRIPTION" => $oXmlItemTrait->Name
                                            );
                                }

                            /* Properties import */
                            if (!empty($oXmlItem->Properties)) {
                                foreach ($oXmlItem->Properties as $oXmlItemProperty) {
                                    $arIBlockProperty = $arIBlockProperties[$oXmlItemProperty->Id];

                                    if ($arIBlockProperty["PROPERTY_TYPE"] != "L") {
                                        $arIBlockItemFields["PROPERTY_VALUES"][$arIBlockProperty["ID"]] = $oXmlItemProperty->Value;
                                    } else {
                                        $arIBlockItemFields["PROPERTY_VALUES"][$arIBlockProperty["ID"]] = $arIBlockProperty["VALUES"][$oXmlItemProperty->Value]["ID"];
                                    }
                                }
                            }

                            $oIBlockItem->Add($arIBlockItemFields);
                        }

                        if ($oXmlItem->Pictures != null)
                            foreach ($oXmlItem->Pictures as $sPicture)
                                if (is_file($sPicturesPath."/".$sPicture))
                                    unlink($sPicturesPath."/".$sPicture);
                    }
                }

                $oIBlockItem = new CIBlockElement();

                if ($bIsOnlyChanges)
                    $eItemAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING;

                if ($eItemAction != STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING) {
                    $arIBlockItems = CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"])
                    ), "ID");

                    foreach ($arIBlockItems as $arIBlockItem) {
                        if (!empty($arIBlockItem["EXTERNAL_ID"]))
                            if (array_key_exists($arIBlockItem["EXTERNAL_ID"], $arXmlItemsAll))
                                continue;

                        if ($eItemAction == STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DELETE) {
                            $oIBlockItem->Delete($arIBlockItem["ID"]);
                        } else {
                            $oIBlockItem->Update($arIBlockItem["ID"], array("ACTIVE" => "N"));
                        }
                    }
                }

                unset($oIBlockItem);

                return CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                    array(),
                    array("IBLOCK_ID" => $arIBlock["ID"])
                ), "ID");
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @return array|null
         */
        public static function ImportPricesTypes(&$oXml) {
            $arXmlPricesTypes = CStartShopExchange1CCatalogOfferPriceType::GetListByXml($oXml);
            $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

            if (!empty($arXmlPricesTypes)) {
                $arPricesTypes = CStartShopUtil::DBResultToArray(CStartShopPrice::GetList(), "CODE");

                foreach ($arXmlPricesTypes as $oXmlPriceType)
                    if ($oXmlPriceType instanceof CStartShopExchange1CCatalogOfferPriceType) {
                        $arPriceType = $arPricesTypes[$oXmlPriceType->Id];

                        if (!empty($arPriceType)) {
                            CStartShopPrice::Update($arPriceType['ID'], array(
                                 "LANG" => array(
                                     LANGUAGE_ID => array(
                                         "NAME" => $oXmlPriceType->Name
                                     )
                                 )
                            ));
                        } else {
                            CStartShopPrice::Add(array(
                                "CODE" => $oXmlPriceType->Id,
                                "LANG" => array(
                                    LANGUAGE_ID => array(
                                        "NAME" => $oXmlPriceType->Name
                                    )
                                )
                            ));
                        }
                    }

                return CStartShopUtil::DBResultToArray(CStartShopPrice::GetList(), "ID");
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @return array|null
         */
        public static function ImportCurrencies(&$oXml) {
            $arXmlOffers = CStartShopExchange1CCatalogOffer::GetListByXml($oXml);
            $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

            if (!empty($arXmlOffers)) {
                $arCurrencies = CStartShopUtil::DBResultToArray(CStartShopCurrency::GetList(), "CODE");
                $arCurrenciesTreated = array();

                foreach ($arXmlOffers as $oXmlOffer)
                    if ($oXmlOffer instanceof CStartShopExchange1CCatalogOffer)
                        if ($oXmlOffer->Prices != null)
                            foreach($oXmlOffer->Prices as $oPrice)
                                if ($oPrice instanceof CStartShopExchange1CCatalogOfferPrice)
                                    if (!in_array($oPrice->Currency, $arCurrenciesTreated))
                                        $arCurrenciesTreated[] = $oPrice->Currency;

                if (!empty($arCurrenciesTreated))
                    foreach ($arCurrenciesTreated as $sCurrency)
                        if (empty($arCurrencies[$sCurrency]))
                            CStartShopCurrency::Add(array(
                                "CODE" => $sCurrency,
                                "RATE" => 1,
                                "RATING" => 1
                            ));

                return CStartShopUtil::DBResultToArray(CStartShopCurrency::GetList(), "ID");
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @param array $arIBlock
         */
        public static function ImportOffersProperties(&$oXml, &$arIBlock) {
            $arCatalog = CStartShopCatalog::GetByIBlock($arIBlock['ID'])->Fetch();
            $arXmlOffers = CStartShopExchange1CCatalogOffer::GetListByXml($oXml);
            $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

            if (!empty($arXmlOffers) && !empty($arCatalog) && !empty($arCatalog['OFFERS_IBLOCK'])) {
                $arIBlockOffers = CIBlock::GetByID($arCatalog['OFFERS_IBLOCK'])->Fetch();

                if (!empty($arIBlockOffers)) {
                    $arIBlockOffersProperties = CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(array(), array(
                        "IBLOCK_ID" => $arIBlockOffers['ID']
                    )), "XML_ID");

                    $arProperties = array();
                    $arXmlProperties = array();

                    foreach ($arXmlOffers as $oXmlOffer)
                        if ($oXmlOffer instanceof CStartShopExchange1CCatalogOffer)
                            if ($oXmlOffer->IsOffer())
                                if ($oXmlOffer->Characteristics != null)
                                    foreach ($oXmlOffer->Characteristics as $oXmlOfferCharacteristic)
                                        if ($oXmlOfferCharacteristic instanceof CStartShopExchange1CCatalogOfferCharacteristic) {
                                            if (isset($arXmlProperties[$oXmlOfferCharacteristic->Name])) {
                                                if (!in_array($oXmlOfferCharacteristic->Value, $arXmlProperties[$oXmlOfferCharacteristic->Name]))
                                                    $arXmlProperties[$oXmlOfferCharacteristic->Name][] = $oXmlOfferCharacteristic->Value;
                                            } else {
                                                $arXmlProperties[$oXmlOfferCharacteristic->Name] = array(
                                                    $oXmlOfferCharacteristic->Value
                                                );
                                            }
                                        }

                    foreach ($arXmlProperties as $sXmlPropertyName => $arXmlProperty) {
                        $arProperty = array(
                            "NAME" => $sXmlPropertyName,
                            "CODE" => CUtil::translit($sXmlPropertyName, "ru", array("change_case" => "U", "max_len" => "48")),
                            "VALUES" => array()
                        );

                        foreach ($arXmlProperty as $sXmlPropertyValue)
                            $arProperty["VALUES"][] = array(
                                "NAME" => $sXmlPropertyValue,
                                "CODE" => CUtil::translit($sXmlPropertyValue, "ru", array("change_case" => "U", "max_len" => "48"))
                            );

                        $arProperties[$arProperty['CODE']] = $arProperty;
                    }

                    $arPropertiesTreatedID = array();

                    foreach ($arProperties as $arProperty) {
                        $arIBlockOfferProperty = $arIBlockOffersProperties[$arProperty['CODE']];

                        $oIBlockProperty = new CIBlockProperty();

                        if (!empty($arIBlockOfferProperty)) {
                            $arIBlockPropertyFields = array(
                                "NAME" => $arProperty["NAME"],
                                "PROPERTY_TYPE" => "L",
                                "USER_TYPE" => false
                            );

                            $arIBlockPropertyValues = array();

                            foreach ($arProperty["VALUES"] as $arPropertyValue)
                                $arIBlockPropertyValues[] = array(
                                    "VALUE" => $arPropertyValue["NAME"],
                                    "XML_ID" => $arPropertyValue["CODE"]
                                );

                            $oIBlockProperty->Update($arIBlockOfferProperty["ID"], $arIBlockPropertyFields, true);
                            $oIBlockProperty->UpdateEnum($arIBlockOfferProperty["ID"], $arIBlockPropertyValues, true);

                            $arPropertiesTreatedID[] = $arIBlockOfferProperty["ID"];
                        } else {
                            $arIBlockPropertyFields = array(
                                "IBLOCK_ID" => $arIBlockOffers['ID'],
                                "NAME" => $arProperty["NAME"],
                                "CODE" => $arProperty["CODE"],
                                "XML_ID" => $arProperty["CODE"],
                                "PROPERTY_TYPE" => "L",
                                "USER_TYPE" => false
                            );

                            $arIBlockPropertyValues = array();

                            foreach ($arProperty["VALUES"] as $arPropertyValue)
                                $arIBlockPropertyValues[] = array(
                                    "VALUE" => $arPropertyValue["NAME"],
                                    "XML_ID" => $arPropertyValue["CODE"]
                                );

                            $iIBlockPropertyID = $oIBlockProperty->Add($arIBlockPropertyFields);

                            if (!empty($iIBlockPropertyID)) {
                                $oIBlockProperty->UpdateEnum($iIBlockPropertyID, $arIBlockPropertyValues);
                                $arPropertiesTreatedID[] = $iIBlockPropertyID;
                            }
                        }

                        unset($oIBlockProperty);
                    }

                    CStartShopCatalog::Update($arIBlock['ID'], array("OFFERS_PROPERTIES" => $arPropertiesTreatedID));
                }
            }
        }

        /**
         * @param CDataXML $oXml
         * @param array $arIBlock
         * @param int $eOfferAction
         * @param bool $bSynchronizeName
         * @param int $iOffset
         * @param int $iLength
         * @return null
         */
        public static function ImportOffers(&$oXml, &$arIBlock, $eOfferAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING, $bSynchronizeName = true, $iOffset = 0, $iLength = 0) {
            if ($oXml instanceof CDataXML && !empty($arIBlock)) {
                $arXmlOffersAll = CStartShopExchange1CCatalogOffer::GetListByXml($oXml);
                $arXmlOffers = array();
                $arXmlOffersTreated = array();
                $arCatalog = CStartShopCatalog::GetByIBlock($arIBlock['ID'])->Fetch();
                $bIsOnlyChanges = CStartShopExchange1CCatalog::IsOnlyChanges($oXml);

                if ($arXmlOffersAll != null)
                    if ($iOffset > 0 && $iLength == 0) {
                        $arXmlOffers = array_slice($arXmlOffersAll, $iOffset);
                    } else if ($iLength > 0) {
                        $arXmlOffers = array_slice($arXmlOffersAll, $iOffset, $iLength);
                    }

                if (!empty($arCatalog) && !empty($arXmlOffers)) {
                    $arIBlockItems = CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                        array(),
                        array("IBLOCK_ID" => $arIBlock["ID"])
                    ), "EXTERNAL_ID");
                    $arIBlockOffersItems = array();
                    $arIBlockOffers = CIBlock::GetByID($arCatalog['OFFERS_IBLOCK'])->Fetch();
                    $arIBlockOffersProperties = array();

                    if (!empty($arIBlockOffers)) {
                        $arIBlockOffersItems = CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                            array(),
                            array("IBLOCK_ID" => $arIBlockOffers["ID"])
                        ), "EXTERNAL_ID");

                        $arIBlockOffersProperties = CStartShopUtil::DBResultToArray(CIBlockProperty::GetList(array(), array(
                            "IBLOCK_ID" => $arIBlockOffers['ID']
                        )), "XML_ID");

                        $arIBlockOffersPropertiesEnum = CStartShopUtil::DBResultToArray(CIBlockPropertyEnum::GetList(
                            array(),
                            array('IBLOCK_ID' => $arIBlockOffers['ID'])
                        ), 'ID');

                        $arIBlockOffersPropertiesExternalID = array();

                        foreach ($arIBlockOffersProperties as $sKey => $arIBlockOfferProperty)
                            $arIBlockOffersPropertiesExternalID[$arIBlockOfferProperty['ID']] = $sKey;

                        foreach ($arIBlockOffersPropertiesEnum as $iID => $arIBlockOffersPropertyEnum) {
                            $sIBlockOffersPropertyExternal = $arIBlockOffersPropertiesExternalID[$arIBlockOffersPropertyEnum['PROPERTY_ID']];

                            if (!empty($sIBlockOffersPropertyExternal) && !empty($arIBlockOffersPropertyEnum['XML_ID']))
                                $arIBlockOffersProperties[$sIBlockOffersPropertyExternal]['VALUES'][$arIBlockOffersPropertyEnum['XML_ID']] = $arIBlockOffersPropertyEnum;
                        }
                    }

                    foreach ($arXmlOffersAll as $oXmlOffer)
                        if ($oXmlOffer instanceof CStartShopExchange1CCatalogOffer)
                            if ($oXmlOffer->IsOffer() && !empty($arIBlockOffers))
                                $arXmlOffersTreated[] = $oXmlOffer->Id;

                    foreach ($arXmlOffers as $oXmlOffer) {
                        if ($oXmlOffer instanceof CStartShopExchange1CCatalogOffer) {
                            $arIBlockItem = $arIBlockItems[$oXmlOffer->GetCatalogItemID()];

                            if (!empty($arIBlockItem))
                                if (!$oXmlOffer->IsOffer()) {
                                    CStartShopToolsIBlock::SetQuantityRatio($arIBlockItem['ID'], 1);
                                    CStartShopToolsIBlock::SetQuantity($arIBlockItem['ID'], $oXmlOffer->Quantity);
                                    CStartShopToolsIBlock::SetPrices($arIBlockItem['ID'], null, null, null);

                                    if ($oXmlOffer->Prices != null) {
                                        foreach ($oXmlOffer->Prices as $oXmlOfferPrice)
                                            if ($oXmlOfferPrice instanceof CStartShopExchange1CCatalogOfferPrice)
                                                CStartShopToolsIBlock::SetPrice(
                                                    $arIBlockItem["ID"],
                                                    $oXmlOfferPrice->Type,
                                                    $oXmlOfferPrice->Value,
                                                    $oXmlOfferPrice->Currency
                                                );
                                    }
                                } else if (!empty($arIBlockOffers)) {
                                    $arIBlockOffersItem = $arIBlockOffersItems[$oXmlOffer->Id];
                                    $arIBlockOffersItemFields = array();
                                    $oIBlockItem = new CIBlockElement();
                                    $iItemID = null;

                                    if (!empty($arIBlockOffersItem)) {
                                        $iItemID = $arIBlockOffersItem['ID'];

                                        if ($bSynchronizeName && $arIBlockOffersItem["NAME"] != $oXmlOffer->Name)
                                            $arIBlockOffersItemFields["NAME"] = $oXmlOffer->Name;

                                        if (!empty($arIBlockOffersItemFields))
                                            $oIBlockItem->Update($arIBlockOffersItem["ID"], $arIBlockOffersItemFields);

                                        CStartShopToolsIBlock::SetPrices($iItemID, null, null, null);
                                    } else {
                                        $arIBlockOffersItemFields = array(
                                            "IBLOCK_ID" => $arIBlockOffers['ID'],
                                            "EXTERNAL_ID" => $oXmlOffer->Id,
                                            "NAME" => $oXmlOffer->Name
                                        );

                                        $iItemID = $oIBlockItem->Add($arIBlockOffersItemFields);
                                    }

                                    if (!empty($iItemID)) {
                                        $arIBlockOffersPropertiesFields = array();

                                        if (!empty($oXmlOffer->Characteristics))
                                            foreach ($oXmlOffer->Characteristics as $oXmlOfferCharacteristic)
                                                if ($oXmlOfferCharacteristic instanceof CStartShopExchange1CCatalogOfferCharacteristic) {
                                                    $sXmlOfferCharacteristicKey = CUtil::translit($oXmlOfferCharacteristic->Name, "ru", array("change_case" => "U", "max_len" => "48"));
                                                    $sXmlOfferCharacteristicValue = CUtil::translit($oXmlOfferCharacteristic->Value, "ru", array("change_case" => "U", "max_len" => "48"));
                                                    $arIBlockOffersPropertiesFields[$arIBlockOffersProperties[$sXmlOfferCharacteristicKey]["ID"]] = $arIBlockOffersProperties[$sXmlOfferCharacteristicKey]["VALUES"][$sXmlOfferCharacteristicValue]["ID"];
                                                }

                                        if (!empty($arIBlockOffersPropertiesFields))
                                            CIBlockElement::SetPropertyValuesEx(
                                                $iItemID,
                                                $arIBlockOffers["ID"],
                                                $arIBlockOffersPropertiesFields
                                            );

                                        CStartShopToolsIBlock::SetQuantityRatio($iItemID, 1);
                                        CStartShopToolsIBlock::SetQuantity($iItemID, $oXmlOffer->Quantity);
                                        CStartShopToolsIBlock::SetOffersLinkByIBlock($arIBlock['ID'], $iItemID, $arIBlockItem['ID']);

                                        if ($oXmlOffer->Prices != null)
                                            foreach ($oXmlOffer->Prices as $oXmlOfferPrice)
                                                if ($oXmlOfferPrice instanceof CStartShopExchange1CCatalogOfferPrice)
                                                    CStartShopToolsIBlock::SetPrice(
                                                        $iItemID,
                                                        $oXmlOfferPrice->Type,
                                                        $oXmlOfferPrice->Value,
                                                        $oXmlOfferPrice->Currency
                                                    );
                                    }

                                    unset($oIBlockItem);
                                    unset($arIBlockOffersItemFields);
                                    unset($arIBlockOffersItem);
                                }

                            unset($arIBlockItem);
                        }
                    }

                    $oIBlockItem = new CIBlockElement();

                    if ($bIsOnlyChanges)
                        $eOfferAction = STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING;

                    if ($eOfferAction != STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_NOTHING) {
                        $arIBlockItems = CStartShopUtil::DBResultToArray(CIBlockElement::GetList(
                            array(),
                            array("IBLOCK_ID" => $arIBlock["ID"])
                        ), "ID");

                        foreach ($arIBlockOffersItems as $arIBlockOfferItem) {
                            if (!empty($arIBlockOfferItem["EXTERNAL_ID"]))
                                if (in_array($arIBlockOfferItem["EXTERNAL_ID"], $arXmlOffersTreated))
                                    continue;

                            if ($eOfferAction == STARTSHOP_EXCHANGE_1C_CATALOG_IMPORT_ACTION_DELETE) {
                                $oIBlockItem->Delete($arIBlockOfferItem["ID"]);
                            } else {
                                $oIBlockItem->Update($arIBlockOfferItem["ID"], array("ACTIVE" => "N"));
                            }
                        }
                    }

                    unset($oIBlockItem);
                    return true;
                }
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @return int
         */
        public static function GetItemsCount(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $eType = static::GetType($oXml);

                if ($eType == STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_PRODUCTS) {
                    if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/Каталог/Товары"))
                        return count($oNode->children());
                } else if ($eType == STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_OFFERS) {
                    if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/ПакетПредложений/Предложения"))
                        return count($oNode->children());
                }
            }

            return 0;
        }


        /**
         * @param CDataXML $oXml
         * @return int|null
         */
        public static function GetType(&$oXml) {
            if ($oXml instanceof CDataXML) {
                if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/Каталог"))
                    return STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_PRODUCTS;

                if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/ПакетПредложений"))
                    return STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_OFFERS;
            }

            return null;
        }

        /**
         * @param CDataXML $oXml
         * @return bool
         */
        public static function IsOnlyChanges(&$oXml) {
            if ($oXml instanceof CDataXML) {
                $eType = static::GetType($oXml);

                if ($eType == STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_PRODUCTS) {
                    if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/Каталог"))
                        if ($oNode->getAttribute("СодержитТолькоИзменения") == "true") {
                            return true;
                        } else {
                            return false;
                        }
                } else if ($eType == STARTSHOP_EXCHANGE_1C_CATALOG_TYPE_OFFERS) {
                    if ($oNode = $oXml->SelectNodes("/КоммерческаяИнформация/ПакетПредложений"))
                        if ($oNode->getAttribute("СодержитТолькоИзменения") == "true") {
                            return true;
                        } else {
                            return false;
                        }
                }
            }

            return false;
        }
    }
?>