<?
$MESS['WDR2_ERROR_AUTH_ERROR'] = 'Необходимо войти на сайт под своим именем, прежде чем голосовать за отзывы.';
$MESS['WDR2_ERROR_YOU_CANNOT_VOTE'] = 'Вы уже голосовали по этому отзыву.';
$MESS['WDR2_ERROR_VOTE_ERROR'] = 'Ошибка. Попробуйте еще раз.';

$MESS['WD_REVIEWS2_ADD_LINK'] = 'Добавить отзыв';
$MESS['WD_REVIEWS2_EDIT_LINK'] = 'Редактировать отзыв';
$MESS['WD_REVIEWS2_DELETE_LINK'] = 'Удалить отзыв';
$MESS['WD_REVIEWS2_DELETE_TITLE'] = 'Вы уверены, что хотите удалить выбранный отзыв?';
?>