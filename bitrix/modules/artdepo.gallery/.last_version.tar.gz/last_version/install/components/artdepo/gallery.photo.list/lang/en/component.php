<?
$MESS ['C_BACK_URL_TITLE'] = "Back";
?>
