<?
$MESS["IPOLSDEK_COMPOPT_MODE"] = "Подключенный профиль на карте";
$MESS["IPOLSDEK_COMPOPT_CITIES"] = "Подключаемые города (если не выбрано ни одного - подключаются все)";
$MESS["IPOLSDEK_COMPOPT_NOMAPS"] = "Не подключать Яндекс-карты (если их подключает что-то еще на странице)";
$MESS["IPOLSDEK_COMPOPT_CNT_DELIV"]  = "Расчитывать доставку при подключении";
$MESS["IPOLSDEK_COMPOPT_CNT_BASKET"] = "Расчитывать доставку для корзины";
$MESS["IPOLSDEK_COMPOPT_FORBIDDEN"]  = "Отключить расчет для профилей";
$MESS["IPOLSDEK_COMPOPT_PAYERS"]  = "Тип плательщика, от лица которого считать доставку";
$MESS["IPOLSDEK_COMPOPT_PAYSYSTEM"]  = "Тип платежной системы, с которой будет считатся доставка";
$MESS["IPOLSDEK_COMPOPT_COUNTRIES"]  = "Подключенные страны";

$MESS["IPOLSDEK_PROF_PICKUP"]   = "Самовывоз";
$MESS["IPOLSDEK_PROF_COURIER"]  = "Курьер";
$MESS["IPOLSDEK_PROF_POSTOMAT"]  = "Постамат";

$MESS["IPOLSDEK_MODE_BOTH"]  = "Самовывоз и постаматы";
?>