<?
$MESS ['ADG_ERROR_WRONG_PARENT_SECTION'] = "Parent section ID not defined or incorrect.";
$MESS ['ADG_PH_ERR_EDIT'] = "Error updating the element";
$MESS ['ADG_PH_ERR_DEL'] = "Error deleting the element";
$MESS ['ADG_PH_LIST_NAV'] = "Elements";
$MESS ['ARTDEPO_GALLERY_PHOTO_NAME'] = "Name";
$MESS ['ARTDEPO_GALLERY_PHOTO_SORT'] = "Sort";
$MESS ['ARTDEPO_GALLERY_PHOTO_DATE_UPDATE'] = "Modification date";
$MESS ['ARTDEPO_GALLERY_PHOTO_DATE_CREATE'] = "Creation date";
$MESS ['ARTDEPO_GALLERY_PHOTO_LIST_EDIT'] = "Rename";
$MESS ['ARTDEPO_GALLERY_PHOTO_LIST_DEL'] = "Delete";
$MESS ['ARTDEPO_GALLERY_PHOTO_LIST_DEL_CONF'] = "Remove element?";
?>
