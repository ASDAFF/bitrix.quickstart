<?
$MESS["IPOLSDEK_PICKUP"] = "Самовывоз:";
$MESS["IPOLSDEK_NO_DELIV"] = "Нет доставки.";
$MESS["IPOLSDEK_DELTERM"] = "Срок: ";
$MESS["IPOLSDEK_DAY"] = " дн.";
?>