<?
$arModuleVersion = array(
	"VERSION" => "0.0.1",
	"VERSION_DATE" => "2013-08-12 13:00:00"
);
?>
