<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "autre";
$MESS["SAL_CHOOSE_CITY"] = "(sélectionner une ville)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(autres)";
$MESS["SAL_CHOOSE_COUNTRY"] = "(sélectionner un pays)";
$MESS["SAL_CHOOSE_REGION"] = "(sélectionner  une région)";
$MESS["SAL_LOC_CITY"] = "Ville";
$MESS["SAL_LOC_COUNTRY"] = "Pays";
$MESS["SAL_LOC_REGION"] = "District";
?>