<?
$MESS["SAL_CHOOSE_COUNTRY"] = "(select country)";
$MESS["SAL_CHOOSE_CITY"] = "(select city)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(other)";
$MESS["SAL_CHOOSE_REGION"] = "(select a region)";
$MESS["LOC_DEFAULT_NAME_NULL"] = "other";
$MESS["SAL_LOC_COUNTRY"] = "Country";
$MESS["SAL_LOC_REGION"] = "Region";
$MESS["SAL_LOC_CITY"] = "City";
?>