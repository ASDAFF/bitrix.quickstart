<?
$MESS ['T_NEWS_NEWS_NA'] = "Section is not found";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
$MESS ['ARTDEPO_GALLERY_MODULE_NOT_INSTALLED'] = "Gallery module is not installer";
?>
