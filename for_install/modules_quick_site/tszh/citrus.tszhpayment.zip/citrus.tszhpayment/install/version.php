<?
$arModuleVersion = array(
	"VERSION" => "12.5.26",
	"VERSION_DATE" => "2015-01-19 10:43:00"
);
?>