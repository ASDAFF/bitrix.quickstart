<?
$MESS ['VOTE_POLL_ID'] = "Poll ID";
$MESS ['VOTE_RESULT_PAGE'] = "Page used to display poll result diagrams";
?>