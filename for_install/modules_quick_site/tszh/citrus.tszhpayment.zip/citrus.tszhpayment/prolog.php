<?
global $MESS;
IncludeModuleLangFile(__FILE__);

define("ADMIN_MODULE_NAME", "citrus.tszhpayment");
define("ADMIN_MODULE_ICON", "<a href=\"/bitrix/admin/tszh_payment.php?lang=".LANG."\"><img src=\"/bitrix/images/fileman/fileman.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("MODULE_ICON_ALT")."\" title=\"".GetMessage("MODULE_ICON_ALT")."\"></a>");
?>