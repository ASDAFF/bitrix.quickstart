<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("������");
?><?$APPLICATION->IncludeComponent(
	"citrus:tszh.payment.make",
	"",
	Array(
		"PAYMENT_URL" => "/personal/payment/",
		"PAYMENT_ID" => $_GET["PAYMENT_ID"],
	),
false
);?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>