<?
$MESS ['VOTE_DOT_DEFAULT_NAME'] = "Default template without poll description";
$MESS ['VOTE_DOT_DEFAULT_DESC'] = "Default template without poll description";
?>