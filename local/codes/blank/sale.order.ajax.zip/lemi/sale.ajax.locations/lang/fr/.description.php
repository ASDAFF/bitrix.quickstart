<?
$MESS["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Un site dynamique sous forme de sélection";
$MESS["SAL_DEFAULT_TEMPLATE_NAME"] = "Emplacements (AJAX)";
$MESS["SAL_NAME"] = "Procédure de l'établissement de la commande";
?>