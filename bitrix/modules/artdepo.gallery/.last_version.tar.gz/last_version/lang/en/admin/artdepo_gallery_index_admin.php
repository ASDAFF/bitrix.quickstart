<?
$MESS ['IBEL_A_UPDERR'] = "Error while saving";
$MESS ['ARTDEPO_GALLERY_LIST_ERR_DEL'] = "Error while delating collection. Check access in medialib.";
$MESS ['ARTDEPO_GALLERY_LIST_NAV'] = "Sections";
$MESS ['ARTDEPO_GALLERY_NAME'] = "Name";
$MESS ['ARTDEPO_GALLERY_ACTIVE'] = "Active";
$MESS ['ARTDEPO_GALLERY_DATE_UPDATE'] = "Date update";
$MESS ['ARTDEPO_GALLERY_OWNER_ID'] = "Created by";

$MESS ['ARTDEPO_GALLERY_ACTIVE_YES'] = "Yes";
$MESS ['ARTDEPO_GALLERY_ACTIVE_NO'] = "No";
$MESS ['ARTDEPO_GALLERY_LIST_ENTER'] = "Open section";
$MESS ['ARTDEPO_GALLERY_LIST_EDIT'] = "Edit";
$MESS ['ARTDEPO_GALLERY_LIST_DEL'] = "Delete";
$MESS ['ARTDEPO_GALLERY_LIST_DEL_CONF'] = "Are you sure you want to delete the selected collections and items?";
$MESS ['ARTDEPO_GALLERY_LIST_ADD'] = "New section";
$MESS ['ARTDEPO_GALLERY_LIST_ADD_TITLE'] = "Add new section";
$MESS ['ARTDEPO_GALLERY_LIST_PAGE_TITLE'] = "Gallery: Sections";
?>
