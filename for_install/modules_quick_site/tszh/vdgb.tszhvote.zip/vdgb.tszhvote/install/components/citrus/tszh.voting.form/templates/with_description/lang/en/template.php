<?
$MESS ['VOTE_START_DATE'] = "Start";
$MESS ['VOTE_END_DATE'] = "End";
$MESS ['VOTE_IS_ACTIVE'] = "Poll is active.";
$MESS ['VOTE_IS_NOT_ACTIVE'] = "Poll is not active.";
$MESS ['VOTE_SUBMIT_BUTTON'] = "Vote";
$MESS ['VOTE_RESET'] = "Reset";
$MESS ['VOTE_VOTES'] = "Votes";
$MESS["F_CAPTCHA_TITLE"] = "Spam bot protection (CAPTCHA)";
$MESS["F_CAPTCHA_PROMT"] = "CAPTCHA image characters";
?>
