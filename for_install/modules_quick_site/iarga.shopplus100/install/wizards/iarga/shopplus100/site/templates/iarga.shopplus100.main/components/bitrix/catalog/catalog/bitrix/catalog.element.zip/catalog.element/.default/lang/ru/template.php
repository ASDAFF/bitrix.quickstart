<?
$MESS["CATALOG_ADD_TO_BASKET"] = "Р вЂ™ Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎС“";
$MESS["CATALOG_MORE_PHOTO"] = "Р вЂўРЎвЂ°Р Вµ РЎвЂћР С•РЎвЂљР С•";
$MESS["CATALOG_DOWNLOAD"] = "Р РЋР С”Р В°РЎвЂЎР В°РЎвЂљРЎРЉ";
$MESS["CATALOG_BACK"] = "Р СњР В°Р В·Р В°Р Т‘ Р Р† РЎР‚Р В°Р В·Р Т‘Р ВµР В»";
$MESS["CATALOG_BUY"] = "Р С™РЎС“Р С—Р С‘РЎвЂљРЎРЉ";
$MESS["CATALOG_NOT_AVAILABLE"] = "(Р Р…Р ВµРЎвЂљ Р Р…Р В° РЎРѓР С”Р В»Р В°Р Т‘Р Вµ)";
$MESS["CATALOG_QUANTITY"] = "Р С™Р С•Р В»Р С‘РЎвЂЎР ВµРЎРѓРЎвЂљР Р†Р С•";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "Р С›РЎвЂљ #FROM# Р Т‘Р С• #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "Р С›РЎвЂљ #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "Р вЂќР С• #TO#";
$MESS["CATALOG_PRICE_VAT"] = "РЎРѓ Р СњР вЂќР РЋ";
$MESS["CATALOG_PRICE_NOVAT"] = "Р В±Р ВµР В· Р СњР вЂќР РЋ";
$MESS["CATALOG_VAT"] = "Р СњР вЂќР РЋ";
$MESS["CATALOG_NO_VAT"] = "Р Р…Р Вµ Р С•Р В±Р В»Р В°Р С–Р В°Р ВµРЎвЂљРЎРѓРЎРЏ";
$MESS["CATALOG_VAT_INCLUDED"] = "Р СњР вЂќР РЋ Р Р†Р С”Р В»РЎР‹РЎвЂЎР ВµР Р… Р Р† РЎвЂ Р ВµР Р…РЎС“";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "Р СњР вЂќР РЋ Р Р…Р Вµ Р Р†Р С”Р В»РЎР‹РЎвЂЎР ВµР Р… Р Р† РЎвЂ Р ВµР Р…РЎС“";
$MESS["CT_BCE_QUANTITY"] = "Р С™Р С•Р В»Р С‘РЎвЂЎР ВµРЎРѓРЎвЂљР Р†Р С•";
$MESS["CT_BCE_CATALOG_ADD"] = "Р вЂ™ Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎС“";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Р РЋРЎР‚Р В°Р Р†Р Р…Р С‘РЎвЂљРЎРЉ";
$MESS["CATALOG_SUBSCRIBE"] = "Р Р€Р Р†Р ВµР Т‘Р С•Р СР С‘РЎвЂљРЎРЉ Р С• Р С—Р С•РЎРѓРЎвЂљРЎС“Р С—Р В»Р ВµР Р…Р С‘Р С‘";
?>