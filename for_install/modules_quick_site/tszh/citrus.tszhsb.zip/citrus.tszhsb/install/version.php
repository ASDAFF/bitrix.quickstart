<?
$arModuleVersion = array(
	"VERSION" => "12.0.1",
	"VERSION_DATE" => "2014-02-25 12:00:00"
);
?>