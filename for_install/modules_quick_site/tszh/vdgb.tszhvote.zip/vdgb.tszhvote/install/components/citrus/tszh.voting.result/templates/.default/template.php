<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<?
if(!empty($arResult['ERRORS']['VOTE']))
{
	foreach($arResult['ERRORS']['VOTE'] as $key => $message)
		ShowError($message." ID=".$key);
}    

foreach($arResult['VOTE'] as $VOTE):
	
	if(isset($VOTE['QUESTION']) && !empty($VOTE['QUESTION']))
	?>

    <div class="voting-result">
    	<h3><?=$VOTE['TITLE_TEXT']?></h3>
        <div class="voting-date">
        	<?=GetMessage("CVF_DATES")?>:
            <?=$VOTE['DATE_BEGIN']?> &mdash; <?=$VOTE['DATE_END']?>
        </div>
        <div class="voting-description"><?=$VOTE["DETAIL_TEXT"]?></div>

            <?foreach($VOTE['QUESTION'] as $key => $question):
            
            	$arAnswerSums = Array();
				$arTotals = Array();
            	$rsAnswers = CCitrusPollVoteAnswer::GetList(Array(), Array("VOTE_QUESTION_ID" => $question['ID']), Array("ANSWER_ID", "VOTE_QUESTION_ID", "SUM" => 'VOTE_WEIGHT'));
				while ($arAnswer = $rsAnswers->GetNext(false))
				{
					$arAnswerSums[$arAnswer['ANSWER_ID']] = Array(
						"SUM" => $arAnswer['VOTE_WEIGHT'],
						'CNT' => $arAnswer["CNT"],
					);
					$arTotals[$arAnswer['VOTE_QUESTION_ID']] += $arAnswer['VOTE_WEIGHT'];
				}
			
            ?>
                <?if(isset($question['ANSWER'])):?>

                    <div class="vote-question">
                        <div class="question-title"><?=$question['TEXT']?></div>
                        <?if($arParams['VOTE_TYPE_DIOGRAM']):?>
                            <table class="data-diogram">
                                <?foreach($question['ANSWER'] as $answ_id => $answer):?>
                                    <?
                                    	$sum = $arAnswerSums[$answ_id]['SUM'];
                                        $count = (100 * $sum) / $arTotals[$question['ID']];
                                        $width = $count*0.8;
                                    ?>
                                    <tr>
                                        <td width="20%"><?=$answer['TEXT']?></td>
                                        <td width="75%">
                                            <div class="voting-result-box" style="width:<?=$width?>%;height:15px;background-color:<?=$answer['COLOR']?>;"></div>
                                            <span class="voting-result-percent"><?=number_format($count,2,"."," ")."%"?></span>
                                        </td>
                                    </tr>

                                <?endforeach;?>
                            </table>
                        <?else:
                        
                        	$obMethod = CCitrusPollMethodBase::GetMethodObj($VOTE['VOTING_METHOD']);
							if (is_object($obMethod))
							{
								$ar = CCitrusPollVote::GetList(Array(), Array("QUESTION_ID" => $question["ID"], false, Array('nTopCount' => 1)), Array("ENTITY_ID"))->Fetch();
								$totalVolume = $obMethod->GetTotalVolume($ar['ENTITY_ID']);
								if ($totalVolume > 0)
								{
									$votedVolume = 0;
									foreach ($question['ANSWER'] as $arAnswer)
										$votedVolume += $arAnswerSums[$arAnswer['ID']]["SUM"];
									$question['ANSWER']['-'] = Array(
										"COLOR" => "#CCCCCC",
										"TEXT" => "(�� ����������)",
									);
									$arAnswerSums['-']['SUM'] = $totalVolume - $votedVolume;
									$arTotals[$question['ID']] = $totalVolume;
								}
							}
						
                        ?>
                                <table>
                                    <tr>
                                        <td>
                                            <img alt="" width="150" height="150" src="<?=$componentPath?>/draw_graf.php?QUESTION=<?=$key?>&dm=150" class="voting-result-diagram" />
                                        </td>
                                        <td>
                                            <div class="answer-box">
                                            <?foreach($question['ANSWER'] as $answ_id => $answer):

		                                    	$sum = $arAnswerSums[$answ_id]['SUM'];
		                                        $count = (100 * $sum) / $arTotals[$question['ID']];
											
                                            ?>
                                                <div>
                                                    <div class="voting-result-box" style="background-color:<?=$answer['COLOR']?>;"></div>
                                                    <span class="voting-result-percent"><?=number_format($count,2,"."," ")."%"?></span>&nbsp<?=$answer['TEXT']?>
                                                </div>
                                            <?endforeach;?>
                                            </div>
                                        </td>
                                    </tr>
                                </table>

                         <?endif;?>
                    </div>

                <?endif;?>
            <?endforeach;?>

    </div>
<?endforeach;?>


