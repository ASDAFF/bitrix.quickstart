<?
$MESS ['ADG_MODULE_NAME'] = "Gallery with multiupload";
$MESS ['ADG_MODULE_DESC'] = "Module gallery with multiupload feature";
$MESS ["ADG_INSTALL_TITLE"] = "Install module";
$MESS ["ADG_UNINSTALL_TITLE"] = "Delete module";
$MESS ['ADG_INSTALL_DEMO_GALLERY'] = "Install demo gallery";
$MESS ['ADG_MODULE_ERROR_NO_ROOT_COLLECTION'] = "Can't create root collection. Use support support@artdepo.com.ua";
$MESS ['ADG_PARTNER_NAME'] = "Art Depo";
?>
