<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "autre (entrer à la main)";
$MESS["PUP_NULL"] = "Veuillez saisir votre ville";
?>