<?
$MESS ['VOTE_MAIN_PAGE_DEFAULT_NAME'] = "Standard template for the main page";
$MESS ['VOTE_MAIN_PAGE_DEFAULT_DESC'] = "Standard template for the main page";
?>