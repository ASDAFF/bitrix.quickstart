<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

if (!CModule::IncludeModule("vdgb.tszhvote"))
{
	ShowError(GetMessage("VOTE_MODULE_IS_NOT_INSTALLED"));
	return;
}

$arParams["GROUP_ID"] = IntVal($arParams["GROUP_ID"]);
if ($arParams["GROUP_ID"] <= 0)
{
	ShowError(GetMessage("VOTE_GROUP_EMPTY"));
	return;
}

$arParams["LIMIT_FIELD_NAME"] = trim(htmlspecialcharsbx($arParams["LIMIT_FIELD_NAME"]));
if ($arParams["LIMIT_FIELD_NAME"] == '-' || strlen($arParams["LIMIT_FIELD_NAME"]) <= 0)
	 $arParams["LIMIT_FIELD_NAME"] = false;
$arParams["LIMIT_FIELD_VALUE"] = trim($arParams['LIMIT_FIELD_VALUE']);

$arParams["VOTING_ID"] = IntVal($arParams["VOTING_ID"]);
$arParams["VOTING_ID"] = $arParams["VOTING_ID"] > 0 ? $arParams["VOTING_ID"] : 0;
/*if ($arParams["VOTING_ID"] <= 0)
{
	$rsPolls = CCitrusPoll::GetList(
		array("DATE_BEGIN" => "DESC"),
		array(
			"GROUP_ID" => $arParams["GROUP_ID"],
			"ACTIVE" => "Y",
		),
		false,
		false,
		array("ID", "DATE_BEGIN", "DATE_END")
	);
	while ($arPoll = $rsPolls->Fetch())
	{
		$dateBegin = MakeTimeStamp($arPoll["DATE_BEGIN"]);
		$dateEnd = MakeTimeStamp($arPoll["DATE_END"]);
		$now = time();
		if ($now >= $dateBegin && $now < $dateEnd)
		{
			$arParams["VOTING_ID"] = $arPoll["ID"];
			break;
		}
	}
}*/

$URL_NAME_DEFAULT = array("vote_result" => "VOTING_ID=#VOTING_ID#");
foreach($URL_NAME_DEFAULT as $URL => $URL_VALUE)
{
	if(strLen(trim($arParams[strToUpper($URL) . "_TEMPLATE"])) <= 0)
		$arParams[strToUpper($URL) . "_TEMPLATE"] = $APPLICATION->GetCurPage() . "?" . $URL_VALUE;

	$arParams["~" . strToUpper($URL) . "_TEMPLATE"] = $arParams[strToUpper($URL) . "_TEMPLATE"];
	$arParams[strToUpper($URL) . "_TEMPLATE"] = htmlspecialcharsbx($arParams["~" . strToUpper($URL) . "_TEMPLATE"]);
}

$arResult = array();

if ($_SERVER["REQUEST_METHOD"] == 'POST' && check_bitrix_sessid() && $_POST['do_vote'] == 1)
{
	try
	{
		$VOTING_ID = IntVal($_POST['voting_id']);
		if ($VOTING_ID <= 0)
			throw new Exception(GetMessage("VOTE_EMPTY"));
	
		if (CCitrusPollVote::IsVoted($VOTING_ID))
			throw new Exception(GetMessage("VOTE_ALREADY_VOTE"));
		
		if ($ex = $APPLICATION->GetException())
			throw new Exception($ex->GetMessage());

		$arAnswers = $_POST['Q'];
		if (!CCitrusPollVote::DoVote($VOTING_ID, $arAnswers))
		{
			if ($ex = $APPLICATION->GetException())
				throw new Exception(GetMessage("VOTING_FAILED_MSG", Array("#MSG#" => $ex->GetString())));
			throw new Exception(GetMessage("VOTING_FAILED"));
		}
	} 
	catch (Exception $e)
	{
		$arResult["ERROR_MESSAGE"] = $e->getMessage();
	}

	if (empty($arResult["ERROR_MESSAGE"]))
		LocalRedirect($APPLICATION->GetCurPageParam("VOTE_SUCCESSFULL=Y", Array('VOTE_SUCCESSFULL')));
}

if(isset($_REQUEST['VOTE_SUCCESSFULL']) && $_REQUEST['VOTE_SUCCESSFULL'] == "Y")
{
	$arResult["OK_MESSAGE"] = GetMessage("OK_MESSAGE");
}

$arFilter = Array(
	"GROUP_ID" => $arParams["GROUP_ID"],
	"ACTIVE" => "Y",
	"<=DATE_BEGIN" => ConvertTimeStamp(time(), "SHORT"),
	">=DATE_END" => ConvertTimeStamp(time(), "SHORT"),
);
if ($arParams["LIMIT_FIELD_NAME"])
	$arFilter[$arParams["LIMIT_FIELD_NAME"]] = $arParams["LIMIT_FIELD_VALUE"];
if ($arParams["VOTING_ID"])
	$arFilter["ID"] = $arParams['VOTING_ID'];

//������� ������ ��������� �������
$rsVoting = CCitrusPoll::GetList(array("RAND" => "ASC"), $arFilter);
while ($arVoting = $rsVoting->Fetch())
{
	$arResult["ITEM"][$arVoting["ID"]] = $arVoting;

	$isVoted = CCitrusPollVote::IsVoted($arVoting['ID']);
	$arResult["ITEM"][$arVoting["ID"]]["IS_VOTED"] = $isVoted;
	if ($isVoted)
		continue;

	//������� ������ �������� �� ������ � id = $arVoting["ID"]
	$rsQuestion = CCitrusPollQuestion::GetList(array("SORT" => "ASC"), array("VOTING_ID" => $arVoting["ID"], "ACTIVE" => "Y"));
	while($arQuestion = $rsQuestion->Fetch())
	{
		$arResult["ITEM"][$arVoting["ID"]]["QUESTION"][$arQuestion["ID"]] = $arQuestion;

		//������� ������ �������, ��� ������� �������
		$rsAnsw = CCitrusPollAnswer::GetList(array("SORT" => "ASC"), array("QUESTION_ID" => $arQuestion["ID"], "ACTIVE" => "Y"));
		while($arAnsw = $rsAnsw->Fetch())
		{
			$arResult["ITEM"][$arVoting["ID"]]["QUESTION"][$arQuestion["ID"]]["ANSWER"][$arAnsw["ID"]] = $arAnsw;
		}
	}
	break;
}

$this->IncludeComponentTemplate();
?>