<?
$MESS['WD_REVIEWS2_COMPONENT_NAME'] = 'Звездочки рейтинга';
$MESS['WD_REVIEWS2_COMPONENT_DESC'] = 'Отображение рейтинга (звездочки)';
$MESS['WD_REVIEWS2_COMPONENT_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WD_REVIEWS2_COMPONENT_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>