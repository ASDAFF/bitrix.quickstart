<?
$MESS['SOF_DEFAULT_TEMPLATE_NAME'] = "Оформление заказа";
$MESS['SOF_DEFAULT_TEMPLATE_DESCRIPTION'] = "Оформление заказа на одной странице";
$MESS['SOF_NAME'] = "Процедура оформления заказа";