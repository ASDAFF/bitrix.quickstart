<?
$MESS["CP_BSSI_NAME"] = "Nom du champ d'introduction de l'emplacement";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "Le choix de la ville d'emplacement n'est pas obligatoire";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Nom de la ville (l'emplacement) champ de formulaire";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "Lieu de retour ID (ou une ville autrement)";
$MESS["SALE_SAL_PARAM_COUNTRY"] = "Pays initiale";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Nom du champ de formulaire de pays";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "Ville (lieu) le changement gestionnaire";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Nom du champ de forme pour la région";
?>