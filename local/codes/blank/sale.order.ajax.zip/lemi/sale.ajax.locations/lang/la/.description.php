<?
$MESS["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Formulario de selección de ubicación dinámica ";
$MESS["SAL_DEFAULT_TEMPLATE_NAME"] = "Ubicaciones (AJAX)";
$MESS["SAL_NAME"] = "Procedimiento de pedidos";
?>