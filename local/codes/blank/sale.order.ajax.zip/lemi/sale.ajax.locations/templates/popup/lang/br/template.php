<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "outro (entrada manual)";
$MESS["PUP_NULL"] = "Forneça uma cidade";
?>