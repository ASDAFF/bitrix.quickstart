<?
$MESS['WEBDEBUG_REVIEWS_COMPONENT_NAME'] = 'Форма для добавления отзыва (старая версия)';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_DESC'] = 'Форма для добавления отзыва к товару, новости, и другим элементам инфоблока';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG'] = 'Webdebug [Веб-дебаг]';
$MESS['WEBDEBUG_REVIEWS_COMPONENT_SECTION_WEBDEBUG_REVIEWS'] = 'Отзывы';
?>