<?
$MESS ['VOTE_FORM_NAME'] = "Poll form";
$MESS ['VOTE_FORM_DESCRIPTION'] = "Display a poll form";
$MESS ['VOTING_SERVICE'] = "Polls and voting";
?>