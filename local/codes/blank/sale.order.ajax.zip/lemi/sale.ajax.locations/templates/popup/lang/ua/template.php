<?
$MESS["PUP_NULL"] = "Введіть місто";
$MESS["LOC_DEFAULT_NAME_NULL"] = "другий (ввести руками)";
?>