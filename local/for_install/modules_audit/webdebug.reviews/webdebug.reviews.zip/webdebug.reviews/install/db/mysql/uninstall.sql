DROP TABLE IF EXISTS `b_webdebug_reviews`;
DROP TABLE IF EXISTS `b_wd_reviews2_fields`;
DROP TABLE IF EXISTS `b_wd_reviews2_interface`;
DROP TABLE IF EXISTS `b_wd_reviews2_ratings`;
DROP TABLE IF EXISTS `b_wd_reviews2_ratingsvalues`;
DROP TABLE IF EXISTS `b_wd_reviews2_reviews`;
DROP TABLE IF EXISTS `b_wd_reviews2_voting`;