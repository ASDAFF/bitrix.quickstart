<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszhpayment/admin/tszh_pay_systems_edit.php");
?>
