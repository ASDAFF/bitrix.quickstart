<?
$MESS ["SAL_DEFAULT_TEMPLATE_NAME"] = "Locations (AJAX)";
$MESS ["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Dynamic location selection form";
$MESS ["SAL_NAME"] = "Order procedure";
?>
