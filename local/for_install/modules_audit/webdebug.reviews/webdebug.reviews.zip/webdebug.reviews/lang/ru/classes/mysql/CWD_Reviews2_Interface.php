<?
$MESS['WD_REVIEWS2_INTERFACE_ERROR_NO_NAME'] = 'Не указано название интерфейса.';
$MESS['WD_REVIEWS2_INTERFACE_ERROR_DELETE_REVIEWS_EXISTS'] = 'Невозможно удалить интерфейс, если он содержит отзывы. Для удаления сначала удалите все отзывы, созданные по этому интерфейсу.';

$MESS['WD_REVIEWS2_EVENT_TYPE_GENERAL'] = 'Уведомление о добавлении отзыва (%s)';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_GENERAL_USER_SUBJECT'] = 'Вы оставили отзыв на сайте #SERVER_NAME#';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_GENERAL_ADMIN_SUBJECT'] = 'Добавлен новый отзыв на сайте #SERVER_NAME#';

$MESS['WD_REVIEWS2_EVENT_TYPE_MODERATE'] = 'Уведомление о добавлении отзыва (%s)';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_MODERATE_USER_SUBJECT'] = 'Вы оставили отзыв на сайте #SERVER_NAME#';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_MODERATE_ADMIN_SUBJECT'] = 'Добавлен новый отзыв на сайте #SERVER_NAME#';

$MESS['WD_REVIEWS2_EVENT_TYPE_ANSWER'] = 'Уведомление о получении ответа на отзыв (%s)';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_ANSWER_USER_SUBJECT'] = 'Администрация сайта ответила на Ваш отзыв на сайте #SERVER_NAME#';

$MESS['WD_REVIEWS2_EVENT_TYPE_MODERATED'] = 'Уведомление о модерации отзыва ответа на отзыв (%s)';
	$MESS['WD_REVIEWS2_EVENT_MESSAGE_MODERATED_USER_SUBJECT'] = 'Администрация сайта проверила Ваш отзыв на сайте #SERVER_NAME#';

$MESS['WD_REVIEWS2_MACROS_REVIEW'] = 'Отзыв пользователя (берется из поля, отмеченного для использования в роли отзыва)';
$MESS['WD_REVIEWS2_MACROS_EMAIL'] = 'E-mail пользователя (берется из поля, отмеченного для использования в роли e-mail)';
$MESS['WD_REVIEWS2_MACROS_NAME'] = 'Имя пользователя (берется из поля, отмеченного для использования в роли имени пользователя)';
$MESS['WD_REVIEWS2_MACROS_USER_ID'] = 'ID текущего пользователя';
$MESS['WD_REVIEWS2_MACROS_DATETIME'] = 'Дата и время отзыва';
$MESS['WD_REVIEWS2_MACROS_REVIEW_ID'] = 'ID отзыва';
$MESS['WD_REVIEWS2_MACROS_INTERFACE_ID'] = 'ID интерфейса';
$MESS['WD_REVIEWS2_MACROS_TARGET'] = 'Объект для отзыва';
$MESS['WD_REVIEWS2_MACROS_TARGET_URL'] = 'Ссылка на объект на сайте';

?>