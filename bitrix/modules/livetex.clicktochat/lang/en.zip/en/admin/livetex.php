<?
$MESS['LIVETEX_ALT']= "";

$MESS['"LIVE_TITLE"'] = "";

$MESS['LIVETEX_BLOCK1_TITLE'] = "What is LiveTex?";

$MESS['LIVETEX_BLOCK1_TEXT'] = <<<HTML
<p  style="line-height: 1.4em;">LiveTex is a perfect communication customer service. It is reasonable and efficient method of communication with web visitors on the web-site, which offers online chat service and complimentary calls.</p>
<p  style="line-height: 1.4em;">Enabling LiveTex's service on your web, allows your customer service representatives and web visitors to engage in meaningful conversations via online chat or via complimentary calls from your website.</p>
<p  style="line-height: 1.4em;">"Direct sales" feature allows customer service representatives proactively suggest assistance to visitors, like sales assistant in the physical store.</p>

<p  style="line-height: 1.4em;">You can connect LiveTex by yourself, without technicians.</p>

HTML;


$MESS['LIVETEX_REG_TITLE'] = "How to start working with LiveTex?";
$MESS['LIVETEX_REG_INFO'] = "To start engaging your visitors today you need to follow three simple steps:
";
$MESS['LIVETEX_REG'] = "Register on LiveTex";
$MESS['LIVETEX_REG_SITE'] = "";
$MESS['LIVETEX_REG_ID'] = "Enter your  <b>LiveTex ID</b>";
$MESS['LIVETEX_REG_INFO2'] = ":(be sure to save changes at the bottom of the page)
<br>
	To find LiveTex ID of your site, go to Account> Preferences> Get the code (under the name of your website). In the code you'll see your LiveTex ID.

";

$MESS['LIVETEX_REG_INFO3'] = "	<li style=\"margin-top: 10px;\"><a href=\"http://livetex.ru/download-client/\" target=\"_blank\">Download</a> and install the Operator console at customer service representative computer.<br/>
	Operator's console allows managers to communicate with visitors. It runs with Windows, Mac and Linux. To install, just download the application and follow the installation wizard.</li>";

$MESS['LIVETEX_SUPPORT_TITLE'] = "Technical support";
$MESS['LIVETEX_SUPPORT_INFO'] = "<br>LiveTex's expert Support agents provide you with support in case you have any problems with your LiveTex solution.
<br>";

?>