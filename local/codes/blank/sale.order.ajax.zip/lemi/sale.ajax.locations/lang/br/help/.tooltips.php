<?
$MESS["CITY_INPUT_NAME_TIP"] = "Nome do campo de formulário que contém o nome da cidade ou local";
$MESS["CITY_OUT_LOCATION_TIP"] = "Se selecionado, o gerenciador irá retornar a ID do local.";
$MESS["COUNTRY_INPUT_NAME_TIP"] = "Nome do campo de formulário que contém o nome do país";
$MESS["COUNTRY_TIP"] = "Selecione aqui o país que irá aparecer em primeiro lugar na lista.";
$MESS["ONCITYCHANGE_TIP"] = "Especifica o nome do gerenciador de evento de <b>seleção da cidade</b>";
?>