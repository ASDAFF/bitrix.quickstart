<?
$MESS ['ADG_UP_BTN_ADD_NEW_IMG'] = "Add new images";
$MESS ['ADG_UP_DRAG_DROP'] = "Drag�n�drop";
$MESS ['ADG_UP_BTN_CANCEL'] = "Cancel";
$MESS ['ADG_UP_BTN_REPEAT'] = "Retry";
$MESS ['ADG_UP_BTN_DELETE'] = "Delete";
$MESS ['ADG_UP_ERROR_FILE_UPLOAD'] = "Can't upload, probably this is not an image or it is too large";
$MESS ['ADG_UP_TITLE'] = "Images multiupload";
$MESS ['ADG_UP_DESCRIPTION_TEXT'] = "Choose files for upload.<br> Also you can upload images with Drag�n�drop";
$MESS ['ADG_UP_BTN_SHOW_UPLOADED_IMAGES'] = "Show uploaded images";
?>
