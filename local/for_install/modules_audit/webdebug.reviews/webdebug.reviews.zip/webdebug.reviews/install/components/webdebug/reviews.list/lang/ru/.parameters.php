<?
$MESS['WEBDEBUG_REVIEWS_SOURCE'] = 'Для чего оставляем отзыв? (выберите сначала инфоблок, затем элемент)';
	$MESS['WEBDEBUG_REVIEWS_IBLOCK_TYPE'] = 'Тип инфоблока';
	$MESS['WEBDEBUG_REVIEWS_IBLOCK_ID'] = 'Инфоблок';
	$MESS['WEBDEBUG_REVIEWS_ELEMENT_ID'] = 'ID элемента';
	$MESS['WEBDEBUG_REVIEWS_ELEMENT_CODE'] = 'Код элемента';

$MESS['WEBDEBUG_REVIEWS_REVIEWS_COUNT'] = 'Кол-во на странице';

$MESS['WEBDEBUG_REVIEWS_FIELDS'] = 'Отображаемые поля';
	$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELDS'] = 'Отображаемые поля';
	$MESS['WEBDEBUG_REVIEWS_REQUIRED_FIELDS'] = 'Поля, обязательные для заполнения';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_NAME'] = 'Имя';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_EMAIL'] = 'E-mail';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_WWW'] = 'Веб-сайт';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_PLUS'] = 'Достоинства';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_MINUS'] = 'Недостатки';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_TEXT_COMMENTS'] = 'Комментарии';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_DATETIME'] = 'Дата';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_0'] = 'Поле для голосования #1';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_1'] = 'Поле для голосования #2';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_2'] = 'Поле для голосования #3';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_3'] = 'Поле для голосования #4';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_4'] = 'Поле для голосования #5';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_5'] = 'Поле для голосования #6';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_6'] = 'Поле для голосования #7';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_7'] = 'Поле для голосования #8';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_8'] = 'Поле для голосования #9';
		$MESS['WEBDEBUG_REVIEWS_DISPLAY_FIELD_VOTE_9'] = 'Поле для голосования #10';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_0'] = 'Название поля для голосования #1';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_1'] = 'Название поля для голосования #2';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_2'] = 'Название поля для голосования #3';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_3'] = 'Название поля для голосования #4';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_4'] = 'Название поля для голосования #5';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_5'] = 'Название поля для голосования #6';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_6'] = 'Название поля для голосования #7';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_7'] = 'Название поля для голосования #8';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_8'] = 'Название поля для голосования #9';
		$MESS['WEBDEBUG_REVIEWS_VOTE_NAME_9'] = 'Название поля для голосования #10';
	$MESS['WEBDEBUG_REVIEWS_EMAIL_PUBLIC'] = 'Публиковать e-mail';
	$MESS['WEBDEBUG_REVIEWS_USE_MODERATE'] = 'Показывать только допущенные';
?>