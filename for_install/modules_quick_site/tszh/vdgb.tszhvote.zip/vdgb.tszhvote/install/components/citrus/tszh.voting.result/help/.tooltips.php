<?
$arTooltips = array(
	"VOTE_ID" => GetMessage("VOTE_ID_TIP"),
	"CACHE_TYPE" => GetMessage("CACHE_TYPE_TIP"),
	"CACHE_TIME" => GetMessage("CACHE_TIME_TIP"),
);
?>