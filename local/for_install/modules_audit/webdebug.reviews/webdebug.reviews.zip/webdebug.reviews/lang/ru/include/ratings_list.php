<?

$MESS['WD_REVIEWS2_ERROR_NO_RATINGS'] = 'Не создано ни одного рейтинга';
$MESS['WD_REVIEWS2_ERROR_NO_RATINGS_PARTICIPATES'] = 'Не создано ни одного рейтинга, участвующего в подсчете результирующего рейтинга.';
$MESS['WD_REVIEWS2_ERROR_SAVE'] = 'Ошибка при сохранении';

$MESS['WD_REVIEWS2_BTN_ADD'] = 'Добавить';
$MESS['WD_REVIEWS2_BTN_REFRESH'] = 'Обновить список';

$MESS['WD_REVIEWS2_COL_NAME'] = 'Название';
$MESS['WD_REVIEWS2_COL_PARTICIPATES'] = 'Влияет на общий рейтинг';
$MESS['WD_REVIEWS2_COL_SORT'] = 'Сорт.';

$MESS['WD_REVIEWS2_RATINGS_COUNT'] = 'Всего рейтингов';

$MESS['WD_REVIEWS2_RATINGS_POPUP_ADD'] = 'Создание нового рейтинга в форме добавления отзыва';
$MESS['WD_REVIEWS2_RATINGS_POPUP_EDIT'] = 'Редактирование рейтинга в форме добавления отзыва';
$MESS['WD_REVIEWS2_RATINGS_POPUP_SAVE'] = 'Сохранить';
$MESS['WD_REVIEWS2_RATINGS_POPUP_CANCEL'] = 'Отменить';

$MESS['WD_REVIEWS2_RATINGS_EDIT'] = 'Ред.';
$MESS['WD_REVIEWS2_RATINGS_DELETE'] = 'Уд.';
$MESS['WD_REVIEWS2_RATINGS_DELETE_CONFIRM'] = 'Удалить данный рейтинг?';

?>