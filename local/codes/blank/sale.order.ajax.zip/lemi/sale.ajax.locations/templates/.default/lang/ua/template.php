<?
$MESS["SAL_CHOOSE_COUNTRY"] = "(виберіть країну)";
$MESS["SAL_CHOOSE_CITY"] = "(виберіть місто)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(інший)";
$MESS["SAL_CHOOSE_REGION"] = "(виберіть регіон)";
$MESS["LOC_DEFAULT_NAME_NULL"] = "інший";
$MESS["SAL_LOC_COUNTRY"] = "Країна";
$MESS["SAL_LOC_REGION"] = "Регіон";
$MESS["SAL_LOC_CITY"] = "Місто";
?>