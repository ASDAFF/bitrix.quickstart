<?
$MESS["SAL_CHOOSE_COUNTRY"] = "(pasirinkite šalį)";
$MESS["SAL_CHOOSE_CITY"] = "(pasirinkti miestą)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(kita)";
$MESS["SAL_CHOOSE_REGION"] = "(pasirinkti regioną)";
$MESS["LOC_DEFAULT_NAME_NULL"] = "kita";
$MESS["SAL_LOC_COUNTRY"] = "Šalis";
$MESS["SAL_LOC_REGION"] = "Regionas";
$MESS["SAL_LOC_CITY"] = "Miestas";
?>