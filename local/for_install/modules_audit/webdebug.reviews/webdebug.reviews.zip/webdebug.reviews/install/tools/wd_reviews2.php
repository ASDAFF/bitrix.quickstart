<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/webdebug.reviews/tools/wd_reviews2.php");
?>