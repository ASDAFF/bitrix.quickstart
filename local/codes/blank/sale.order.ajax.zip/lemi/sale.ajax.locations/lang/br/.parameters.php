<?
$MESS["CP_BSSI_NAME"] = "Nome do campo de entrada de local";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "A cidade do local é opcional";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Campo de formulário do nome da cidade (local) ";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "ID do local de retorno (ou cidade)";
$MESS["SALE_SAL_PARAM_COUNTRY"] = "País iniciaç";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Campo de formulário de nome do país";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "Gerenciador de modificação de Cidade (local)";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Nome do campo de formulário da Região";
?>