<?
$MESS["VOTE_IS_ACTIVE_SMALL"] = "active";
$MESS["VOTE_IS_NOT_ACTIVE_SMALL"] = "not active";
$MESS["VOTE_IS_ACTIVE"] = "Poll is active.";
$MESS["VOTE_IS_NOT_ACTIVE"] = "Poll is not active.";
$MESS["VOTE_VOTES"] = "Votes";
$MESS["VOTE_GROUP_TOTAL"] = "total";
?>