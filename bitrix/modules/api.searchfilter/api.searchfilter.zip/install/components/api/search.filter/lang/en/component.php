<?
$MESS ['CC_BCF_ALL'] = "(all)";
$MESS ['CC_BCF_TILL'] = "till";
$MESS ['CC_BCF_TOP_LEVEL'] = "Top level";
$MESS ['CC_BCF_INCLUDE_SUBSECTIONS'] = "include subsections";
$MESS ['CC_BCF_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
?>