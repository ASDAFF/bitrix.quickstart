<?
$MESS["CITY_INPUT_NAME_TIP"] = "Le nom d'un champ de formulaire pour contenir la ville ou le nom du lieu.";
$MESS["CITY_OUT_LOCATION_TIP"] = "Si elle est cochée, le gestionnaire sera de retour l'ID de l'emplacement.";
$MESS["COUNTRY_INPUT_NAME_TIP"] = "Le nom d'un champ de formulaire pour contenir le nom du pays.";
$MESS["COUNTRY_TIP"] = "Sélectionnez ici le pays qui sera affiché en premier dans la liste.";
$MESS["ONCITYCHANGE_TIP"] = "Indique le nom de la <b>sélection de la ville</b> de gestionnaire d'événement.";
?>