<?
$MESS['SAL_DEFAULT_TEMPLATE_DESCRIPTION'] = "Динамічна форма вибору місцезнаходження";
$MESS['SAL_DEFAULT_TEMPLATE_NAME'] = "AJAX-місцезнаходження";
$MESS['SAL_NAME'] = "Процедура оформлення замовлення";
?>