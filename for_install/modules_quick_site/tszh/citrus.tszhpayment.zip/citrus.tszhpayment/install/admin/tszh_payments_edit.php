<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszhpayment/admin/tszh_payments_edit.php");
?>
