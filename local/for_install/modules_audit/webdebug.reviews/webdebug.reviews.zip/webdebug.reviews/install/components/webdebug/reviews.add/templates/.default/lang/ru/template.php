<?
$MESS['WEBDEBUG_REVIEWS_ADD_BUTTON'] = 'Оставить отзыв';

$MESS['WEBDEBUG_REVIEWS_NOTICE_USE_MODERATE'] = 'Отзывы публикуются после модерации';
$MESS['WEBDEBUG_REVIEWS_SUCCESS_BUT_USING_MODERATE'] = 'После прохождения модерации (проверки) администрацией отзыв будет опубликован';

$MESS['WEBDEBUG_REVIEWS_FORM_SUBMIT'] = 'Готово!';
$MESS['WEBDEBUG_REVIEWS_FIELD_NAME'] = 'Ваше имя';
$MESS['WEBDEBUG_REVIEWS_FIELD_EMAIL'] = 'E-mail';
$MESS['WEBDEBUG_REVIEWS_FIELD_EMAIL_PUBLIC'] = 'публиковать E-mail';
$MESS['WEBDEBUG_REVIEWS_FIELD_WWW'] = 'Веб-сайт';
$MESS['WEBDEBUG_REVIEWS_FIELD_TEXT_PLUS'] = 'Достоинства';
$MESS['WEBDEBUG_REVIEWS_FIELD_TEXT_MINUS'] = 'Недостатки';
$MESS['WEBDEBUG_REVIEWS_FIELD_TEXT_COMMENTS'] = 'Комментарии';

$MESS['WEBDEBUG_REVIEWS_FIELD_CAPTCHA'] = 'Защитный код';
$MESS['WEBDEBUG_REVIEWS_FIELD_CAPTCHA_REFRESH'] = 'обновить';
?>