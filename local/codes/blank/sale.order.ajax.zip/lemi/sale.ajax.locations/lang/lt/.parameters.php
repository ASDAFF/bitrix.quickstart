<?
$MESS["SALE_SAL_PARAM_COUNTRY"] = "Pradinė šalis";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "Grąžinimo vietos ID (arba miestas)";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "Lokacijos miestas yra neprivalomas";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Šalies formos lauko pavadinimas";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Miesto (vietos) formos lauko pavadinimas";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "Miesto (vietos) keitimo tvarkymo programa";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Regiono formos lauko pavadinimas";
$MESS["CP_BSSI_NAME"] = "Lokacijos ivesties lauko pavadinimas";
?>