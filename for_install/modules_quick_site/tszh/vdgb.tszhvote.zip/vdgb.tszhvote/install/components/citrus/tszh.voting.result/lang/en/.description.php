<?
$MESS ['VOTE_RESULT_NAME'] = "Poll results";
$MESS ['VOTE_RESULT_DESCRIPTION'] = "Displays diagrams with the poll results";
$MESS ['VOTING_SERVICE'] = "Polls and voting";
?>