<?
$MESS ['T_ARTDEPO_GALLERY_PHOTO_LIST_NAME'] = "Photo list";
$MESS ['T_ARTDEPO_GALLERY_PHOTO_LIST_DESC'] = "List of photos in the album";
$MESS ['T_ARTDEPO_DESC_GALLERY'] = "Gallery";
?>
