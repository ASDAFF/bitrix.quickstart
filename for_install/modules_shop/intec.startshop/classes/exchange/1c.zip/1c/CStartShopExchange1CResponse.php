<?
    class CStartShopExchange1CResponse
    {
        public static function Success($bDie = true) {
            echo "success\n";

            if ($bDie)
                die();
        }

        public static function Progress($bDie = true) {
            echo "progress\n";

            if ($bDie)
                die();
        }

        public static function Failure($sReason = "", $bDie = true) {
            echo "failure\n";
            echo $sReason."\n";

            if ($bDie)
                die();
        }

        public static function Authorize($sCookieName, $sCookieValue, $bDie = true) {
            if (!empty($sCookieName) && !empty($sCookieValue)) {
                static::Success(false);
                echo $sCookieName."\n";
                echo $sCookieValue."\n";
            } else {
                static::Failure("Authorize: invalid parameters!", $bDie);
                return false;
            }

            if ($bDie)
                die();

            return true;
        }

        public static function Initialize($iFileSize = 1048576, $bUseZip = false, $bDie = true) {
            if (!empty($iFileSize) && is_numeric($iFileSize)) {
                echo "zip=".($bUseZip ? "yes" : "no")."\n";
                echo "file_limit=".$iFileSize."\n";
            } else {
                static::Failure("Initialize: invalid parameters!", $bDie);
                return false;
            }

            if ($bDie)
                die();

            return true;
        }
    }
?>