<?
$MESS["CITY_INPUT_NAME_TIP"] = "Nazwa pola formularza zawierającego nazwę miasta lub lokalizacji.";
$MESS["CITY_OUT_LOCATION_TIP"] = "Jeżeli zaznaczone, obsługa zwróci ID lokalizacji.";
$MESS["COUNTRY_INPUT_NAME_TIP"] = "Nazwa pola formularza zawierającego nazwę kraju.";
$MESS["COUNTRY_TIP"] = "Wybierz tutaj kraj, który będzie wyświetlany jako pierwszy na liście.";
$MESS["ONCITYCHANGE_TIP"] = "Określ nazwę <b>wyboru miasta</b> obsługi wydarzenia.";
?>