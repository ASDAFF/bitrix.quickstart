<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "otro";
$MESS["SAL_CHOOSE_CITY"] = "(seleccionar ciudad)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(otro)";
$MESS["SAL_CHOOSE_COUNTRY"] = "(seleccione país)";
$MESS["SAL_CHOOSE_REGION"] = "(seleccione una región)";
$MESS["SAL_LOC_CITY"] = "Ciudad";
$MESS["SAL_LOC_COUNTRY"] = "País";
$MESS["SAL_LOC_REGION"] = "Región";
?>