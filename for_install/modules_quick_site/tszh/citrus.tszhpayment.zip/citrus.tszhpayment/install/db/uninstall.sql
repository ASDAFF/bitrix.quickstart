DROP TABLE IF EXISTS `b_tszh_pay_system`;
DROP TABLE IF EXISTS `b_tszh_payment`;
