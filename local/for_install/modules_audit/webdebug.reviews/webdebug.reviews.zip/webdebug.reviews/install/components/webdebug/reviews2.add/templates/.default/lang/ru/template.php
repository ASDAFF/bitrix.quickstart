<?
$MESS['WD_REVIEWS2_NEED_AUTH'] = 'Для написания отзывов необходима авторизация на сайте.';
$MESS['WD_REVIEWS2_ADD_BUTTON'] = 'Оставить отзыв!';
$MESS['WD_REVIEWS2_ADD_HEADER'] = 'Оставить отзыв';
$MESS['WD_REVIEWS2_CAPTCHA_HEADER'] = 'Защитный код';
$MESS['WD_REVIEWS2_CAPTCHA_LOADING'] = 'Загрузка кода...';
$MESS['WD_REVIEWS2_CAPTCHA_RELOAD'] = 'обновить код';
$MESS['WD_REVIEWS2_SUBMIT'] = 'Отправить';
?>