<?
IncludeModuleLangFile(__FILE__);

define("ADMIN_MODULE_NAME", "vdgb.tszhvote");
define("ADMIN_MODULE_ICON", "<img src=\"/bitrix/images/search/search.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("VOTE_PROLOG_ALT")."\" title=\"".GetMessage("VOTE_PROLOG_ALT")."\">");

?>
