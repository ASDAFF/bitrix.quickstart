<?
$MESS['WD_REVIEWS2_CANCEL'] = 'Отмена';
$MESS['WD_REVIEWS2_Y'] = 'Да';
$MESS['WD_REVIEWS2_N'] = 'Нет';

$MESS['WD_REVIEWS2_ERROR_NO_INTERFACE'] = 'Не указан интерфейс';

$MESS['WD_REVIEWS2_REVIEW_ADD'] = 'Добавить отзыв';
$MESS['WD_REVIEWS2_REVIEW_EDIT'] = 'Редактировать отзыв';
$MESS['WD_REVIEWS2_REVIEW_DENIED'] = 'Запретить публикацию';
$MESS['WD_REVIEWS2_REVIEW_APPROVE'] = 'Разрешить публикацию';

$MESS['WD_REVIEWS2_FIELD_MODERATED'] = 'Допущено';
$MESS['WD_REVIEWS2_FIELD_USER_ID'] = 'Пользователь';
$MESS['WD_REVIEWS2_FIELD_ANSWER'] = 'Ответ';
$MESS['WD_REVIEWS2_FIELD_ANSWER_USER_ID'] = 'ID администратора';
$MESS['WD_REVIEWS2_FIELD_TARGET'] = 'Объект';
$MESS['WD_REVIEWS2_FIELD_DATE_CREATED'] = 'Дата создания';
$MESS['WD_REVIEWS2_FIELD_DATE_MODIFIED'] = 'Дата изменения';
$MESS['WD_REVIEWS2_FIELD_DATE_VOTING'] = 'Дата последнего голоса';
$MESS['WD_REVIEWS2_FIELD_VOTES_Y'] = 'За';
$MESS['WD_REVIEWS2_FIELD_VOTES_N'] = 'Против';
$MESS['WD_REVIEWS2_FIELD_VOTE_RESULT'] = 'Мнение';

$MESS['WDR2_ERROR_INTERFACE_NOT_FOUND'] = 'Интерфейс не найден.';
$MESS['WDR2_ERROR_INTERFACE_EMPTY'] = 'Интерфейс не указан.';
$MESS['WDR2_ERROR_TARGET_EMPTY'] = 'Объект не указан.';

?>