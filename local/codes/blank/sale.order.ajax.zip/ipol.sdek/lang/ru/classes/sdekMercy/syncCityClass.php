<?
$MESS ['IPOLSDEK_RK_1'] = "АДЫГЕ";
$MESS ['IPOLSDEK_RV_1'] = "АДЫГЕЯ";

$MESS ['IPOLSDEK_RK_2'] = "БАШКОРТОСТАН";
$MESS ['IPOLSDEK_RV_2'] = "БАШКОРТОСТАН";

$MESS ['IPOLSDEK_RK_3'] = "БУРЯТ";
$MESS ['IPOLSDEK_RV_3'] = "БУРЯТИЯ";

$MESS ['IPOLSDEK_RK_4'] = "АЛТАЙ";
$MESS ['IPOLSDEK_RV_4'] = "АЛТАЙ";

$MESS ['IPOLSDEK_RK_5'] = "ДАГЕСТАН";
$MESS ['IPOLSDEK_RV_5'] = "ДАГЕСТАН";

$MESS ['IPOLSDEK_RK_6'] = "ИНГУШЕТ";
$MESS ['IPOLSDEK_RV_6'] = "ИНГУШЕТИЯ";

$MESS ['IPOLSDEK_RK_7'] = "КАБАРДИН";
$MESS ['IPOLSDEK_RV_7'] = "КАБАРДИНО-БАЛКАРСКАЯ";

$MESS ['IPOLSDEK_RK_8'] = "КАЛМЫК";
$MESS ['IPOLSDEK_RV_8'] = "КАЛМЫКИЯ";

$MESS ['IPOLSDEK_RK_9'] = "КАРАЧАЕВ";
$MESS ['IPOLSDEK_RV_9'] = "КАРАЧАЕВО-ЧЕРКЕССКАЯ";

$MESS ['IPOLSDEK_RK_10'] = "КАРЕЛ";
$MESS ['IPOLSDEK_RV_10'] = "КАРЕЛИЯ";

$MESS ['IPOLSDEK_RK_11'] = "КОМИ";
$MESS ['IPOLSDEK_RV_11'] = "КОМИ";

$MESS ['IPOLSDEK_RK_12'] = "МАРИЙ";
$MESS ['IPOLSDEK_RV_12'] = "МАРИЙ ЭЛ";

$MESS ['IPOLSDEK_RK_13'] = "МОРДОВ";
$MESS ['IPOLSDEK_RV_13'] = "МОРДОВИЯ";

$MESS ['IPOLSDEK_RK_14'] = "ЯКУТ";
$MESS ['IPOLSDEK_RV_14'] = "ЯКУТИЯ";

$MESS ['IPOLSDEK_RK_15'] = "ОСЕТИЯ";
$MESS ['IPOLSDEK_RV_15'] = "СЕВЕРНАЯ ОСЕТИЯ - АЛАНИЯ";

$MESS ['IPOLSDEK_RK_16'] = "АЛАНИЯ";
$MESS ['IPOLSDEK_RV_16'] = "СЕВЕРНАЯ ОСЕТИЯ - АЛАНИЯ";

$MESS ['IPOLSDEK_RK_17'] = "ТАТАРСТ";
$MESS ['IPOLSDEK_RV_17'] = "ТАТАРСТАН";

$MESS ['IPOLSDEK_RK_18'] = "ТЫВА";
$MESS ['IPOLSDEK_RV_18'] = "ТЫВА";

$MESS ['IPOLSDEK_RK_19'] = "УДМУРТ";
$MESS ['IPOLSDEK_RV_19'] = "УДМУРТИЯ";

$MESS ['IPOLSDEK_RK_20'] = "ХАКАС";
$MESS ['IPOLSDEK_RV_20'] = "ХАКАСИЯ";

$MESS ['IPOLSDEK_RK_21'] = "ЧУВАШ";
$MESS ['IPOLSDEK_RV_21'] = "ЧУВАШИЯ";

$MESS ['IPOLSDEK_RK_22'] = "КРАСНОДАР";
$MESS ['IPOLSDEK_RV_22'] = "КРАСНОДАРСКИЙ";

$MESS ['IPOLSDEK_RK_23'] = "КРАСНОЯР";
$MESS ['IPOLSDEK_RV_23'] = "КРАСНОЯРСКИЙ";

$MESS ['IPOLSDEK_RK_24'] = "ПРИМОРСК";
$MESS ['IPOLSDEK_RV_24'] = "ПРИМОРСКИЙ";

$MESS ['IPOLSDEK_RK_25'] = "СТАВРОПОЛЬ";
$MESS ['IPOLSDEK_RV_25'] = "СТАВРОПОЛЬСКИЙ";

$MESS ['IPOLSDEK_RK_26'] = "ХАБАРОВСК";
$MESS ['IPOLSDEK_RV_26'] = "ХАБАРОВСКИЙ";

$MESS ['IPOLSDEK_RK_27'] = "АРХАНГЕЛ";
$MESS ['IPOLSDEK_RV_27'] = "АРХАНГЕЛЬСКАЯ";

$MESS ['IPOLSDEK_RK_28'] = "АСТРАХАН";
$MESS ['IPOLSDEK_RV_28'] = "АСТРАХАНСКАЯ";

$MESS ['IPOLSDEK_RK_29'] = "БЕЛГОРОД";
$MESS ['IPOLSDEK_RV_29'] = "БЕЛГОРОДСКАЯ";

$MESS ['IPOLSDEK_RK_30'] = "БРЯНСК";
$MESS ['IPOLSDEK_RV_30'] = "БРЯНСКАЯ";

$MESS ['IPOLSDEK_RK_31'] = "ВЛАДИМИР";
$MESS ['IPOLSDEK_RV_31'] = "ВЛАДИМИРСКАЯ";

$MESS ['IPOLSDEK_RK_32'] = "ВОЛГОГРАД";
$MESS ['IPOLSDEK_RV_32'] = "ВОЛГОГРАДСКАЯ";

$MESS ['IPOLSDEK_RK_33'] = "ВОЛОГОДС";
$MESS ['IPOLSDEK_RV_33'] = "ВОЛОГОДСКАЯ";

$MESS ['IPOLSDEK_RK_34'] = "ВОРОНЕЖ";
$MESS ['IPOLSDEK_RV_34'] = "ВОРОНЕЖСКАЯ";

$MESS ['IPOLSDEK_RK_35'] = "ИВАНОВ";
$MESS ['IPOLSDEK_RV_35'] = "ИВАНОВСКАЯ";

$MESS ['IPOLSDEK_RK_36'] = "ИРКУТСК";
$MESS ['IPOLSDEK_RV_36'] = "ИРКУТСКАЯ";

$MESS ['IPOLSDEK_RK_37'] = "КАЛИНИНГРАД";
$MESS ['IPOLSDEK_RV_37'] = "КАЛИНИНГРАДСКАЯ";

$MESS ['IPOLSDEK_RK_38'] = "КАМЧАТ";
$MESS ['IPOLSDEK_RV_38'] = "КАМЧАТКА";

$MESS ['IPOLSDEK_RK_39'] = "КЕМЕРОВ";
$MESS ['IPOLSDEK_RV_39'] = "КЕМЕРОВСКАЯ";

$MESS ['IPOLSDEK_RK_40'] = "КИРОВ";
$MESS ['IPOLSDEK_RV_40'] = "КИРОВСКАЯ";

$MESS ['IPOLSDEK_RK_41'] = "КОСТРОМ";
$MESS ['IPOLSDEK_RV_41'] = "КОСТРОМСКАЯ";

$MESS ['IPOLSDEK_RK_42'] = "КУРГАН";
$MESS ['IPOLSDEK_RV_42'] = "КУРГАНСКАЯ";

$MESS ['IPOLSDEK_RK_43'] = "КУРСК";
$MESS ['IPOLSDEK_RV_43'] = "КУРСКАЯ";

$MESS ['IPOLSDEK_RK_44'] = "ЛЕНИНГРАД";
$MESS ['IPOLSDEK_RV_44'] = "ЛЕНИНГРАДСКАЯ";

$MESS ['IPOLSDEK_RK_45'] = "ЛИПЕЦК";
$MESS ['IPOLSDEK_RV_45'] = "ЛИПЕЦКАЯ";

$MESS ['IPOLSDEK_RK_46'] = "МАГАДАН";
$MESS ['IPOLSDEK_RV_46'] = "МАГАДАНСКАЯ";

$MESS ['IPOLSDEK_RK_47'] = "МОСК";
$MESS ['IPOLSDEK_RV_47'] = "МОСКОВСКАЯ";

$MESS ['IPOLSDEK_RK_48'] = "МУРМАНСК";
$MESS ['IPOLSDEK_RV_48'] = "МУРМАНСКАЯ";

$MESS ['IPOLSDEK_RK_49'] = "НИЖЕГОРОД";
$MESS ['IPOLSDEK_RV_49'] = "НИЖЕГОРОДСКАЯ";

$MESS ['IPOLSDEK_RK_50'] = "НИЖНЕГОРОД";
$MESS ['IPOLSDEK_RV_50'] = "НИЖЕГОРОДСКАЯ";

$MESS ['IPOLSDEK_RK_51'] = "НОВГОРОД";
$MESS ['IPOLSDEK_RV_51'] = "НОВГОРОДСКАЯ";

$MESS ['IPOLSDEK_RK_52'] = "НОВОСИБИРСК";
$MESS ['IPOLSDEK_RV_52'] = "НОВОСИБИРСКАЯ";

$MESS ['IPOLSDEK_RK_53'] = "ОМСК";
$MESS ['IPOLSDEK_RV_53'] = "ОМСКАЯ";

$MESS ['IPOLSDEK_RK_54'] = "ОРЕНБУРГ";
$MESS ['IPOLSDEK_RV_54'] = "ОРЕНБУРГСКАЯ";

$MESS ['IPOLSDEK_RK_55'] = "ОРЛОВ";
$MESS ['IPOLSDEK_RV_55'] = "ОРЛОВСКАЯ";

$MESS ['IPOLSDEK_RK_56'] = "ОРЕЛ";
$MESS ['IPOLSDEK_RV_56'] = "ОРЛОВСКАЯ";

$MESS ['IPOLSDEK_RK_57'] = "ПЕНЗ";
$MESS ['IPOLSDEK_RV_57'] = "ПЕНЗЕНСКАЯ";

$MESS ['IPOLSDEK_RK_58'] = "ПЕРМ";
$MESS ['IPOLSDEK_RV_58'] = "ПЕРМСКИЙ";

$MESS ['IPOLSDEK_RK_59'] = "ПСКОВ";
$MESS ['IPOLSDEK_RV_59'] = "ПСКОВСКАЯ";

$MESS ['IPOLSDEK_RK_60'] = "РОСТОВ";
$MESS ['IPOLSDEK_RV_60'] = "РОСТОВСКАЯ";

$MESS ['IPOLSDEK_RK_61'] = "РЯЗАН";
$MESS ['IPOLSDEK_RV_61'] = "РЯЗАНСКАЯ";

$MESS ['IPOLSDEK_RK_62'] = "САМАР";
$MESS ['IPOLSDEK_RV_62'] = "САМАРСКАЯ";

$MESS ['IPOLSDEK_RK_63'] = "САРАТОВ";
$MESS ['IPOLSDEK_RV_63'] = "САРАТОВСКАЯ";

$MESS ['IPOLSDEK_RK_64'] = "СВЕРДЛОВ";
$MESS ['IPOLSDEK_RV_64'] = "СВЕРДЛОВСКАЯ";

$MESS ['IPOLSDEK_RK_65'] = "СМОЛЕНСК";
$MESS ['IPOLSDEK_RV_65'] = "СМОЛЕНСКАЯ";

$MESS ['IPOLSDEK_RK_66'] = "ТОМСК";
$MESS ['IPOLSDEK_RV_66'] = "ТОМСКАЯ";

$MESS ['IPOLSDEK_RK_67'] = "ТЮМЕН";
$MESS ['IPOLSDEK_RV_67'] = "ТЮМЕНСКАЯ";

$MESS ['IPOLSDEK_RK_68'] = "УЛЬЯНОВСК";
$MESS ['IPOLSDEK_RV_68'] = "УЛЬЯНОВСКАЯ";

$MESS ['IPOLSDEK_RK_69'] = "ЧЕЛЯБИНСК";
$MESS ['IPOLSDEK_RV_69'] = "ЧЕЛЯБИНСКАЯ";

$MESS ['IPOLSDEK_RK_70'] = "ЗАБАЙКАЛ";
$MESS ['IPOLSDEK_RV_70'] = "ЗАБАЙКАЛЬСКИЙ";

$MESS ['IPOLSDEK_RK_71'] = "ЯРОСЛАВ";
$MESS ['IPOLSDEK_RV_71'] = "ЯРОСЛАВСКАЯ";

$MESS ['IPOLSDEK_RK_72'] = "ЕВРЕЙ";
$MESS ['IPOLSDEK_RV_72'] = "ЕВРЕЙСКАЯ";

$MESS ['IPOLSDEK_RK_73'] = "ХАНТЫ";
$MESS ['IPOLSDEK_RV_73'] = "ХАНТЫ-МАНСИЙСКИЙ";

$MESS ['IPOLSDEK_RK_74'] = "ЮГРА";
$MESS ['IPOLSDEK_RV_74'] = "ХАНТЫ-МАНСИЙСКИЙ";

$MESS ['IPOLSDEK_RK_75'] = "ЧУКОТ";
$MESS ['IPOLSDEK_RV_75'] = "ЧУКОТСКИЙ";

$MESS ['IPOLSDEK_RK_76'] = "ЯМАЛО";
$MESS ['IPOLSDEK_RV_76'] = "ЯМАЛО-НЕНЕЦКИЙ";

$MESS ['IPOLSDEK_RK_77'] = "НЕНЕЦК";
$MESS ['IPOLSDEK_RV_77'] = "НЕНЕЦКИЙ";

$MESS ['IPOLSDEK_RK_78'] = "КРЫМ";
$MESS ['IPOLSDEK_RV_78'] = "КРЫМ";

$MESS ['IPOLSDEK_RK_79'] = "САХАЛИН";
$MESS ['IPOLSDEK_RV_79'] = "САХАЛИНСКАЯ";

$MESS ['IPOLSDEK_RK_80'] = "ТАМБОВ";
$MESS ['IPOLSDEK_RV_80'] = "ТАМБОВСКАЯ";

$MESS ['IPOLSDEK_RK_81'] = "ТУЛ";
$MESS ['IPOLSDEK_RV_81'] = "ТУЛЬСКАЯ";

$MESS ['IPOLSDEK_RK_82'] = "ТВЕР";
$MESS ['IPOLSDEK_RV_82'] = "ТВЕРСКАЯ";

$MESS ['IPOLSDEK_RK_83'] = "АМУР";
$MESS ['IPOLSDEK_RV_83'] = "АМУРСКАЯ";

$MESS ['IPOLSDEK_RK_84'] = "ЧЕЧ";
$MESS ['IPOLSDEK_RV_84'] = "ЧЕЧНЯ";

$MESS ['IPOLSDEK_RK_85'] = "САХА";
$MESS ['IPOLSDEK_RV_85'] = "ЯКУТИЯ";

$MESS ['IPOLSDEK_RK_86'] = "КАЛУ";
$MESS ['IPOLSDEK_RV_86'] = "КАЛУЖСКАЯ";

$MESS ['IPOLSDEK_RK_87'] = "ПЕТЕРБУРГ";
$MESS ['IPOLSDEK_RV_87'] = "ЛЕНИНГРАДСКАЯ";

$MESS ['IPOLSDEK_RK_88'] = "СЕВАСТОПОЛЬ";
$MESS ['IPOLSDEK_RV_88'] = "КРЫМ";

$MESS ['IPOLSDEK_CHANGE_YO'] = "ё";
$MESS ['IPOLSDEK_CHANGE_YE'] = "е";

$MESS ['IPOLSDEK_SIMPLECITY_1']  = "поселок городского типа";
$MESS ['IPOLSDEK_SIMPLECITY_2']  = "населенный пункт";
$MESS ['IPOLSDEK_SIMPLECITY_3']  = "курортный поселок";
$MESS ['IPOLSDEK_SIMPLECITY_4']  = "дачный поселок";
$MESS ['IPOLSDEK_SIMPLECITY_5']  = "рабочий поселок";
$MESS ['IPOLSDEK_SIMPLECITY_6']  = "почтовое отделение";
$MESS ['IPOLSDEK_SIMPLECITY_7']  = "сельское поселение";
$MESS ['IPOLSDEK_SIMPLECITY_8']  = "ж/д станция";
$MESS ['IPOLSDEK_SIMPLECITY_9']  = "станция";
$MESS ['IPOLSDEK_SIMPLECITY_10'] = "городок";
$MESS ['IPOLSDEK_SIMPLECITY_11'] = "деревня";
$MESS ['IPOLSDEK_SIMPLECITY_12'] = "микрорайон";
$MESS ['IPOLSDEK_SIMPLECITY_13'] = "станица";
$MESS ['IPOLSDEK_SIMPLECITY_14'] = "хутор";
$MESS ['IPOLSDEK_SIMPLECITY_15'] = "аул";
$MESS ['IPOLSDEK_SIMPLECITY_16'] = "село";
$MESS ['IPOLSDEK_SIMPLECITY_17'] = "поселок";
$MESS ['IPOLSDEK_SIMPLECITY_18'] = "снт";

$MESS ['IPOLSDEK_SIMPLEDIST_1']  = "район";
$MESS ['IPOLSDEK_SIMPLEDIST_2']  = "р-н";
?>