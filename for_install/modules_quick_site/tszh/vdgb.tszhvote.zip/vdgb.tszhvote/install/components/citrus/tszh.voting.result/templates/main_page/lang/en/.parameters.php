<?
$MESS ['THEMES'] = "Theme";
$MESS ['V_COLOURLESS'] = "colourless";
$MESS ['V_BLUE'] = "blue";
$MESS ['V_GREEN'] = "green";
?>