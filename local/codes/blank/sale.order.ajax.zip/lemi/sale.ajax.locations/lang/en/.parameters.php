<?
$MESS["SALE_SAL_PARAM_COUNTRY"] = "Initial country";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "Return location ID (or city otherwise)";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "The location city is optional";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Name of country form field";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Name of city (location) form field";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "City (location) change services";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Region form field name";
$MESS["CP_BSSI_NAME"] = "Location input field name";
?>