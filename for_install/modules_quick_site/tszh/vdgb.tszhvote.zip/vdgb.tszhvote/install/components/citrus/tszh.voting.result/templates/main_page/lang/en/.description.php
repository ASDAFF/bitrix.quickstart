<?
$MESS ['VOTE_MAIN_PAGE_DEFAULT_NAME'] = "Template for the main page";
$MESS ['VOTE_MAIN_PAGE_DEFAULT_DESC'] = "Template for the main page";
?>