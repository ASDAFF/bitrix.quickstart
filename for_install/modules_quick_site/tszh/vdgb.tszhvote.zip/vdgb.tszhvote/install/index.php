<?

global $MESS;
IncludeModuleLangFile(__FILE__);

if (class_exists("vdgb_tszhvote"))
	return;

class vdgb_tszhvote extends CModule {

	var $MODULE_ID = "vdgb.tszhvote";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;

	function vdgb_tszhvote() {
		$arModuleVersion = array();

		$path = str_replace("\\", "/", __FILE__);
		$path = substr($path, 0, strlen($path) - strlen("/index.php"));
		include ($path . "/version.php");

		if (is_array($arModuleVersion) && array_key_exists("VERSION", $arModuleVersion)) {
			$this->MODULE_VERSION = $arModuleVersion["VERSION"];
			$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		} else {
			$this->MODULE_VERSION = SEARCH_VERSION;
			$this->MODULE_VERSION_DATE = SEARCH_VERSION_DATE;
		}

		$this->MODULE_NAME = GetMessage("C_VOTE_MODULE_NAME");
		$this->MODULE_DESCRIPTION = GetMessage("C_VOTE_MODULE_DESC");

		$this->PARTNER_NAME = GetMessage("C_MODULE_PARTNER_NAME");
		$this->PARTNER_URI = GetMessage("C_MODULE_PARTNER_URI");
	}

	function DoInstall() {
		global $DOCUMENT_ROOT, $APPLICATION, $step;
		$step = IntVal($step);
		if ($step < 2) {
			$APPLICATION->ResetException();
			try {
				if (!$this->InstallDB())
					throw new Exception(GetMessage("C_ERROR_INSTALL_DB"));
				if (!$this->InstallEvents())
					throw new Exception(GetMessage("C_ERROR_INSTALL_EVENTS"));
				if (!$this->InstallFiles())
					throw new Exception(GetMessage("C_ERROR_INSTALL_FILES"));
			} catch (Exception $e) {
				$strAdditionalMessage = '';
				if ($ex = $APPLICATION->GetException())
					$strAdditionalMessage .= ' (' . $ex->GetString() . ')';
				$APPLICATION->ThrowException($e->GetMessage() . $strAdditionalMessage);
			}
			$APPLICATION->IncludeAdminFile(GetMessage("C_VOTE_MODULE_INSTAL_PAGE_TITLE"), $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/step1.php");
		}
	}

	function DoUninstall() {
		global $DOCUMENT_ROOT, $APPLICATION, $step;
		$step = IntVal($step);
		if ($step < 2) {
			$APPLICATION->IncludeAdminFile(GetMessage("C_VOTE_MODULE_UNINSTALL_PAGE_TITLE"), $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/unstep1.php");
		} elseif ($step < 3) {
			$APPLICATION->ResetException();
			try {
				if (!$this->UnInstallDB(array("save_tables" => $_REQUEST["save_tables"] == 1)))
					throw new Exception(GetMessage("C_ERROR_UNINSTALL_DB"));
				if (!$this->UnInstallEvents())
					throw new Exception(GetMessage("C_ERROR_UNINSTALL_EVENTS"));
				if (!$this->UnInstallFiles())
					throw new Exception(GetMessage("C_ERROR_UNINSTALL_FILES"));
			} catch (Exception $e) {
				$strAdditionalMessage = '';
				if ($ex = $APPLICATION->GetException())
					$strAdditionalMessage .= ' (' . $ex->GetString() . ')';
				$APPLICATION->ThrowException($e->GetMessage() . $strAdditionalMessage);
			}
			$APPLICATION->IncludeAdminFile(GetMessage("C_VOTE_MODULE_UNINSTALL_PAGE_TITLE"), $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/unstep2.php");
		}
	}

	function InstallDB() {
		global $DBType, $APPLICATION, $DBName, $DB;
		$errors = false;

		if (!$DB->Query("SELECT 'x' FROM b_citrus_voting WHERE 1=0", true)) {
			@set_time_limit(0);
			$DB->StartTransaction();
			$errors = $DB->RunSQLBatch($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/db/" . strtolower($DB->type) . "/install.sql");
			if ($this->errors)
				$DB->Rollback();
			else
				$DB->Commit();
		}

		if ($errors !== false) {
			$APPLICATION->ThrowException(implode("<br>", $errors));
			return false;
		}

		RegisterModule($this->MODULE_ID);
		RegisterModuleDependences("main", "OnUserDelete", $this->MODULE_ID, "CVoteUser", "DeleteByUserID");

		return true;
	}

	function UnInstallDB($arParams = array()) {
		global $DB, $DBType, $APPLICATION;

		$errors = false;

		if (!$arParams['save_tables'] && is_object($DB))
			$errors = $DB->RunSQLBatch($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/" . $this->MODULE_ID . "/install/db/" . strtolower($DB->type) . "/uninstall.sql");

		UnRegisterModuleDependences("main", "OnUserDelete", $this->MODULE_ID, "CVoteUser", "DeleteByUserID");
		UnRegisterModule($this->MODULE_ID);

		if ($errors !== false) {
			$APPLICATION->ThrowException(implode("<br>", $errors));
			return false;
		}
		return true;
	}

	function InstallFiles() {
		$errors = Array();

		if (!CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/{$this->MODULE_ID}/install/themes/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/themes/", true, true))
			$errors[] = GetMessage("C_ERROR_INSTALL_THEME_ADMIN");
		if (!CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/{$this->MODULE_ID}/install/admin/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin", true, true))
			$errors[] = GetMessage("C_ERROR_INSTALL_FILES_ADMIN");
		if (!CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/{$this->MODULE_ID}/install/components/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/components", true, true))
			$errors[] = GetMessage("C_ERROR_INSTALL_FILES_COMPONENTS");

		if (count($errors) > 0) {
			$APPLICATION->ThrowException(implode("<br>", $errors));
			return false;
		}

		return true;
	}

	function UnInstallFiles() {
		DeleteDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/{$this->MODULE_ID}/install/admin/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin");
		DeleteDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/{$this->MODULE_ID}/install/components/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/components");
		DeleteDirFilesEx("/bitrix/themes/.default/icons/{$this->MODULE_ID}/");
		unlink($_SERVER["DOCUMENT_ROOT"] . "/bitrix/themes/.default/{$this->MODULE_ID}.css");
		return true;
	}

	function InstallEvents() {
		return true;
	}

	function UnInstallEvents() {
		return true;
	}

}

?>