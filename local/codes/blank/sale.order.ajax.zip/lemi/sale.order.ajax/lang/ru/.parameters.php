<?
$MESS['SBB_DELIVERY_PAYSYSTEM'] = 'Последовательность оформления';
$MESS['SBB_TITLE_PD'] = 'Доставка -> Оплата';
$MESS['SBB_TITLE_DP'] = 'Оплата -> Доставка';
$MESS['SOA_DELIVERY_NO_AJAX'] = 'Рассчитывать стоимость доставки сразу';
$MESS['SOA_ALLOW_PAY_FROM_ACCOUNT'] = 'Позволять оплачивать с внутреннего счета';
$MESS['SOA_ONLY_FULL_PAY_FROM_ACCOUNT'] = 'Позволять оплачивать с внутреннего счета только в полном объеме';
$MESS['SBB_USE_PREPAYMENT'] = 'Использовать предавторизацию для оформления заказа (PayPal Express Checkout)';
$MESS['SOA_DISABLE_BASKET_REDIRECT'] = 'Оставаться на странице, если корзина пуста';
$MESS['SOA_SEND_NEW_USER_NOTIFY'] = 'Отправлять пользователю письмо, что он зарегистрирован на сайте';
$MESS['SOA_PATH_TO_BASKET'] = 'Страница корзины';
$MESS['PATH_TO_CATALOG'] = 'Страница каталога товаров';
$MESS['SOA_PATH_TO_PAYMENT'] = 'Страница подключения платежной системы';
$MESS['SOA_PATH_TO_PERSONAL'] = 'Страница персонального раздела';
$MESS['SOA_PATH_TO_ORDERS_LIST'] = 'Страница списка заказов';
$MESS['SOA_DELIVERY_GROUPS'] = 'Группы свойств, относящиеся к настройке доставки';
$MESS['SOA_PAY_SYSTEMS_ONLINE'] = 'Платежные системы, работающие онлайн';