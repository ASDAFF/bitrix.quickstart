<?
$MESS["CP_BSSI_NAME"] = "Nombre del campo de ubicación de ingreso ";
$MESS["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "La ciudad de ubicación es opcional.";
$MESS["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Nombre de la ciudad (ubicación) campo de formulario";
$MESS["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "ID de la ubicación de retorno (o de lo contrario la ciudad)";
$MESS["SALE_SAL_PARAM_COUNTRY"] = "País inicial";
$MESS["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Nombre del campo del formulario país";
$MESS["SALE_SAL_PARAM_ONCITYCHANGE"] = "Ciudad (ubicación) cambiar servicios";
$MESS["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Nombre del campo del formulario región";
?>