<?
$MESS['WD_REVIEWS2_ERROR_NO_CAPTCHA'] = 'Не указан защитный код';
$MESS['WD_REVIEWS2_ERROR_WRONG_CAPTCHA'] = 'Неверно указан защитный код';
$MESS['WD_REVIEWS2_ERROR_SESSID_EXPIRED'] = 'Ваша сессия истекла. Обновите страницу и попробуйте еще раз.';
$MESS['WD_REVIEWS2_ERROR_DENIED_UNREGISTERED'] = 'На сайте запрещено оставлять отзывы без авторизации.';
?>