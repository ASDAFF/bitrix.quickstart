<?
$MESS ["SAL_DEFAULT_TEMPLATE_NAME"] = "AJAX-местоположения";
$MESS ["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Динамическая форма выбора местоположения";
$MESS ["SAL_NAME"] = "Процедура оформления заказа";
?>