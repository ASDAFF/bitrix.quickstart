<?
$MESS['WEBDEBUG_REVIEWS_SUCCESS_MESSAGE'] = 'Спасибо! Ваш отзыв успешно добавлен.';

$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_EMPTY'] = 'Защитный код не указан';
$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_WRONG'] = 'Указан неверный защитный код';
$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_WRONG'] = 'Указан неверный защитный код';

$MESS['WEBDEBUG_REVIEWS_ERROR_NAME'] = 'Вы не указали имя';
$MESS['WEBDEBUG_REVIEWS_ERROR_EMAIL'] = 'Вы не указали e-mail';
$MESS['WEBDEBUG_REVIEWS_ERROR_WWW'] = 'Вы не указали веб-сайт';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_PLUS'] = 'Вы не указали достоинства';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_MINUS'] = 'Вы не указали недостатки';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_COMMENTS'] = 'Вы не указали комментарий';
?>