<?IncludeModuleLangFile(__FILE__);

function citrusTszhPaymentGetTszhList()
{
	$arResult = array();

	$rsTszh = CTszh::GetList(
		array('ID' => 'ASC'),
		array(),
		false,
		false,
		array("ID", "NAME")
	);
	while ($arTszh = $rsTszh->GetNext())
	{
		$arResult[$arTszh["ID"]] = $arTszh["NAME"];
	}

	return $arResult;
}

function tszhPaymentMonetaUsageTable($monetaEnabled = "N", $monetaOffer = "N", $radioName = "MONETA_SCHEME", $email = false, CWizardStep $wizardStep = null, $wizardReqMonetaSchemeErrorID = "REQ_MONETA_SCHEME")
{
	$result = '';

	$demoFlag = CTszhPaymentGateway::isDemo();

	if ($wizardStep)
	{
		$result .= '<link href="'.CUtil::GetAdditionalFileURL('/bitrix/js/main/core/css/core.css').'" type="text/css" rel="stylesheet" />'."\r\n";
		$result .= '<script type="text/javascript" src="'.CUtil::GetAdditionalFileURL('/bitrix/js/main/core/core.js').'"></script>'."\r\n";

		$arWizardErrors = $wizardStep->GetErrors();
		$reqMonetaSchemeErrorFlag = false;
		foreach ($arWizardErrors as $arError)
		{
			if (isset($arError[1]) && $arError[1] == $wizardReqMonetaSchemeErrorID)
			{
				$reqMonetaSchemeErrorFlag = true;
				break;
			}
		}

	}
	$result .= CUtil::InitJSCore(array('ajax', 'popup'), true);

	$result .= '<style type="text/css">';
	if ($wizardStep)
		$result .= '
			font.notetext {
				color: #008000;
			}
			.notetext {
				font-family: Arial;
				font-size: 10pt;
				font-weight: bold;
			}
		';
	$result .=
		'#moneta-usage-table {
			width: 600px;
			margin: 0 auto !important;
			border-collapse: collapse;
			border: none;
			border-spacing: 0;
		}
		#moneta-usage-table td,
		#moneta-usage-table th {
			width: 33.33%;
			padding: .3em;
			color: #000;
			text-align: center;
			border: 2px solid #000;
			background-color: #F5F9F9;
		}
		#moneta-usage-table th {
			font-size: 115%;
			line-height: 115%;
			padding: .5em;
		}
		#moneta-usage-table td.scheme1 {
			background-color: #ff5705;
		}
		#moneta-usage-table label.scheme,
		#moneta-usage-table label.scheme input {
			cursor: pointer;
		}
		#moneta-usage-table label.scheme input[disabled] {
			opacity: 1;
		}
	</style>
	';

	$result .= '<div id="moneta-procedure" style="display: none; max-width: 500px;">' . GetMessage("CITRUS_TSZH_PAYMENT_MONETA_PROCEDURE", Array("#EMAIL#" => $email === false ? GetMessage("CITRUS_TSZH_NEED_EMAIL") : $email)) . '</div>';

	$result .= "<script>
		var monetaProcedurePopup = new BX.PopupWindow(
			'moneta-procedure',
			null,
			{
				content: BX('moneta-procedure'),
				closeIcon: {right: '20px', top: '10px'},
				closeByEsc: true,
				zIndex: 0,
				offsetLeft: 140,
				offsetTop: 0,
				draggable: {restrict: false},
				autoHide: true,
				buttons: [
					new BX.PopupWindowButton({
						text: '" . GetMessage("CITRUS_TSZH_PAYMENT_CLOSE") . "',
						className: 'webform-button-link-cancel',
						events: {click: function(){
							this.popupWindow.close();
						}}
					})
				]
			}
		);
	</script>
	";

	$monetaOfferOnClick = "this.checked ? BX('{$radioName}1').checked='checked' : BX('{$radioName}2').checked='checked';";
	$monetaScheme2OnClick = "if (this.checked) BX('MONETA_OFFER').checked=false;";
	if ($demoFlag)
	{
		if (defined("ADMIN_SECTION") && !$wizardStep)
		{
			$clickMessage = "TSZH_MODULE_DEMO_NOTICE_ADMIN";

			$arMessage = Array(
				"DETAILS"	=> GetMessage("TSZH_MODULE_DEMO_NOTICE_ADMIN"),
				"TYPE"		=> "OK",
				"MESSAGE"	=> GetMessage("MUT_MONETA_DEMO"),
				"HTML"		=> true,
			);
			$result .= CAdminMessage::ShowMessage($arMessage);
		}
		else
		{
			$clickMessage = "TSZH_MODULE_DEMO_NOTICE";

			ob_start();
			ShowNote(GetMessage("MUT_MONETA_DEMO"));
			$html = ob_get_contents();
			ob_end_clean();
			$result .= $html . GetMessage("TSZH_MODULE_DEMO_NOTICE");
		}

		$monetaOfferOnClick = "this.checked=false; alert(monetaAlertMessage);";
		$result .= "<script>
			var monetaAlertMessage = '" . CUtil::JSEscape(GetMessage("MUT_MONETA_DEMO") . "\n\n" . strip_tags(preg_replace('#<br\s*/?>#', "\n", GetMessage($clickMessage)))) . "';
		</script>";
	}

	$result .= '<table id="moneta-usage-table">
		<tr>
			<th colspan="3">' . GetMessage("MUT_HEADER") . '</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_VARIANTS") . '
			</td>
			<td class="scheme1">
				<input type="hidden" name="' . ($wizardStep ? '__wiz_' : '') . $radioName . '" value="' . (!$reqMonetaSchemeErrorFlag && $monetaOffer == "Y" ? '1' : (!$reqMonetaSchemeErrorFlag && $monetaOffer != "Y" && $monetaEnabled=="Y" ? '2' : '')) . '" />
				<label class="scheme" for="' . $radioName . '1">' .
					($wizardStep
					 ? $wizardStep->ShowRadioField($radioName, "1", array("id" => "{$radioName}1") + (!$reqMonetaSchemeErrorFlag && $monetaOffer == "Y" ? array("checked" => "checked", "disabled" => "disabled") : array()) + (!$reqMonetaSchemeErrorFlag && ($monetaOffer == "Y" || $monetaEnabled == "Y") ? array("disabled" => "disabled") : array()))
						: '<input type="radio" id="' . $radioName . '1" name="' . $radioName . '" value="1" ' . ($monetaOffer == "Y" ? 'checked="checked"' : '') . ' ' . ($monetaOffer == "Y" || $monetaEnabled == "Y" ? 'disabled="disabled"' : '') . ' />'
					)
					. ' ' . GetMessage("MUT_SCHEME1") .
				'</label>
			</td>
			<td>
				<label class="scheme" for="' . $radioName . '2">' .
					($wizardStep
					 ? $wizardStep->ShowRadioField($radioName, "2", array("id" => "{$radioName}2", "onclick" => $monetaScheme2OnClick) + (!$reqMonetaSchemeErrorFlag && $monetaEnabled=="Y" && $monetaOffer!="Y" ? array("checked" => "checked") : array()) + (!$reqMonetaSchemeErrorFlag && ($monetaOffer == "Y" || $monetaEnabled == "Y") ? array("disabled" => "disabled") : array()))
						: '<input type="radio" id="' . $radioName . '2" name="' . $radioName . '" value="2" ' . ($monetaEnabled=="Y" && $monetaOffer!="Y" ? 'checked="checked"' : '') . ' ' . ($monetaOffer == "Y" || $monetaEnabled == "Y" ? 'disabled="disabled"' : '') . ' onclick="' . $monetaScheme2OnClick . '" />'
					)
					. ' ' . GetMessage("MUT_SCHEME2") .
				'</label>
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_DOGOVOR") . '
			</td>
			<td class="scheme1">
				+
			</td>
			<td>
				&ndash;
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_PERSONAL_AREA") . '
			</td>
			<td class="scheme1">
				+
			</td>
			<td>
				&ndash;
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_COMMISSION") . '
			</td>
			<td class="scheme1">
				' . GetMessage("MUT_COMMISSION_PAYEE") . '
			</td>
			<td>
				' . GetMessage("MUT_COMMISSION_PAYER") . '
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_TRANSFER") . '
			</td>
			<td class="scheme1">
				' . GetMessage("MUT_BY_TEMPLATE") . '
			</td>
			<td>
				' . GetMessage("MUT_DAILY") . '
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_PAY_WAYS") . '
			</td>
			<td class="scheme1">
				' . GetMessage("MUT_PAY_SYSTEMS") . ' ' . GetMessage("MUT_PAY_OTHERS") . '
				<br>
				<strong>' . GetMessage("MUT_PAY_WAYS_20") . '</strong>
			</td>
			<td>
				' . GetMessage("MUT_PAY_SYSTEMS") . '
			</td>
		</tr>
		<tr>
			<td>
				' . GetMessage("MUT_ACTIVITY") . '
			</td>
			<td class="scheme1">
				<input type="hidden" name="MONETA_OFFER" value="' . ($monetaOffer == "Y" ? 'Y' : '') . '" />
				<label for="moneta_offer_checkbox" title="">' . 
					($wizardStep
						? $wizardStep->ShowCheckboxField("MONETA_OFFER", "Y", (array("id" => "MONETA_OFFER", "onclick" => $monetaOfferOnClick) + ($monetaOffer == "Y" || $monetaEnabled=="Y" ? array("disabled" => "disabled") : array())))
						: '<input id="MONETA_OFFER" type="checkbox" name="MONETA_OFFER" value="Y" ' . ($monetaOffer == "Y" ? 'checked="checked"' : '') . ($monetaOffer == "Y" || $monetaEnabled == "Y" ? 'disabled="disabled"' : '') . ' onclick="' . $monetaOfferOnClick . '" />'
					)
					. GetMessage("CITRUS_TSZH_PAYMENT_MONETA_OFFER") . '
				</label>'
				.
				(strlen(trim($email)) <= 0 || !check_email($email) ? '<p>' . GetMessage("CITRUS_TSZH_NEED_EMAIL") . '</p>' : '')
				. '
			</td>
			<td>
				'. GetMessage("MUT_DEFAULT") . '
			</td>
		</tr>
	</table>
	';

	if ($wizardStep)
		return $result;
	else
		echo $result;
}
