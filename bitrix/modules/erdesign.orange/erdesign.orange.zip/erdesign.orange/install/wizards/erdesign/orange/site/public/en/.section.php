<?
$sSectionName = "�������";
$arDirProperties = array(
   "description" => "#SITE_DESCRIPTION#",
   "keywords" => "#SITE_KEYWORDS#",
   "robots" => "index, follow"
);
?>