<?
$MESS ['VOTE_ID_TIP'] = "Select here one of the existing polls. You can select <b><i>(other)</i></b> and specify the ID of an external poll, for example: <b>={\$_REQUEST[\"VOTE_ID\"]}</b>.";
$MESS ['VOTE_RESULT_TEMPLATE_TIP'] = "Specifies the path name of the poll result chart page. The URL should contain a parameter to pass the poll ID. The default value is <b>vote_result.php?VOTE_ID=#VOTE_ID#</b>.";
$MESS ['CACHE_TYPE_TIP'] = "<i>Auto</i>: the cache is valid during the time predefined in the cache settings;<br /><i>Cache</i>: always cache for the period specified in the next field;<br /><i>Do not cahce</i>: no caching is performed.";
$MESS ['CACHE_TIME_TIP'] = "Specify here the period of time during which the cache is valid.";
?>