<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!CModule::IncludeModule("citrus.tszh"))
{
	ShowError(GetMessage("TSZH_MODULE_NOT_INSTALLED"));
	return;
}
if (!CModule::IncludeModule("citrus.tszhpayment"))
{
	ShowError(GetMessage("TSZH_PAYMENT_MODULE_NOT_INSTALLED"));
	return;
}

$arParams["MINIMUM_SUMM"] = FloatVal($arParams["MINIMUM_SUMM"]);
if($arParams["MINIMUM_SUMM"] <= 0) {
	$arParams["MINIMUM_SUMM"] = 0;
}

$arParams["PAY_SYSTEM"] = IntVal($arParams["PAY_SYSTEM"]);
$arResult["PAY_SYSTEM"] = CTszhPaySystem::GetByID($arParams["PAY_SYSTEM"]);
if (!is_array($arResult["PAY_SYSTEM"])) {
	ShowError(GetMessage("TSZH_PAYMENT_SYSTEM_DOESNT_EXISTS"));
	return;
}

$arParams['VAR'] = 'pay_amount';

$arNotes = Array();
$arErrors = Array();
$arResult['AMOUNT_TO_SHOW'] = '';
if ($USER->IsAuthorized() && $account = CTszhAccount::GetByUserID($USER->GetID()))
{
	$lastPeriod = CTszhAccountPeriod::GetList(
		Array('PERIOD_DATE' => 'DESC', 'PERIOD_ID' => 'DESC'),
		Array("ACCOUNT_ID" => $account["ID"], "PERIOD_ACTIVE" => "Y", "!PERIOD_ONLY_DEBT" => "Y"),
		false,
		false,
		array("ID", "DEBT_END")
	)->GetNext(true, false);
	$arResult["AMOUNT_TO_SHOW"] = $lastPeriod["DEBT_END"];
}

$arResult['CURRENCY_TITLE'] = GetMessage("TSZH_PAYMENT_CURRENCY_TITLE");
$arResult["ACTION"] = $APPLICATION->GetCurPageParam("", Array($arParams["VAR"]));

// ������ ����������� ��� �� �������������� �������������
if (!$USER->IsAuthorized())
{
	// ������� ID �������� ����������, ��� ������� �������� ��������� ���������� ������
	$rsPS = CTszhPaySystem::GetList(Array(), Array("ACTION_FILE" => $arResult["PAY_SYSTEM"]["ACTION_FILE"]), Array("TSZH_ID"));
	$tszhIdList = array();
	while ($arPS = $rsPS->Fetch())
		$tszhIdList[] = $arPS['TSZH_ID'];

	$rsTszh = CTszh::GetList(array("NAME" => "ASC"), array("LID" => SITE_ID, "@ID" => $tszhIdList));
	$arResult["TSZH"] = array();
	while ($arTszh = $rsTszh->GetNext())
	{
		$arResult["TSZH"][$arTszh["ID"]] = $arTszh["NAME"];
		$arResult["TSZH_LIST"][$arTszh["ID"]] = $arTszh;
	}

	// ���� � �������� �������� ID �����������, ��������� ������ ������ ���� ������������
	if (is_set($arParams, "TSZH_ID") && $arParams["TSZH_ID"] > 0)
		$arResult["TSZH"] = array_intersect_key($arResult["TSZH"], array(intval($arParams["TSZH_ID"]) => 1));
}

if (isset($_GET['needauth']))
	$APPLICATION->set_cookie('citrus_tszhpayment_needauth', '1', strtotime('+1 month'));

$arResult["USER_FIELDS"] = $GLOBALS["USER_FIELD_MANAGER"]->GetUserFields(CTszhPayment::USER_FIELD_ENTITY, 0, LANGUAGE_ID);
if ($_SERVER["REQUEST_METHOD"] == "POST" && check_bitrix_sessid() && IntVal($_POST["pay_system_id"]) == $arResult['PAY_SYSTEM']['ID'])
{
	// ���� ������������ �� ����������� � ������ ���������� ��ƻ
	if ($USER->IsAuthorized() && !CTszh::IsTenant())
	{
		$APPLICATION->AuthForm(GetMessage("TSZH_NOT_A_MEMBER"), true, true, "N", false);
		return;
	}

	if (!is_numeric($_POST[$arParams["VAR"]])) {
		$arErrors[] = GetMessage("TSZH_PAYMENT_DO_AMOUNT_ERROR");
		$arResult['AMOUNT_TO_SHOW'] = htmlspecialchars($_POST[$arParams["VAR"]]);
	}

	if (!$USER->IsAuthorized() && !isset($_POST['payment_step2']))
	{
		if (isset($_GET['needauth']) || $APPLICATION->get_cookie('citrus_tszhpayment_needauth'))
		{
			$APPLICATION->AuthForm(GetMessage("CITRUS_TSZHPAYMENT_NEED_AUTH"), true, true, "N", false);
			return;
		}
		$arResult["UNATH_PAYMENT"] = "Y";
		$lastPayment = $APPLICATION->get_cookie("citrus_tszhpayment_lastpayment");
		if ($lastPayment)
		{
			$rsPayment = CTszhPayment::GetList(Array(), Array(
				"ID" => $lastPayment,
				"LID" => SITE_ID,
				"=USER_ID" => false,
			));
			if ($arLastPayment = $rsPayment->GetNext())
			{
				$needFields = Array("C_PAYEE_NAME", "C_ADDRESS", "C_ACCOUNT", "TSZH_ID");
				$arResult["FIELDS"] = Array();
				foreach ($needFields as $field)
				{
					if (isset($arLastPayment[$field]))
						$arResult["FIELDS"][$field] = $arLastPayment[$field];
				}
			}
		}

		if (is_set($_GET, "summ") && is_numeric($_GET["summ"]))
			$arResult["AMOUNT_TO_SHOW"] = $arResult["FIELDS"][$arParams["VAR"]] = htmlspecialcharsbx($_GET["summ"]);
		$this->IncludeComponentTemplate();
		return;
	}

	if (!$USER->IsAuthorized())
	{
		$arResult["UNATH_PAYMENT"] = "Y";

		$arResult["FIELDS"] = $_POST;
		array_map('htmlspecialcharsbx', $arResult["FIELDS"]);

		$arResult["FIELDS"]["C_PAYEE_NAME"] = trim($arResult["FIELDS"]["C_PAYEE_NAME"]);
		if (!strlen($arResult["FIELDS"]["C_PAYEE_NAME"]))
			$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_PAYEE_NAME");

		$arResult["FIELDS"]["C_ADDRESS"] = trim($arResult["FIELDS"]["C_ADDRESS"]);
		if (!strlen($arResult["FIELDS"]["C_ADDRESS"]))
			$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_C_ADDRESS");

		$arResult["FIELDS"]["C_ACCOUNT"] = trim($arResult["FIELDS"]["C_ACCOUNT"]);
		
		if (!strlen($arResult["FIELDS"]["C_ACCOUNT"])) 
		{
			$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_C_ACCOUNT");
		} 
		else 
		{
			if (!CTszh::hasDemoDataOnly($arResult["FIELDS"]["TSZH_ID"]) && !CTszhAccount::GetByXmlID($arResult["FIELDS"]["C_ACCOUNT"]))
			{
				$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_NO_C_ACCOUNT");
			}
		}
		if (!preg_match('#[\d+]+#', $arResult["FIELDS"]["C_ACCOUNT"]))
			$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_C_ACCOUNT_INCORRECT");

		$arResult["FIELDS"]["TSZH_ID"] = intval($arResult["FIELDS"]["TSZH_ID"]);
		if (!array_key_exists($arResult["FIELDS"]["TSZH_ID"], $arResult["TSZH"]))
			$arErrors[] = GetMessage("CITRUS_TSZHPAYMENT_ERROR_TSZH_ID");
	}

	$price = FloatVal($_POST[$arParams["VAR"]]);
	if ($price < $arParams['MINIMUM_SUMM']) {
		$arErrors[] = str_replace('#SUMM#', number_format($arParams['MINIMUM_SUMM'], 2, ',', ''), GetMessage("TSZH_PAYMENT_DO_ERROR_MINIMUM_SUMM"));
		$arResult['AMOUNT_TO_SHOW'] = $arResult["FIELDS"][$arParams["VAR"]] = $price;
	}

	if (count($arErrors) <= 0)
	{
		$arFields = array(
			"LID" => SITE_ID,
			"SUMM" => $price,
			"CURRENCY" => "RUB",
			"PAY_SYSTEM_ID" => $arResult["PAY_SYSTEM"]["ID"],
		);
		if ($USER->IsAuthorized())
		{
			$arAccount = CTszhAccount::GetByUserID($USER->GetID());
			$arFields["USER_ID"] = $USER->GetID();
			$arFields["ACCOUNT_ID"] = $arAccount['ID'];
			$arFields["TSZH_ID"] = $arAccount["TSZH_ID"];
		}
		else
		{
			$arFields = $arFields + Array(
				"C_PAYEE_NAME" => $arResult["FIELDS"]["C_PAYEE_NAME"],
				"C_ADDRESS" => $arResult["FIELDS"]["C_ADDRESS"],
				"C_COMMENTS" => $arResult["FIELDS"]["C_COMMENTS"],
				"C_ACCOUNT" => $arResult["FIELDS"]["C_ACCOUNT"],
				"TSZH_ID" => $arResult["FIELDS"]["TSZH_ID"],
			);
			$rsItems = CTszhAccount::GetList(
				array(), 
				array("XML_ID" => $arResult["FIELDS"]["C_ACCOUNT"], "TSZH_ID" => $arResult["FIELDS"]["TSZH_ID"]), 
				false, 
				array(), 
				array()
			);
			if ($arItem = $rsItems->Fetch()):
				$arFields["ACCOUNT_ID"] = $arItem['ID'];
			endif;
			
		}
		$GLOBALS["USER_FIELD_MANAGER"]->EditFormAddFields(CTszhPayment::USER_FIELD_ENTITY, $arFields);

		$arPaySystem = CTszhPaySystem::GetByID($arResult["PAY_SYSTEM"]["ID"]);
		if (strlen($arPaySystem['CURRENCY']) > 0)
			$arFields["CURRENCY"] = $arPaySystem['CURRENCY'];
		
		
		if (count($arErrors) <= 0)
			$paymentID = CTszhPayment::Add($arFields);
			
		if ($paymentID)
		{
			$APPLICATION->set_cookie("citrus_tszhpayment_lastpayment", $paymentID, strtotime("+1 year"), "/");
			$redirectURL = $APPLICATION->GetCurPageParam("payment=" . $paymentID, Array('payment'));
			LocalRedirect($redirectURL);
		}
		else
		{
			$arErrors[] = GetMessage("TSZH_PAYMENT_DO_ERROR_ADDING_PAYMENT");
			if ($ex = $GLOBALS["APPLICATION"]->GetException())
				$arErrors[] = $ex->GetString();
		}

	}
}
elseif (is_set($_GET, "summ") && is_numeric($_GET["summ"]))
	$arResult["AMOUNT_TO_SHOW"] = $arResult["FIELDS"][$arParams["VAR"]] = htmlspecialcharsbx($_GET["summ"]);

$arResult["MAKE_PAYMENT_URL"] = $arParams["MAKE_PAYMENT_URL"] = $APPLICATION->GetCurPageParam("window=1", array("window", "bxajaxid", "AJAX_CALL"));
$arResult["WINDOW"] = is_set($_REQUEST, "window");

$paymentID = IntVal($_REQUEST['payment']);
if ($paymentID > 0)
{
	$arFilter = array(
		"ID" => $paymentID,
		"USER_ID" => $USER->IsAuthorized() ? $USER->GetID() : false,
	);
	$arPayment = CTszhPayment::GetList(Array(), $arFilter, false, false, array("*", "UF_*"))->GetNext();
	if (!is_array($arPayment))
	{
		ShowError(GetMessage("CITRUS_TSZHPAYMENT_NOT_FOUND"));
		return;
	}
	if ($arPayment["PAY_SYSTEM_ID"] == $arResult["PAY_SYSTEM"]["ID"])
	{
		$arResult["PAYMENT"] = $arPayment;
		if ($arResult["PAY_SYSTEM"]["NEW_WINDOW"] != "Y" || $arResult["WINDOW"])
		{
			CTszhPaySystem::InitParamArrays($arResult["PAYMENT"], $arResult["PAY_SYSTEM"]["PARAMS"]);

			$pathToAction = $_SERVER["DOCUMENT_ROOT"].$arResult["PAY_SYSTEM"]["ACTION_FILE"];

			$pathToAction = str_replace("\\", "/", $pathToAction);
			while (substr($pathToAction, strlen($pathToAction) - 1, 1) == "/")
				$pathToAction = substr($pathToAction, 0, strlen($pathToAction) - 1);

			if (file_exists($pathToAction))
			{
				if (is_dir($pathToAction) && file_exists($pathToAction."/payment.php"))
					$pathToAction .= "/payment.php";

				$arResult["PAY_SYSTEM"]["PATH_TO_ACTION"] = $pathToAction;
			}
		}
		else
		{
			$arNotes[] = GetMessage("PAYMENT_CREATED");
			//$redirectURL = str_replace("#ID#", $paymentID, $arParams["MAKE_PAYMENT_URL"]);
			//LocalRedirect($redirectURL);
		}
	}
}

$arResult['ERROR_MESSAGE'] = count($arErrors) > 0 ? implode('<br />&mdash; ', $arErrors) : false;
$arResult['NOTE_MESSAGE'] = count($arNotes) > 0 ? implode('<br />&mdash; ', $arNotes) : false;

$this->IncludeComponentTemplate();
?>