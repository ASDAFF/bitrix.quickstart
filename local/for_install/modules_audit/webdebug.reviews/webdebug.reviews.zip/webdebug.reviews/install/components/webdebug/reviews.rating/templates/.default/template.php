<?if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();?>

<div class="webdebug-reviews-rating-value" style="width:<?=round($arResult["MAX_RATING"]*12)?>px">
	<div class="webdebug-reviews-rating-value-stars" style="width:<?=round($arResult["RATING"]*12)?>px">
		
	</div>
</div>