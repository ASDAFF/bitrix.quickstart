<?
$MESS ['IPOLSDEK_DEL_TEXT'] = "<span style='color:red'>Модуль \"Интеграция со СДЭК\" удален.</span><br>";
?>