<?
$MESS['CP_BSSI_NAME'] = "Ім'я поля введення місцезнаходження";
$MESS['SALE_SAL_PARAM_ALLOW_EMPTY_CITY'] = "Вибір міста місцезнаходження не обов'язковий";
$MESS['SALE_SAL_PARAM_CITY_INPUT_NAME'] = "Ім'я поля форми для міста (місцезнаходження)";
$MESS['SALE_SAL_PARAM_CITY_OUT_LOCATION'] = "Повертати ID місцезнаходження (в іншому випадку — міста)";
$MESS['SALE_SAL_PARAM_COUNTRY'] = "Стартове значення країни";
$MESS['SALE_SAL_PARAM_COUNTRY_INPUT_NAME'] = "Ім'я поля форми для країни";
$MESS['SALE_SAL_PARAM_ONCITYCHANGE'] = "Обробник зміни значення міста (місцезнаходження)";
$MESS['SALE_SAL_PARAM_REGION_INPUT_NAME'] = "Ім'я поля форми для регіону";
?>