<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!CModule::IncludeModule("vdgb.tszhvote"))
	return;

$arGroup = array();

$rs = CCitrusPollGroup::GetList(array("SORT" => "ID"), array("ACTIVE" => "Y"), array("ID","NAME","TITLE","LID"));
if (is_object($rs)) {
	while($arrGroup = $rs->Fetch()) {
		$arGroup[$arrGroup["ID"]] = "[".$arrGroup["ID"]."] ".$arrGroup["LID"]."-".$arrGroup["NAME"];
	}
}

$arTypeDiogram = array(
	"0" => GetMessage("TypeCircul"),
	"1" => GetMessage("TypeGistogram"),
);

$arLimitFieldNames = Array(
	"-" => GetMessage("CVE_F_NO_FIELD"),
	"ID" => GetMessage("CVE_F_ID"),
	"CREATED_BY" => GetMessage("CVE_F_CREATED_BY"),
);

$arComponentParameters = array(
	"GROUPS" => array(
		"SETTINGS" => array(
			"SORT" => 130,
			"NAME" => GetMessage("MAIN_SETINGS"),
		),
            
		"RESULT_SETINGS" => array(
			"SORT" => 130,
			"NAME" => GetMessage("RESULT_SETINGS"),
		),

	),
	"PARAMETERS" => array(
            
		"GROUP_ID" => array(
			"NAME" => GetMessage("GROUP_ID"),
			"TYPE" => "LIST",
			"PARENT" => "SETTINGS",
			"VALUES" => $arGroup,
			"MULTIPLE"=>"N",
			"ADDITIONAL_VALUES"=>"Y",
		),
		"LIMIT_FIELD_NAME" => Array(
			"PARENT" => "BASE",
			"NAME" => GetMessage("CVE_LIMIT_FIELD_NAME"),
			"TYPE" => "LIST",
			"VALUES" => $arLimitFieldNames,
			"DEFAULT" => 'CREATED_BY',
			"ADDITIONAL_VALUES" => "Y",
		),
		"LIMIT_FIELD_VALUE" => Array(
			"PARENT" => "BASE",
			"NAME" => GetMessage("CVE_LIMIT_FIELD_VALUE"),
			"TYPE" => "STRING",
			"DEFAULT" => '={$USER->GetID()}',
		),
		"VARIABLE_ALIASES" => Array(
			"VOTING_ID" => Array("NAME" => GetMessage("VOTE_ID_TITLE")),
		),
		"SEF_MODE" => Array(
			"vote" => array(
				"NAME" => GetMessage("FORM_PAGE"),
				"DEFAULT" => "",
				"VARIABLES" => array(),
			),
			"detail" => array(
				"NAME" => GetMessage("RESULT_PAGE"),
				"DEFAULT" => "#VOTING_ID#/",
				"VARIABLES" => array("#VOTING_ID#"),
			),
		),
		"VOTE_TYPE_DIOGRAM" => array(
			"NAME" => GetMessage("DIOGRAM_TYPE_ID"),
			"TYPE" => "LIST",
			"PARENT" => "RESULT_SETINGS",
			"VALUES" => $arTypeDiogram,
			"MULTIPLE"=>"N",
			"REFRESH" => "N",
			"ADDITIONAL_VALUES"=>"Y",
		),
	)
);

?>