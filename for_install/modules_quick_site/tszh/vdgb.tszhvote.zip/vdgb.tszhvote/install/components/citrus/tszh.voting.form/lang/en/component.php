<?
$MESS["VOTE_MODULE_IS_NOT_INSTALLED"] = "Polls module is not installed.";
$MESS["VOTE_ACCESS_DENIED"] = "Access denied for this poll.";
$MESS["VOTE_NOT_FOUND"] = "Poll not found.";
$MESS["VOTE_OK"] = "Thank you for voting.";
$MESS["VOTE_ALREADY_VOTE"] = "You can not take part in this poll twice.";
$MESS["VOTE_RED_LAMP"] = "Poll is not active.";
$MESS["VOTE_EMPTY"] = "Poll not found.";
$MESS["USER_VOTE_EMPTY"] = "Please select an option.";
$MESS["VOTE_BAD_CAPTCHA"] = "The code you have typed is incorrect.";
$MESS["VOTE_NO_CAPTCHA"] = "The check code is missing.";
$MESS["VOTE_REQUIRED_MISSING"] = "You did not answer the mandatory question.";
?>