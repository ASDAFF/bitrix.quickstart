<?
$MESS['WEBDEBUG_REVIEWS_IBLOCK_TYPE'] = 'Тип инфоблока';
$MESS['WEBDEBUG_REVIEWS_IBLOCK_ID'] = 'Инфоблок';
$MESS['WEBDEBUG_REVIEWS_ELEMENT_ID'] = 'ID элемента';
$MESS['WEBDEBUG_REVIEWS_ELEMENT_CODE'] = 'Код элемента';
$MESS['WEBDEBUG_REVIEWS_VOTE'] = 'Параметр, по которому выводим средний рейтинг';
$MESS['WEBDEBUG_REVIEWS_MAX_RATING'] = 'Максимальный рейтинг';
?>