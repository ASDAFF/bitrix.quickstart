<?
$MESS['WEBDEBUG_REVIEWS_SUCCESS_MESSAGE'] = 'Спасибо! Ваш отзыв успешно добавлен.';

$MESS['WEBDEBUG_REVIEWS_FIELD_NAME_1'] = 'Дополнительное поле #1';
$MESS['WEBDEBUG_REVIEWS_FIELD_NAME_2'] = 'Дополнительное поле #2';
$MESS['WEBDEBUG_REVIEWS_FIELD_NAME_3'] = 'Дополнительное поле #3';
$MESS['WEBDEBUG_REVIEWS_FIELD_NAME_4'] = 'Дополнительное поле #4';
$MESS['WEBDEBUG_REVIEWS_FIELD_NAME_5'] = 'Дополнительное поле #5';

$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_EMPTY'] = 'Защитный код не указан';
$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_WRONG'] = 'Указан неверный защитный код';
$MESS['WEBDEBUG_REVIEWS_ERROR_CAPTCHA_WRONG'] = 'Указан неверный защитный код';

$MESS['WEBDEBUG_REVIEWS_ERROR_NAME'] = 'Вы не указали имя';
$MESS['WEBDEBUG_REVIEWS_ERROR_EMAIL'] = 'Вы не указали e-mail';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_PLUS'] = 'Вы не указали достоинства';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_MINUS'] = 'Вы не указали недостатки';
$MESS['WEBDEBUG_REVIEWS_ERROR_TEXT_COMMENTS'] = 'Вы не указали комментарий';
$MESS['WEBDEBUG_REVIEWS_ERROR_VOTE'] = 'Вы не указали \'%s\'';
?>