<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

foreach($arResult['DELIVERY_SERVICES'][3]['STORES'] as &$arItem) {
    $arResult['STORES_PICKUP'][] = array(
        "x" => $arItem['GPS_N'],
        "y" => $arItem['GPS_S'],
        "desc" => $arItem['ADDRESS']
    );
}
unset($arItem);

//Indi\Main\Console::log($arResult);

$cp = $this->__component; // объект компонента

if (is_object($cp))
{
    // добавим в arResult компонента два поля - MY_TITLE и IS_OBJECT
    $cp->arResult['STORES_PICKUP'] = $arResult['STORES_PICKUP'];
    $cp->SetResultCacheKeys(array('STORES_PICKUP'));

}