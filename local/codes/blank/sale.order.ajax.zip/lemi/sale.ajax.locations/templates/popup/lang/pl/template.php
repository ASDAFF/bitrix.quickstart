<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "inne (wprowadzanie ręczne)";
$MESS["PUP_NULL"] = "Wprowadź miasto";
?>