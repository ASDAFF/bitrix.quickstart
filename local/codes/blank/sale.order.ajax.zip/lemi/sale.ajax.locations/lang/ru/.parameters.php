<?
$MESS ["SALE_SAL_PARAM_COUNTRY"] = "Стартовое значение страны";
$MESS ["SALE_SAL_PARAM_CITY_OUT_LOCATION"] = "Возвращать ID местоположения (в противном случае - города)";
$MESS ["SALE_SAL_PARAM_ALLOW_EMPTY_CITY"] = "Выбор города местоположения не обязателен";
$MESS ["SALE_SAL_PARAM_COUNTRY_INPUT_NAME"] = "Имя поля формы для страны";
$MESS ["SALE_SAL_PARAM_REGION_INPUT_NAME"] = "Имя поля формы для региона";
$MESS ["SALE_SAL_PARAM_CITY_INPUT_NAME"] = "Имя поля формы для города (местоположения)";
$MESS ["SALE_SAL_PARAM_ONCITYCHANGE"] = "Обработчик смены значения города (местоположения)";
$MESS ['CP_BSSI_NAME'] = "Имя поля ввода местоположения";

?>