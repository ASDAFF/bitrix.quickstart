<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?$APPLICATION->IncludeComponent(
	"citrus:tszh.voting.result",
	"",
	Array(
		"GROUP_ID" => $arParams['GROUP_ID'],
		"VOTING_ID" => $arResult['VARIABLES'],
		"VOTE_TYPE_DIOGRAM" => $arParams['VOTE_TYPE_DIOGRAM'],
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "36000000",
		"CACHE_NOTES" => ""
	),
	$component
);?>