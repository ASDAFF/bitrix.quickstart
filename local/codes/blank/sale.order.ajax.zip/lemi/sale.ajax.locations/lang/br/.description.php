<?
$MESS["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Formulário de seleção de local dinâmico";
$MESS["SAL_DEFAULT_TEMPLATE_NAME"] = "Locais (AJAX)";
$MESS["SAL_NAME"] = "Procedimento de pedido";
?>