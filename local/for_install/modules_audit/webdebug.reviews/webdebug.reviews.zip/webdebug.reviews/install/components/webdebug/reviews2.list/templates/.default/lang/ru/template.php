<?
$MESS['WD_REVIEWS2_NO_REVIEWS'] = 'Отзывов пока нет.';
$MESS['WD_REVIEWS2_IS_REVIEW_HELPFUL'] = 'Отзыв полезен?';
?>