<?
$MESS['LIVE_MODULE_NAME'] = "LiveTex";
?>