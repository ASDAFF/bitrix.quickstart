<?
$MESS["SAL_DEFAULT_TEMPLATE_NAME"] = "Vietos (AJAX)";
$MESS["SAL_DEFAULT_TEMPLATE_DESCRIPTION"] = "Dinaminė vietos pasirinkimo forma";
$MESS["SAL_NAME"] = "Užsakymo procedūra";
?>