<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/artdepo.gallery/admin/artdepo_gallery_ajax.php");?>
