<?
    class CStartShopExchange1COrder
    {
        private $Root = null;

        public function __construct($oRoot)
        {
            $this->Root = $oRoot;
        }
    }
?>