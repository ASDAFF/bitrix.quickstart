<?
$MESS["PUP_NULL"] = "Enter a city";
$MESS["LOC_DEFAULT_NAME_NULL"] = "other (manual entry)";
?>