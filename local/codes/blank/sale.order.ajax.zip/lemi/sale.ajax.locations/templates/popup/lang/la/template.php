<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "otros (ingreso manual)";
$MESS["PUP_NULL"] = "Entrar en una ciudad";
?>