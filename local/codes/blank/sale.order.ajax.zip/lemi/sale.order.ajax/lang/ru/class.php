<?php
$MESS['SOA_FIELD_NULL'] = 'поле не заполнено';
$MESS['SOA_ERROR_SELECT_SDEK_PICKUP'] = 'Вы не выбрали точку самовывоза';