<?
$MESS['WEBDEBUG_REVIEWS_HEADER'] = 'Отзывы о ';
$MESS['WEBDEBUG_REVIEWS_NO_ITEMS'] = 'Вы можете стать первым, кто оставит отзыв о <strong>%s</strong>';
$MESS['WEBDEBUG_REVIEWS_TEXT_PLUS'] = 'Преимущества:';
$MESS['WEBDEBUG_REVIEWS_TEXT_MINUS'] = 'Недостатки:';
$MESS['WEBDEBUG_REVIEWS_TEXT_COMMENTS'] = 'Комментарий:';
?>