<?
$webdebug_reviews_default_option = array(
	"show_version_1" => "Y",
	"use_epilog_for_scripts_include" => "N",
	"skip_sessid_check" => "Y",
	"show_target_links" => "Y",
	"auto_jquery" => "N",
	
	"form_field_name" => "wd_reviews2_fields",
	"form_rating_name" => "wd_reviews2_rating",
	"update_iblock_elements" => "Y",
	"auto_create_iblock_props" => "Y",
	"antibot_field_name" => "field_1",
	
	"vote_name_0" => "-",
	"vote_name_1" => "-",
	"vote_name_2" => "-",
	"vote_name_3" => "-",
	"vote_name_4" => "-",
	"vote_name_5" => "-",
	"vote_name_6" => "-",
	"vote_name_7" => "-",
	"vote_name_8" => "-",
	"vote_name_9" => "-",
);
?>
