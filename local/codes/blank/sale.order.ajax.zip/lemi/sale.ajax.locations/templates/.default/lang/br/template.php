<?
$MESS["LOC_DEFAULT_NAME_NULL"] = "outro";
$MESS["SAL_CHOOSE_CITY"] = "(selecionar cidade)";
$MESS["SAL_CHOOSE_CITY_OTHER"] = "(outro)";
$MESS["SAL_CHOOSE_COUNTRY"] = "(selecionar país)";
$MESS["SAL_CHOOSE_REGION"] = "(selecionar uma região)";
?>