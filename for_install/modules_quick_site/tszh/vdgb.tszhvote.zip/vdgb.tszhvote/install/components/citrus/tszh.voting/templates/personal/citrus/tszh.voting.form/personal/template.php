<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>

<div class="voting">
    
<?if (isset($arResult["ACCESS_ERROR"]) && strlen($arResult["ACCESS_ERROR"]) > 0)
	ShowError($arResult["ACCESS_ERORR"]);
if (strlen($arResult["ERROR_MESSAGE"]) > 0)
	ShowError($arResult["ERROR_MESSAGE"]);
if (strlen($arResult["OK_MESSAGE"]) > 0)
    ShowNote($arResult["OK_MESSAGE"]);
    
if (!empty($arResult["ITEM"])):
	
	foreach($arResult["ITEM"] as $idVoting => $voting):
		
        if ($voting["IS_VOTED"]):?>
			<?$APPLICATION->IncludeComponent(
				"citrus:tszh.voting.result",
				"personal",
				Array(
					"GROUP_ID" => $arParams['GROUP_ID'],
					"VOTING_ID" => array($idVoting),
					"VOTE_TYPE_DIOGRAM" => $this->__component->__parent->arParams['VOTE_TYPE_DIOGRAM'],
					"CACHE_TYPE" => "A",
					"CACHE_TIME" => "36000000",
					"CACHE_NOTES" => ""
				),
				$this->__component->__parent
			);?>	
			<?continue;
		endif;

        if (!isset($voting['QUESTION']))
            continue;

        if ($voting['VOTING_COMPLETED'] == "Y")
		{
            ?><div class="ok-message"><?=GetMessage("COMP_MESSAGE")?></div><?
            continue;
		}
		
		?>
        <div class="voting-form">
            <form action="<?=$APPLICATION->GetCurPage();?>" method="POST">
            	<?=bitrix_sessid_post()?>
                <input name="voting_id" type="hidden" value="<?=$idVoting?>"/>
                <input name="do_vote" type="hidden" value="1" />
                <h3><?=$voting["TITLE_TEXT"]?></h3>
                <div class="voting-date">
                	<?=GetMessage("CVF_DATES")?>:
                    <?=$voting['DATE_BEGIN']?> &mdash; <?=$voting['DATE_END']?>
                </div>
                <div class="voting-description"><?=$voting["DETAIL_TEXT"]?></div>
                <?foreach($voting["QUESTION"] as $idQuest=>$question):?>
                    <?if(isset($question["ANSWER"])):?>
                        <b><?=$question['TEXT']?></b>
                        <table class="question-table-data">
                        <?if(isset($question["ANSWER"])):?>
                            <?foreach($question["ANSWER"] as $idAnswer=>$answer):?>
                                <tr class="voting-answer">
                                    <td class="voting-answer-title">
                                        <?if($question['IS_MULTIPLE'] == "Y"):?>
                                            <input type="checkbox"  name="Q[<?=$idQuest?>][]" value="<?=$answer['ID']?>"/>
                                        <?else:?>
                                            <input type="radio" name="Q[<?=$idQuest?>][]" value="<?=$answer['ID']?>"/>
                                        <?endif;?>
                                        <span><?=$answer['TEXT']?></span>
                                    </td>
                                </tr>
                            <?endforeach;?>
                        <?endif;?>
                        </table>
                    <?endif;?>
                
                <?endforeach;?>
                <input name="save"  type="submit" value="<?=GetMessage("VOTE_SUBMIT_BUTTON")?>"/>
            </form>
        </div>
    <?endforeach;?>
<?endif;?>
</div>